import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.web.HTMLEditor;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * 
 * @author Shane
 * 11-03-2019, Monday
 * 
 * Objective: Display Data on screen then search word.
 *
 */

/**
 * Extend the Application pre-defined user-interface in order to access 
 * java fx predefined methods.
 */
public class Omega extends Application
{
	private Label find, addData;
	private LinearGradient omega, elBano;
	private TextField searchField, locationField;
	private TextArea textArea;
	private HTMLEditor editor;
	private Button blow, quit, loadFile;
	private AudioClip clickAud, hoverAud, warAud;
	private URL click, hover, war;
	
	private FileChooser fc;
	private File fi;
	 // Set the image of the application icon
    private static final String ApplicationIcon= "umbrella.png";
    
	// Create the start method where implements the methods to prepare the UI
	public void start(Stage windowStage)
	{
		// Create the object of Group in order to group the children together
		Group root =new Group();
		// Create the object of scene and also set the width and height of the window
		Scene scene = new Scene(root, 1200, 900);
		// Set the background color
		scene.setFill(Color.rgb(40,  40,  40));
		// Calling gradient methods
		oMega();
		gradient();
				
		
		/**
		 * Set up the audio
		 */
		// Access the audio
		click= Omega.class.getResource("ui.mp3");
		hover= Omega.class.getResource("hover.mp3");
		war= Omega.class.getResource("war.mp3");
		
		// connect audio clip and sounds with the player
		clickAud= new AudioClip(click.toExternalForm());
		hoverAud= new AudioClip(hover.toExternalForm());
		warAud= new AudioClip(war.toExternalForm());
				
		// Create an object of Label and set text Search where user get help what user need
		// to do or enter into the text field
	    find = new Label();
		// Set the text of the label
		find.setText("Search");
		// Set the position of the label
		find.setLayoutX(20); find.setLayoutY(20);
		// Set the text color
		find.setTextFill(omega);
		// Set the style and size of the label
		find.setFont(Font.font("Helvetica",  FontWeight.BOLD, FontPosture.ITALIC,22));
		
		// create the object of text field where user enter the string which one want to search
		searchField = new TextField();
		// Give the hint to the user what user need to perform
		searchField.setPromptText("Enter the String you want to search ");
		// Set the position of the text field
		searchField.setLayoutX(170); searchField.setLayoutY(20);
		// Set the width and height of the text field
		searchField.setMinWidth(600); searchField.setMinHeight(35);
		// Set the size of the text what user will enter
		searchField.setFont(Font.font("Helvetica", FontPosture.ITALIC, 19));
		// Set the border of the text field
		searchField.setStyle("-fx-background-radius: 30;");
		
		
		// Create an object of Label and set text Search where user get help what user need
		// to do or enter into the text field
		addData = new Label();
		// Set the text of the label
		addData.setText("Add Data");
		// Set the position of the label
		addData.setLayoutX(20); addData.setLayoutY(100);
		// Set the text color
		addData.setTextFill(omega);
		// Set the style and size of the label
		addData.setFont(Font.font("Helvetica",  FontWeight.BOLD, FontPosture.ITALIC,22));
		
		// create the object of text area where user enter the string which one want to search
	    textArea = new TextArea();
		// Give the hint to the user what user need to perform
		textArea.setPromptText("Enter the content you want to add ");
		// Set the position of the text field
		textArea.setLayoutX(170); textArea.setLayoutY(100);
		// Set the width and height of the text field
		textArea.setMinWidth(950); textArea.setMaxHeight(250);
		// Set the size of the text what user will enter
		textArea.setFont(Font.font("Helvetica", FontPosture.ITALIC, 19));
		
		// Setup the Editor field where user add data and search string what user want to search
		editor = new HTMLEditor();
		// Set the position of the editor
		editor.setLayoutX(170); editor.setLayoutY(380);
		// Set the width and height of it
		editor.setMaxHeight(400); editor.setMinWidth(950);
		
		// Create the button to add data into editor field and also find the data from the field
		// if user enter the text in search field
		blow = new Button();
		// Set the text of the button
		blow.setText("Search or Add String");
		// Set the position of the button
		blow.setLayoutX(170); blow.setLayoutY(820);
		// Set the size of the text
		blow.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Set the text color
		blow.setTextFill(omega);
		// Hide background
		blow.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		/**
		 * Shadow effect on the add button
		 */
		blow.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				blow.setStyle("-fx-background-insets: 40, 40, 40, 40; -fx-font-size:24;");
				// Set the text color
				blow.setTextFill(elBano);
				// Play sound on hover
				hoverAud.play();
			}
				});
		
		blow.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the background color
				blow.setStyle("-fx-background-insets: 40, 40, 40, 40; "
						+ "-fx-font-size: 22;");
				// Set the text color
				blow.setTextFill(omega);
				// Stop sound
				hoverAud.stop();
			}
				});
		
		/**
		 * Event Handling of button
		 */
		blow.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{
				// Set click sound
				clickAud.play();
				// Call the method
				comoEstas();
			}
				});
		
		/**
		 * Quit button
		 */
		// Set the image of delete icon
		Image shut = new Image("shut.png");
		// View the image 
		ImageView shutView = new ImageView(shut);
		// Set the height and width of the image
		shutView.setFitHeight(45); shutView.setFitWidth(45);
		
		// Create the button to quit the application
		quit = new Button(" ", shutView);
		// Set the position of the button
		quit.setLayoutX(1144); 
		// Set the size of the text
		quit.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Set the text color
		quit.setTextFill(omega);
		// Hide background
		quit.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		/**
		 * Shadow effect on the add button
		 */
		quit.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				quit.setStyle("-fx-background-insets: 40, 40, 40, 40; -fx-font-size:24;");
				// Set the text color
				quit.setTextFill(elBano);
				// Play sound on hover
				hoverAud.play();
				/*button_Add.setShape(new Circle(1.5));*/
			}
				});
		
		quit.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the background color
				quit.setStyle("-fx-background-insets: 40, 40, 40, 40; "
						+ "-fx-font-size: 22;");
				// Set the text color
				quit.setTextFill(omega);
				// Stop sound
				hoverAud.stop();
				/*button_Add.setShape(new Circle(1.5));*/
			}
				});
		
		/**
		 * Event Handling of button
		 */
		quit.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{
				// Set click sound
				clickAud.play();
				// Quit the application
				windowStage.close();
			}
				});
		
		/**
		 * Load button to load the file
		 */
		/**
		 * Quit button
		 */
		// Set the image of delete icon
		/*Image shut = new Image("shut.png");
		// View the image 
		ImageView shutView = new ImageView(shut);
		// Set the height and width of the image
		shutView.setFitHeight(45); shutView.setFitWidth(45);
		*/
		// Create the button to quit the application
		loadFile = new Button("BROWSE");
		// Set the position of the button
		loadFile.setLayoutX(1000);  loadFile.setLayoutY(815);
		// Set the size of the text
		loadFile.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 25));
		// Set the text color
		loadFile.setTextFill(omega);
		// Hide background
		loadFile.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		/**
		 * Shadow effect on the add button
		 */
		loadFile.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				loadFile.setStyle("-fx-background-insets: 40, 40, 40, 40; -fx-font-size:24;");
				// Set the text color
				loadFile.setTextFill(elBano);
				// Play sound on hover
				hoverAud.play();
			}
				});
		
		loadFile.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the background color
				loadFile.setStyle("-fx-background-insets: 40, 40, 40, 40; "
						+ "-fx-font-size: 22;");
				// Set the text color
				loadFile.setTextFill(omega);
				// Stop sound
				hoverAud.stop();
			}
				});
		
		/**
		 * Event Handling of button
		 */
		loadFile.setOnAction(new EventHandler<ActionEvent>()
		{
	public void handle(ActionEvent event)
	{
		
		try
		{
			browse();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
		});
		
		
		// create the object of text field where user enter the string which one want to search
		locationField = new TextField();
		// Give the hint to the user what user need to perform
		locationField.setPromptText("Load the File ");
		// Set the position of the text field
		locationField.setLayoutX(560); locationField.setLayoutY(820);
		// Set the width and height of the text field
		locationField.setMinWidth(400); locationField.setMinHeight(35);
		// Set the size of the text what user will enter
		locationField.setFont(Font.font("Helvetica", FontPosture.ITALIC, 19));
		// Set the border of the text field
		locationField.setStyle("-fx-background-radius: 30;");
				
		// Group the children together 
		root.getChildren().addAll(find, searchField, textArea, addData, editor, blow, quit, loadFile,locationField) ;
				
		// Set the title of the stage
		windowStage.setTitle("Word Finding Application");
		// Hide the stage
		windowStage.initStyle(StageStyle.DECORATED);
		// Set the stage icon
		// Set the icon of the application
		windowStage.getIcons().add(new Image(ApplicationIcon));
		// Disable the resizable
		windowStage.setResizable(false);
		// Connect scene and stage together
		windowStage.setScene(scene);
		// Display window
		windowStage.show();
	}
	private void browse() throws FileNotFoundException {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open Resource File");
	File selectedfile = 	fileChooser.showOpenDialog(null);

	locationField.setText(selectedfile.getName());
	Scanner scan = new Scanner(selectedfile);

		while (scan.hasNextLine()) {	
         String t = scan.nextLine();
		textArea.appendText(t + "\n");		
		}		
	}
	
	// Create the main method to launch the application
	public static void main(String []args)
	{
		// Launch the application
		Application.launch(args);
	}
	
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX                   Prepare Methods               XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	/**
	 * Setup the gradient Colors
	 */
	
	public void oMega()
	{
		// Linear Gradient, in parenthesis, startX, startY, endX, endY, proportional, cyclemethod, and colors which
		// one want to display
		omega = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE, 
				new Stop(0.4f, Color.web("#E74C3C")),
				new Stop(1.0f, Color.web("#F1C40F")));
	}
	
	public void gradient()
	{
		// Linear Gradient, in parenthesis, startX, startY, endX, endY, proportional, cyclemethod, and colors which
		// one want to display
		elBano = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE,
				new Stop(0.1f, Color.web("#5c229b")),
				new Stop(1.0f, Color.web("#9306a0")));
	}
	
	/**
	 * Method of Search or Add String
	 */
	public void comoEstas()
	{
		// Declare the variable which is set to null
		Pattern pattern=null;
		try
		{
			// get the text from text field and store into the pattern variable
			pattern = Pattern.compile(searchField.getText());
		}
		catch (PatternSyntaxException patternSyntaxException)
		{
			// Able to set the html texts
			editor.setHtmlText(String.format(
					"<html><body><p>"+ "<span style=\"color:Red;\">"
							+ "%s</span></p></body></html>", 
							patternSyntaxException.getMessage()));
			return;
		}
		
		// Create the object of matcher and store the text area data
		Matcher match = pattern.matcher(textArea.getText());
		// set boolean variable to false
		boolean got =false;
		// Create the string builder object
		StringBuilder stringBuilder = new StringBuilder();
		
		/**
		 * Create the class 
		 */
		class Alpha
		{
			int beginning, end;
			// Create constructor
			Alpha(int start, int end)
			{
				this.beginning= start;
				this.end= end;
			}
			
		}
		
		// Create the list to insert data
		List<Alpha> pos= new ArrayList<Alpha>();
		// when user click on button then find the string from text area
		while(match.find())
		{
			// if data or string match then set to true
			pos.add(new Alpha(match.start(), match.end()));
			got=true;
		}
		
		// if not match then print string not found
		if(!got)
		{
			warAud.play();
			stringBuilder.append(String.format("No match found.%n"));
			Alert alert = new Alert(AlertType.WARNING);
			DialogPane dp = alert.getDialogPane();
			dp.setBackground(new Background(new BackgroundFill(omega, CornerRadii.EMPTY, Insets.EMPTY)));
			//dp.setEffect(UserInterface.shadowEffect);
			dp.setStyle("-fx-font-weight: bold; -fx-border-color: red;");
			alert.setTitle("Error");
			alert.setHeaderText("No match found.");
			alert.setContentText("Sorry, String not found.");
			alert.showAndWait();
			
		}
		else
		{
			System.out.println(pos);
			// set the position variable to 0
			int position =0;
			for(int i=0; i< pos.size(); i++)
			{
				stringBuilder.append(textArea.getText().substring(position, 
						pos.get(i).beginning)).append("<span style=\"color:"
								+ "RED;font-size:20px; text-decoration"
								+ ":underline\">").append(textArea.getText().substring(pos.get(i).beginning, pos.get(i).end))
                .append("</span>");
				position=pos.get(i).end;
			}
			if(position > 0)
			{
				stringBuilder.append(textArea.getText().substring(position));
			}
		}
		
		String html = String.format("" +
                "<html><body><p>%s</p></body></html>", stringBuilder.toString());

        editor.setHtmlText(html);
	}
	
}
