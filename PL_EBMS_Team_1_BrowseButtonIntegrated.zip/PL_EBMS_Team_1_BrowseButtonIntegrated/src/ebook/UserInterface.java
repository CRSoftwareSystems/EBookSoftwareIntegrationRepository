package ebook;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;

import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/*******
 * <p> Title: UserInterface Class. </p>
 * 
 * <p> Description: A JavaFX demonstration application: This controller class describes the user
 * interface for the Exercise04 demonstration application </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-04 </p>
 * 
 * @author Team 1
 * 
 * @version 2.03	2018-07-19 Baseline
 * @version 3.00	2019-02-24 An enhancement for Project Lab 
 * 
 */
public class UserInterface {
	int result2 = 0;
	
	/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	private Stage primaryStage;
	
	// Attributes used to establish the display and control panel within the window provided to us
	private double controlPanelHeight = Mainline.WINDOW_HEIGHT - 110;
	private int marginWidth = 20;
	// The User Interface widgets used to control the user interface and start and stop the simulation
	private Label label_FileName = new Label("E-Book Manager");
	private Button button_Open = new Button("Open");

	
	private Button bt = new Button();
	private Button bt2 = new Button();
	
	
	// The attributes used to inform the user if the file name specified exists or not
	private Label message_FileFound = new Label("");
	private Label message_FileNotFound = new Label("");


	private Label message_ErrorDetails = new Label("");
	
	// This attribute hold a reference to the Pane that roots the user interface's window
	private Pane window;

	// These attributes put a graphical frame around the portion of the window that receives the
	// black squares representing alive cells
	
		
	
	// GUI elements for the Add Pop-up
		final Stage addDialog = new Stage();
		private Button btn_addPopup = new Button("Add");
		private TextField fld_DefinitionName = new TextField();
    	private Button btn_Saveadded = new Button("Edit");
    	private Button btn_exit = new Button("Exit");
    	private Button btn_browse = new Button("Browse");
    	 List<File> fileList;
  	   File file;
  	   ListView<String> listView;
  	   ObservableList<String> list;
  	   

  		final FileChooser fileChooser = new FileChooser();
  		private Desktop desktop = Desktop.getDesktop();
  	   
  	   
  
	/**********************************************************************************************

	Constructors
	
	**********************************************************************************************/

	/**********
	 * This constructor established the user interface with all of the graphical widgets that are
	 * use to make the user interface work.
	 * 
	 * @param theRoot	This parameter is the Pane that JavaFX expects the application to use when
	 * 					it sets up the GUI elements.
	 */
	public UserInterface(Pane theRoot) {
		window = theRoot;							// Save a reference to theRoot so we can update
													// that Pane during the application's execution
				
		// Set the fill colors for the border frame for the game's output of the simulation
		
		
		
		addDialog.initModality(Modality.APPLICATION_MODAL);
        addDialog.initOwner(primaryStage);
    	// Label the text field that is to receive the file name.
		setupLabelUI(label_FileName, "Arial", 18, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				marginWidth, 10);

		
		
	
		
		// Establish the link between the text input widget and a routine that checks to see if
		// if a file of that name exists and if so, whether or not the data is valid
//		text_FileName.textProperty().addListener((observable, oldValue, newValue) -> {checkFileName(); });

		// Establish a GUI button the user presses when the file name have been entered and the
		// code has verified that the data in the file is valid (e.g. it conforms to the requirements)
		setupButtonUI(button_Open, "Arial", 18, 100, Pos.BASELINE_LEFT, Mainline.WINDOW_WIDTH - 650,  
				controlPanelHeight + 24);
		

		// Establish the link between the button widget and a routine that loads the data into theData
		// data structure
		button_Open.setOnAction((event) -> { setupDictionaryAddPopup(); });

	

		// The following set up the control panel messages for messages and information about errors
		setupLabelUI(message_FileFound, "Arial", 18, 150, Pos.BASELINE_LEFT, 350, controlPanelHeight);
		message_FileFound.setStyle("-fx-text-fill: green; -fx-font-size: 18;");

		setupLabelUI(message_FileNotFound, "Arial", 18, 150, Pos.BASELINE_LEFT, 350, controlPanelHeight);
		message_FileNotFound.setStyle("-fx-text-fill: red; -fx-font-size: 18;");

		setupLabelUI(message_ErrorDetails, "Arial", 16, Mainline.WINDOW_WIDTH, Pos.BASELINE_LEFT, 20,
				controlPanelHeight);
		
		message_ErrorDetails.setStyle("-fx-text-fill: red; -fx-font-size: 16;");

		
		
		// Place all of the just-initialized GUI elements into the pane with the exception of the
		// Stop button.  That widget will replace the Start button, once the Start has been pressed
		theRoot.getChildren().addAll(
				button_Open, message_FileFound, message_FileNotFound, message_ErrorDetails,   label_FileName);
	}

	
	/**********************************************************************************************

	Helper methods - Used to set up the JavaFX widgets and simplify the code above
	
	**********************************************************************************************/

	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}
	

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextAreaUI(TextArea t, String ff, double f, double x, double y, double w, double h, boolean e){
		t.setFont(Font.font(ff, f));
		t.setPrefWidth(w);
		t.setPrefHeight(h);	
		t.setLayoutX(x);
		t.setLayoutY(y);	
		t.setEditable(e);
		t.setWrapText(true);
	}


	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	
	/**********
	 * This method established the pop-up window that allows the user to add a new definition 
	 * in the dictionary and then save it.
	 */
	private void setupDictionaryAddPopup() {
		// Set up the pop-up modal dialogue window
        addDialog.setTitle("Select Book");
       
        Group dictionaryEditControls = new Group();
        
        // Set up the pop-up window
        Scene dialogScene = new Scene(dictionaryEditControls, 500, 200);
        

        // Set up the fields for the add pop-up window
		setupTextUI(fld_DefinitionName, "Arial", 14, 300, Pos.BASELINE_LEFT, 30, 50, true);
     
        // Set the screen so we can see it
        addDialog.setScene(dialogScene);
        
        setupButtonUI(btn_Saveadded, "Arial", 12, 50, Pos.BASELINE_LEFT, 30, 150);
        btn_Saveadded.setOnAction((event) -> { saveTheAddDefinitionData(); });
        
        setupButtonUI(btn_exit, "Arial", 12, 50, Pos.BASELINE_LEFT, 400, 150);
        btn_Saveadded.setOnAction((event) -> { saveTheAddDefinitionData(); });
        
        setupButtonUI(btn_browse, "Arial", 12, 50, Pos.BASELINE_LEFT, 400, 50);
        btn_browse.setOnAction((event) -> { saveTheAddDefinitionData(); });
        
        setupButtonUI(btn_exit, "Arial", 12, 50, Pos.BASELINE_LEFT, 400, 150);
        btn_exit.setOnAction((event) -> { addDialog.close(); });
        
        setupButtonUI(btn_browse, "Arial", 12, 50, Pos.BASELINE_LEFT, 400, 50);
        btn_browse.setOnAction( new EventHandler<ActionEvent>() {
            @Override
            public void handle(final ActionEvent e) {
                File file = fileChooser.showOpenDialog(addDialog);
                if (file != null) {
                    openFile(file);
                }
            }
        });
        
        // Populate the pop-up window with the GUI elements
        dictionaryEditControls.getChildren().addAll(fld_DefinitionName, btn_Saveadded, btn_browse, btn_exit);
        
        // Show the pop-up window
        addDialog.show();
		
	}
	
	
	 private void openFile(File file) {
	        try {
	            desktop.open(file);
	        } catch (IOException ex) {
	            Logger.getLogger(
	                UserInterface.class.getName()).log(
	                    Level.SEVERE, null, ex
	                );
	        }
	    }


	  /**********
     * This method populates the word/phrase to be defined and the definition fields to be added
     * in the dictionary
     */
    private void saveTheAddDefinitionData () {
    	
        	
            // Hide and close the pop-up window
        	addDialog.hide();
            addDialog.close();

       }

}
