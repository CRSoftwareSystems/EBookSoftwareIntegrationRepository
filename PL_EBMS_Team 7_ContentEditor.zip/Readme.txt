EBOOK MANAGEMENT SOFTWARE SUBSYSTEM BY TEAM 7

---------Readme File: - ------------

- There is Userfriendly UI which is working properly
- The books which is already present in the ListView is directly come from the Repository Folder knowns are collection
- In case for other selections, user can direcly access other books from the browse button.
- A button call edit, when clicked on it opens another window where user can do all their editting.
- A button "Publish Book" present on the second window, when clciked on it publish the Book in .html extension
