package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

public class DC implements Initializable {
	
	@FXML
	WebView webView;
	
    @FXML 
   public WebEngine webengine;
    
    @FXML
    private Button zoomIn;
    
    @FXML
    private Button zoomOut;
    


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		 this.webengine = this.webView.getEngine();
		    this.webengine.load("http://google.com");
		    zoomIn.setOnAction((event) -> { ZoomIn(); });
		    zoomOut.setOnAction((event) -> { ZoomOut(); });
	}
	
	public void ZoomIn() {
		webView.setZoom(webView.getZoom()*1.2);
		
	}
	public void ZoomOut() {
		webView.setZoom(webView.getZoom()/1.2);
		
	}
}
