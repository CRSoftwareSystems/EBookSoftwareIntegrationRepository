package application;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.converter.PicturesManager;
import org.apache.poi.hwpf.converter.WordToHtmlConverter;
import org.apache.poi.hwpf.usermodel.Picture;
import org.apache.poi.hwpf.usermodel.PictureType;
import org.w3c.dom.Document;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MainController extends Application implements Initializable {


    @FXML
    private Button login;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private RadioButton reader;
    @FXML
    private RadioButton author;
    @FXML
    private RadioButton admin;
    @FXML
    private Label message;
    @FXML
    private ComboBox<String> cb_roles;


    final String path = "D:/college projects/Semester 4/Project lab/sample/ab1.doc";
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {

        cb_roles.setPromptText("Select User");
        cb_roles.getItems().addAll("Reader", "Author", "Admin");
    }
    
    public static void converted(String path ) throws IOException, ParserConfigurationException, TransformerException{
    	InputStream input = new FileInputStream (path );
        HWPFDocument wordDocument = new HWPFDocument (input);
        WordToHtmlConverter wordToHtmlConverter = new WordToHtmlConverter (DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument() );
        wordToHtmlConverter.setPicturesManager (new PicturesManager() {
            public String savePicture (byte[] content, PictureType pictureType, String suggestedName, float widthInches, float heightInches) {
                return suggestedName;
               
            }
            
        });
        wordToHtmlConverter.processDocument (wordDocument);
        List<?> pics = wordDocument.getPicturesTable().getAllPictures();
        if (pics != null) {
            for (int i = 0; i <pics.size(); i++) {
                Picture pic = (Picture) pics.get (i);
                try {
                    pic.writeImageContent (new FileOutputStream (path + pic.suggestFullFileName() ) );
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
        Document htmlDocument = wordToHtmlConverter.getDocument();
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        DOMSource domSource = new DOMSource (htmlDocument);
        StreamResult streamResult = new StreamResult (outStream);

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer serializer = tf.newTransformer();
        serializer.setOutputProperty (OutputKeys.ENCODING, "gbk");
        serializer.setOutputProperty (OutputKeys.INDENT, "yes");
        serializer.setOutputProperty (OutputKeys.METHOD, "html");
        serializer.transform (domSource, streamResult);
        outStream.close();

        String content = new String (outStream.toByteArray() );

        writeFile (content, path + "convertedAPIhtml.html", "gbk");
        

    }
    @FXML
    public void convert(ActionEvent event) {
    	try {
			MainController.converted(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /**
	 * The write file
	 * @param content
	 * @param path
	 * @param encode
	 */
	public static void writeFile(String content, String path, String encode) {
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			File file = new File(path);
			fos = new FileOutputStream(file);
			bw = new BufferedWriter(new OutputStreamWriter(fos, encode));
			bw.write(content);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null){
					bw.close();
				}
				if (fos != null){
					fos.close();
				}
			} catch (IOException ie) {
				ie.printStackTrace();
			}
		}
	}

    /***
     * @author Jaskirat Singh Grewal, Prince Parihar
     */
    public void launchRelevantWindow() {
        message.setText("");
        String checkuser = username.getText().toString();
        String checkpass = password.getText().toString();
        String checkUserType = cb_roles.getSelectionModel().getSelectedItem();
        Hashtable<Integer,String> titleTable = new Hashtable<Integer, String>();
        titleTable.put(1,"Reader's Hub");
        titleTable.put(2,"Author's Hub");
        titleTable.put(3,"Admin's Hub");
        String currentStageTitle = "";

        if (checkuser.equals("team9") && checkpass.equals("123")) {
            try {
                // Read file fxml and draw interface.
                FXMLLoader fxmlLoader;
                if (checkUserType.equals("Reader")) {
                    fxmlLoader = new FXMLLoader(getClass()
                            .getResource("/application/HomeWindow.fxml"));
                    currentStageTitle = titleTable.get(1);
                }
                else if (checkUserType.equals("Author")) {
                    fxmlLoader = new FXMLLoader(getClass()
                            .getResource("/application/AuthorHub.fxml"));
                    currentStageTitle = titleTable.get(2);
                }
                else
                {
                    fxmlLoader = new FXMLLoader(getClass()
                            .getResource("/application/AdminHub.fxml"));
                    currentStageTitle = titleTable.get(3);
                }
                Parent root1 = (Parent) fxmlLoader.load();
                Stage mainStage = new Stage();
                mainStage.setTitle(currentStageTitle);
                mainStage.setScene(new Scene(root1));
                mainStage.show();

            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Can't Load the window");
            }
        } else
            message.setText("Please Enter Correct Credentials");
    }

    public void SignUp() throws IOException {



        FXMLLoader fxmlLoader = new FXMLLoader(getClass()
                .getResource("/application/SignUp.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage mainStage = new Stage();
        mainStage.setTitle("Reader's Hub");
        mainStage.setScene(new Scene(root1));
        mainStage.show();
    }
    @Override
    public void start(Stage arg0) throws Exception {
        Parent root = FXMLLoader.load(getClass()
                .getResource("/application/LoginPage.fxml"));
        Stage primaryStage = new Stage();
        primaryStage.setTitle("eBook Software");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();


    }
}
		
