package EPUB_PROS;


import java.io.BufferedReader; 
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;


import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.stage.Stage;

/**
 * 
 * @author Shane
 * 01-04-2019, Monday
 * The purpose to create this class is to setup the Main User_Interface of the EPUB application.
 */
public class EPUB_User_Interface 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX        Define the variables and objects globally in order               XXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX        to access from another class according to their specifiers.      XXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	public static MenuBar omegaBar;
	public static Menu hambMenu;
	public static MenuItem historyView, bookMarkView, restartSys, shutdownSys, edit, copy, paste, delete,
	                       darkTheme, silverTheme;
	
	
	
	public static TextField searchBar;
	public static ToolBar gammaBar;
	private Button  addNotes;
	private Image  addNotesImg, quitImg, notesImg;
	private ImageView addNotesView, quitView, notesView;
	
	public static TabPane tabPane;
	public static DropShadow shadowEffect;
	
	public static TabPane notesPane;
	private Tab notesTab, quitTab;
	private TextArea notesArea;
	private Group notesGroup;
	
	double notesSceneX, notesSceneY;
	double notesTranslateX, notesTranslateY;
	private static Stage alertStage;
	private File notesFile;
	
	// Access the icon for stage or Access image to set as a icon on stage
    private final static String ALERT_ICON="/File_Error.png";
    private final static String ALERT_ICON_FILE="/File_Not_Found.png";
    
	public static AudioClip clickAud;
    private static URL clickURL;
    
    private static Tooltip notesTip;
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX      Setup the Main UserInterface of the application      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	// Create the constructor of the current class
	public EPUB_User_Interface(Pane pane)
	{
		/**
		 * Calling Gradient methods in order to use at the program
		 */
		Gradient_Effects.gradient();
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX         SETUP VOICE OR AUDIO            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * Set up the theme song here
		 */
		// Acess the theme sound
		clickURL = EPUB_User_Interface.class.getResource("/ui.mp3");
		
		
		// Connect the sound with the audio player
		clickAud = new AudioClip(clickURL.toExternalForm());
		
		// Set the volume of the song or sound
		clickAud.setVolume(1);
		
		
	
		
		

		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX            Setup ToolBar for numerous purposes            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		// Create an object of the Tool bar
		gammaBar = new ToolBar();
		// Set the size of the toolbar
		gammaBar.setMaxWidth(1628); gammaBar.setMinHeight(60);
		// Set the position of the of the tool bar
		gammaBar.setTranslateY(-520); gammaBar.setTranslateX(-150);
		// Set the background of the tool bar
		gammaBar.setBackground(new Background(new BackgroundFill(Color.rgb(40, 40, 40), CornerRadii.EMPTY, Insets.EMPTY)));
		
		
		
		
		/**
		 * Add the notes Button where user can add notes while reading book
		 */
		// Create an object of the image in order to access the image or icon
		addNotesImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/Add_Notes.png"));
		// Create an object of the Image view in order setup the image
		addNotesView = new ImageView(addNotesImg);
		// Setup the size of the image or icon
		addNotesView.setFitWidth(65); addNotesView.setFitHeight(40);
		
		// Create an object of the button
		addNotes = new Button("", addNotesView);
		// Hide the background of the button
		addNotes.setStyle("-fx-background-insets: 40,40,40,40;");
		// Set the position of the button
		addNotes.setTranslateX(240);
		
		// Create an object of tooltip
		notesTip = new Tooltip();
		// Set the text what want to display
		notesTip.setText("Add Notes");
		// Set the font of the tooltip text
		notesTip.setFont(Font.font("Arial", FontPosture.ITALIC, 20));
		// Set the color of the text
		notesTip.setStyle("-fx-base: #AE3522; -fx-background-radius: 30; -fx-text-fill: orange;");
		// Set the tooltip on which field want to display
		addNotes.setTooltip(notesTip);
		
		// Create an object of the drop shadow
		shadowEffect = new DropShadow();
		/**
		 * Setup Mouse Hover Effect on Add Notes Button
		 */
		addNotes.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				addNotes.setEffect(shadowEffect);
				// Set the background color on hover
				addNotes.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );");
			}
				});
		
		addNotes.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				addNotes.setEffect(null);
				// Disable background color on hovor end
				addNotes.setStyle("-fx-background-color: transparent;");
			}
				});
		
		/**
		 * Setup the event handling of add notes button where user would be able to prepare the notes at any time even
		 * while reading book and here the user able to drag and drop the notes area anywhere as per their choice and it 
		 * will allow to the user more comfortness.
		 */
		// Create an object of the Tab Pane
		notesPane = new TabPane();
		// Set the size of the tab pane
		notesPane.setMaxWidth(450); notesPane.setMaxHeight(350);
		// Access the css file
		notesPane.getStylesheets().add("ab.css");
		
		/**
		 * Reduce the visibility at drag and drop time
		 */
		
		notesPane.setOnDragDetected(new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Reduce the visibitity
				notesPane.setOpacity(0.4);
			}
				});
		notesPane.setOnMouseReleased(new EventHandler <MouseEvent>()
        {
            public void handle(MouseEvent event)
            {
            	// Increase the visibility
            	notesPane.setOpacity(1);
            }
        });
		/**
		 * Setup event handling 
		 */
		addNotes.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent notesEvent)
			{
				// Play sound 
				clickAud.play();
				// Set the style of the cursor when mouse hover over the tab pane
				notesPane.setCursor(Cursor.MOVE);
				// Set up the event onto the Tab pane, this event when mouse pressed
				notesPane.setOnMousePressed(mousePressed);
				// Setup the event onto the Tab Pane, this event when use want to drag 
				// the notes area
				notesPane.setOnMouseDragged(mouseDragged);
				/**
				 * Tab Setup
				 */
				// Create an object of the image to set icon at the tab
				notesImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/notes.png"));
				// Create an object of the image view to view an image
				notesView = new ImageView(notesImg);
				// Set the size of the icon
				notesView.setFitWidth(40); notesView.setFitHeight(35);
				
				// Create an object of the Tab
				notesTab = new Tab("                        Make Notes                             ");
				// Add the background color of the tab
				notesTab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(130,30,51,1) 45.3%, rgba(95,123,190,1) 279% );");
				// Disable the close tab
				notesTab.setClosable(false);
				// Set the image at the notes tab
				notesTab.setGraphic(notesView);
				
				/**
				 * Quit button setup
				 */
				// Create an object of the Image and access the quit icon
				quitImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/quit.png"));
				// Create an object of the image view to view an image 
				quitView = new ImageView(quitImg);
				// Set the size of the icon
				quitView.setFitWidth(45); quitView.setFitHeight(35);
				
				// Create an object of the quit tab
				quitTab = new Tab("");
				// Add the background color of the tab
				quitTab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(130,30,51,1) 45.3%, rgba(95,123,190,1) 279% );");
				// Disable the close tab
				quitTab.setClosable(false);
				// Set the quit image at tab
				quitTab.setGraphic(quitView);
				/**
				 * Event handling of quit tab
				 */
				quitTab.setOnSelectionChanged(new EventHandler<Event>()
						{
					public void handle(Event event)
					{
						if(quitTab.isSelected())
						{
							// Get the size of the tabs
							int size =notesPane.getTabs().size();
							// Close all the tabs
							notesPane.getTabs().remove(0,size);
							
							/**
							 * Save the notes when close the notes section
							 */
							// Create an object of the file
							File saveFile = new File("Add_Notes.txt");
				            if(saveFile != null)
				            {
				            	// Call the saveTextAreaData method and get the text from
				            	// notes area and save at the file
				                saveTextAreaData(notesArea.getText(), saveFile);
				            }
						
						}
					}
						});
				
				
				/**
				 * Text area setup
				 */
				// Create an object of the text area
				notesArea = new TextArea();
				// Set the size of the text area
				notesArea.setPrefSize(449, 300);
				// Set the hint to the user
				notesArea.setPromptText("Add your notes here........");
				// Set the font size of the notes 
				notesArea.setFont(Font.font("Helvetica", FontPosture.ITALIC, 18));
				// Setup the text area
				notesArea.setStyle("-fx-border-color: firebrick; -fx-border-width: 3.5; -fx-border-style: solid ;"
						           + "-fx-text-fill: #555A54;");
				// Apply css at notes area
				notesArea.getStylesheets().add("/ab.css");
				// Create an object of the Group to group the tab
				notesGroup = new Group();
				// Add the text area at the group
				notesGroup.getChildren().addAll(notesArea);
				
				/**
				 * Setup file to fetch 
				 */
				// Create an object of the file and fetch the file
				notesFile = new File("Add_Notes.txt");
				// Implement condition in order to check the file is null or not
				if(notesFile != null)
		        {
					// Set the text at the text area if file exists
		            notesArea.setText(readData(notesFile));
		        }				
				// Add the group to the tab
				notesTab.setContent(notesGroup);
				
				// Add the tab at the tab pane
				notesPane.getTabs().addAll(notesTab, quitTab);
								
			}
				});
		
		// Add the search field into the toolbar
		gammaBar.getItems().addAll( addNotes);
				
		
		
		// Group the children at the pane in order to display at the window 
		pane.getChildren().addAll();
	}
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX     Setup the method to save the notes at the file        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	private void saveTextAreaData(String data, File file)
	{
        try 
        {
        	// Create an object of the file writer
            FileWriter fileWriter = new FileWriter(file);
            // Write the data 
            fileWriter.write(data);
            // Close the writer
            fileWriter.close();
        } 
        catch (IOException ex) 
        {
        	/**
        	 * Display alert window if file not found
        	 */
        	
        	/**
			 * Setup the alert window if loading failed at any case like Not connected with the internet or something
			 * else reason.
			 */
			Alert alertWindow = new Alert(AlertType.WARNING);
			// Set the dialog pane
			DialogPane dialog = alertWindow.getDialogPane();
			// Set the background of the alert window
			dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
			// Add the Effect on dialog
			dialog.setEffect(shadowEffect);
			// Set the text color 
			dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
			// Set the title of the window
			alertWindow.setTitle("Loading Error");
			// Set the header text
			alertWindow.setHeaderText("Loading Failed!");
			// Set the message for the user in brief
			alertWindow.setContentText("Please, check your internet connection!");
			// Create an object of the Stage and set the icon onto the alert window
			alertStage = (Stage) alertWindow.getDialogPane().getScene().getWindow();
			// Set the image as an window icon
			alertStage.getIcons().add(new Image(ALERT_ICON_FILE));
			// Set the height of the alert window
			alertWindow.getDialogPane().setMinHeight(200);
			// Set the width of the alert window
			alertWindow.getDialogPane().setMinWidth(500);
			// Display alert window
			alertWindow.showAndWait();
        }
          
    }
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX     Setup the method to read the file and display at notes section     XXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	private String readData(File notes)
	 {
		// Create an object of the String builder
		StringBuilder buffer = new StringBuilder();
		// Create an object of the file reader to read the file
		FileReader notesRead = null;
		try 
		{
			// Read the file if file exist
			notesRead = new FileReader(notes);
		} 
		catch (FileNotFoundException fileNotFoundException)
		{
			/**
			 * Display alert window if file not found
			 */
			/**
			 * Setup the alert window if loading failed at any case like Not connected with the internet or something
			 * else reason.
			 */
			Alert alertWindow = new Alert(AlertType.WARNING);
			// Set the dialog pane
			DialogPane dialog = alertWindow.getDialogPane();
			// Set the background of the alert window
			dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
			// Add the Effect on dialog
			dialog.setEffect(shadowEffect);
			// Set the text color 
			dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
			// Set the title of the window
			alertWindow.setTitle("File Error");
			// Set the header text
			alertWindow.setHeaderText("File Not Found!");
			// Set the message for the user in brief
			alertWindow.setContentText("Sorry, File couldn't Found!");
			// Create an object of the Stage and set the icon onto the alert window
			alertStage = (Stage) alertWindow.getDialogPane().getScene().getWindow();
			// Set the image as an window icon
			alertStage.getIcons().add(new Image(ALERT_ICON));
			// Set the height of the alert window
			alertWindow.getDialogPane().setMinHeight(200);
			// Set the width of the alert window
			alertWindow.getDialogPane().setMinWidth(500);
			// Display alert window
			alertWindow.showAndWait();
		}
		// Create an object of the buffered reader
		BufferedReader notesBufReader = new BufferedReader(notesRead);
		// Create the String variable to store the read data
		String notesStorage;
		// Implement the logic to read the file line by line via buffer reader
		try 
		{
			while((notesStorage = notesBufReader.readLine()) != null)
			{
				// Append the text 
				buffer.append(notesStorage);
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		    // Return the data in to the string form
	        return buffer.toString();
	    }
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX     Setup the Draggable events on to the notes section    XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	 /**
     * Setup the mouse event onto the Notes Section where set event on mouse pressed
     * 
     */
    EventHandler<MouseEvent> mousePressed = new EventHandler<MouseEvent>()
    		{
    	public void handle(MouseEvent mouseEvent)
    	{
    		// get the scene vertical and horizontal and give control on mouse event
    		notesSceneX = mouseEvent.getSceneX();
    		notesSceneY = mouseEvent.getSceneY();
    		// Get the allowance to set the positon on mouse event
    		notesTranslateX = ((TabPane)(mouseEvent.getSource())).getTranslateX();
    		notesTranslateY = ((TabPane)(mouseEvent.getSource())).getTranslateY();
    	}
    		};
    /**
     * Set up the event to drag the Notes Section
     */
    EventHandler<MouseEvent> mouseDragged = new EventHandler<MouseEvent>()
    		{
    	public void handle(MouseEvent mouseEvent)
    	{
    		double textOffSetX = mouseEvent.getSceneX() - notesSceneX;
    		double textOffSetY = mouseEvent.getSceneY() - notesSceneY;
    		double textNewTranslateX = notesTranslateX + textOffSetX;
    		double textNewTranslateY = notesTranslateY + textOffSetY;
    		
    		((TabPane)(mouseEvent.getSource())).setTranslateX(textNewTranslateX);
    		((TabPane)(mouseEvent.getSource())).setTranslateY(textNewTranslateY);
    	}
    		};
}
