package EPUB_PROS;
import EPUB_OMEGA.Splash_Screen;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/**
 * 
 * @author Shane
 * 15-03-2019, Friday
 * Objective is to setup the Register_Form where user able to register the account in order to
 * input the fields as required.
 */
public class Register_UI 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Define objects Globally                                    XXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	/**
	 * Define the object globally in order to access easily from anywhere according to the specifiers
	 */
	public static Text registeration_Form;
	private Label user_Name, email_ID, pass_Word, confirm_Password;
	private TextField user_Name_Field, email_ID_Field;
	private PasswordField pass_Word_Field, confirm_Password_Field;
	private Button register, back_To_Login;
	private DropShadow dropShadow;
	
	/**
	 * Constructor of this class where to design the register form
	 */
	public Register_UI(Pane paneRoot)
	{
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Method Calling                                             XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Call the Gradient color
		Gradient_Effects.gradientBallEffect();
		Gradient_Effects.gradientRedEffect();
		Gradient_Effects.oMega();
		Gradient_Effects.gradient();
		
		/**
		 * Create the object of the drop shadow
		 */
		dropShadow = new DropShadow();
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Register Form Text setup                                   XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the text
		registeration_Form = new Text();
		// Set the text 
		registeration_Form.setText("REGISTERATION FORM");
		// Set the position of the text
		registeration_Form.setFont(Font.font("Helvetica", FontPosture.ITALIC, 120));
		// Set the position of the button
		registeration_Form.setLayoutX(400); registeration_Form.setLayoutY(150);
		// Set the color of the text or may say set the gradient color
		registeration_Form.setFill(Gradient_Effects.omega);
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Setup Label and Fields                                     XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * Setup Username Label
		 */
		// Create the object of the label
		user_Name = new Label();
		// Set the text of the label
		user_Name.setText("USERNAME");
		// Set the style and size of the label
		user_Name.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 30));
		// Set the position of the label
		user_Name.setLayoutX(500); user_Name.setLayoutY(250);
		
		
		/**
		 * Setup the User Text Field
		 */
		// Create the object of Textfield
		user_Name_Field = new TextField();
		// Set the style and size of the field
		user_Name_Field.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the position of the textfield
		user_Name_Field.setLayoutX(830); user_Name_Field.setLayoutY(250);
		// Style the border of text field
		user_Name_Field.setStyle("-fx-background-radius: 30;");
		// Set the width of the text field
		user_Name_Field.setMinWidth(380);
		// Give hint to the user what user need to do
		user_Name_Field.setPromptText("Enter your name");
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Setup EMAIL-ID Label and Fields                                     XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		/**
		 * Setup the Email Label
		 */
		// Create the Email Label
		email_ID = new Label();
		// Set the text 
		email_ID.setText("EMAIL-ID");
		// Set the style and size of the label 
		email_ID.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 30));
		// Set the position of the label
		email_ID.setLayoutX(500); email_ID.setLayoutY(340);
		
		
		/**
		 * Setup the Email Field
		 */
		// Create the object of the email field
		email_ID_Field = new TextField();
		// Set the style and size of the text
		email_ID_Field.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the position of the email field
		email_ID_Field.setLayoutX(830); email_ID_Field.setLayoutY(340);
		// Style the border of the field
		email_ID_Field.setStyle("-fx-background-radius: 30;");
		// Set the width of the field
		email_ID_Field.setMinWidth(380);
		// Give hint to the user what user need to do
		email_ID_Field.setPromptText("Enter your Email ID");
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Setup Password label and Fields                                     XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		/**
		 * Setup the password label
		 */
		// Create the object of the password label
		pass_Word = new Label();
		// Set the text of the label
		pass_Word.setText("PASSWORD");
		// Set the style and size of the password label
		pass_Word.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 30));
		// Set the position of the label
		pass_Word.setLayoutX(500); pass_Word.setLayoutY(430);
		
		
		/**
		 * Setup the Password Field
		 */
		// Create the object of the password field
		pass_Word_Field = new PasswordField();
		// Set the style of the field text
		pass_Word_Field.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the position of the field
		pass_Word_Field.setLayoutX(830); pass_Word_Field.setLayoutY(430);
		// Setup the border of the field
		pass_Word_Field.setStyle("-fx-background-radius: 30;");
		// Set the width of the field
		pass_Word_Field.setMinWidth(380);
		// Give hint to the user what user need to do
		pass_Word_Field.setPromptText("Enter your password");
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Setup Confirm Password Label and Fields                                     XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		
		/**
		 * Setup the confirm Password label
		 */
		// Create the object of the label
		confirm_Password = new Label();
		// Set the text of the label
		confirm_Password.setText("CONFIRM PASSWORD");
		// Set the style and size of the label
		confirm_Password.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 30));
		// Set the position of the label
		confirm_Password.setLayoutX(500); confirm_Password.setLayoutY(520);
		
		
		/**
		 * Setup the confirm password field
		 */
		// Create the object of the confirm password fielt
		confirm_Password_Field = new PasswordField();
		// Set the style and size of the field text
		confirm_Password_Field.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the position of the field
		confirm_Password_Field.setLayoutX(830); confirm_Password_Field.setLayoutY(520);
		// Set the style of the field border
		confirm_Password_Field.setStyle("-fx-background-radius: 30;");
		// Set the min width of the field
		confirm_Password_Field.setMinWidth(380);
		// Give hint to the user what user need to do
		confirm_Password_Field.setPromptText("Enter your same password again");
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                Setup Register Button, Hover Effect and Event Handling          XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		
		/**
		 * Setup Register button, when user click upon register button then data store into the database,
		 * and user would be able to login with that email in future.
		 */
		// Create the object of the register button
		register = new Button();
		// Set the text of the button
		register.setText("REGISTER");
		// Set the style and size of the button text
		register.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 24));
		// Set the position of the button
		register.setLayoutX(1030); register.setLayoutY(620);
		// Set the width of the button
		register.setMinWidth(180);
		// Set the style of the button
		register.setStyle("-fx-background-color: #090a0c, linear-gradient(#38424b 0%, #1f2429 20%, #191d22 100%),"
								+ "linear-gradient(#20262b, #191d22), radial-gradient(center 50% 0%, radius 100%, "
								+ "rgba(114,131,148,0.9), rgba(255,255,255,0)); "
								+ "-fx-background-radius: 30;"
								+ "-fx-background-insets: 0,1,2,0;"
								+ "-fx-padding:10 20 10 20;");
		// Set the color of the text
		register.setTextFill(Color.WHITE);
		
		/**
		 * Add an hover effect on button
		 */
		register.addEventHandler(MouseEvent.MOUSE_ENTERED,new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Set the hover effect on button
				register.setEffect(dropShadow);
				// Change the color on hover
				register.setTextFill(Color.web("#F4D03F"));
			}
				});
		
		register.addEventHandler(MouseEvent.MOUSE_EXITED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Disable the effect when hover doesn't happen
				register.setEffect(null);
				// Set the color of the text
				register.setTextFill(Color.WHITE);		
			
		    }
				});
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX      Setup A button to get us back to logn window if user already have         XXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX      an account, set up hover Effect and event handling                        XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		
		/*
		 * Setup the Login back screen button
		 */
		// Create the object of the button
		back_To_Login = new Button();
		// Set the text of the button
		back_To_Login.setText("Already Have An Account? Click Here!");
		// Set the style and size of the button text
		back_To_Login.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Set the border of the button
		back_To_Login.setStyle("-fx-background-color: #090a0c, linear-gradient(#38424b 0%, #1f2429 20%, #191d22 100%),"
				+ "linear-gradient(#20262b, #191d22), radial-gradient(center 50% 0%, radius 100%, "
				+ "rgba(114,131,148,0.9), rgba(255,255,255,0)); "
				+ "-fx-background-radius: 30;"
				+ "-fx-background-insets: 0,1,2,0;"
				+ "-fx-padding:10 20 10 20;");
		// Set the position of the button
		back_To_Login.setLayoutX(830); back_To_Login.setLayoutY(720);
		
		// Set the color of the text button
		back_To_Login.setTextFill(Color.WHITE);
		
		/**
		 * Setup hover effect on button
		 */
		back_To_Login.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Set the hover effect on button
				back_To_Login.setEffect(dropShadow);
				// Change the color on hover
				back_To_Login.setTextFill(Color.web("#F4D03F"));
			}
				});
		
		back_To_Login.addEventHandler(MouseEvent.MOUSE_EXITED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Disable the effect when hover doesn't happen
				back_To_Login.setEffect(null);
				// Set the color of the text
				back_To_Login.setTextFill(Color.WHITE);	
			}
				});
		
		/**
		 * Event handler of the button where user enter the button
		 * then user able to reach or visit the login form window
		 */
		
		back_To_Login.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent actionEvent)
			{
				// Jump on to the Login Form window
				EPUB_MAIN.stg.setScene(EPUB_MAIN.scene);
			}
				});
		
		/**
		 * Call the animation ball method
		 */
		Anim_Trans.animBall();
		// Group the children together
		paneRoot.getChildren().addAll(Background_Image.backgroundImage(), registeration_Form, Anim_Trans.animBall1, user_Name, user_Name_Field,
				email_ID, email_ID_Field, pass_Word, pass_Word_Field, confirm_Password, confirm_Password_Field, register,  back_To_Login);
		
	}

}
