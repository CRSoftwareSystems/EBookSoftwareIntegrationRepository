package EPUB_PROS;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;

/**
 * 
 * @author Shane
 * 15-03-2019, Friday
 * The purpose to create this class is to prepare the Gradient effects for various purposes like add 
 * effects on buttons, or labels and so on.
 *
 */
public class Gradient_Effects 
{

	// Define the objects Globally in order to access from anywhere
	public static RadialGradient omegaBallEffect, omegaRedEffect;
	public static LinearGradient omega, elBano;
	
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX                      Create Methods to setup the Gradient Colors                 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	/**
	 * Create the method to setup the radient color
	 */
	public static void gradientBallEffect()
	{
		// Create the object of Radial Gradient and setup the color or effects
		omegaBallEffect = new RadialGradient(0, 0, 0.35, 0.35, 0.5, true, CycleMethod.NO_CYCLE, 
						new Stop(0.0, Color.WHITE), new Stop(1.0, Color.BLUE));
	}
	
	public static void gradientRedEffect()
	{
		// Create the object of Radial Gradient and setup the color or effects
		omegaRedEffect = new RadialGradient(2, 2, 0.35, 0.55, 0.45, true, CycleMethod.NO_CYCLE, 
								new Stop(0.1, Color.YELLOW), new Stop(1.0, Color.RED));
	}
	
	/**
	 * Set up the Linear gradient color 
	 */
	public static void oMega()
	{
		
		// Linear Gradient, in parenthesis, startX, startY, endX, endY, proportional, cycle colors, and colors which one 
		// want to display 
	    omega = new LinearGradient(0, 0.35, 0, 0.8, true, CycleMethod.NO_CYCLE,
				new Stop(0.4f, Color.web("#E74C3C")),
				new Stop(1.0f, Color.web("#F1C40F")));
		
	}
	
	/**
	 * Set up the Linear gradient color
	 */
	
	public static void gradient()
	{	
		// Linear Gradient, in parenthesis, startX, startY, endX, endY, proportional, cycle colors, and colors which one 
		// want to display 
		elBano = new LinearGradient(0, 0, 1, 1, true, CycleMethod.NO_CYCLE,
				new Stop(0.1f, Color.web("#5c229b")),
				new Stop(1.0f, Color.web("#9306a0")));
	}
	
	
}
