package EPUB_PROS;
import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CubicCurveTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Pro extends Application
{
	public void start(Stage primaryStage)
	{
		//Setting the font of the text 
	     // text.setFont(Font.font("Edwardian Script ITC", 50)); 
		Group root = new Group();
		Scene sc= new Scene(root, 900, 700, Color.rgb(40, 40,  40));
		// Set the background color
	    //sc.setBackground(new Background(new BackgroundFill(Color.rgb(40,  40,  40), CornerRadii.EMPTY, Insets.EMPTY)));
				
		Image umbrella = new Image("umbrella.png");
		ImageView umbrellaView = new ImageView(umbrella);
		// Set the width and height of the image
		umbrellaView.setFitHeight(100); umbrellaView.setFitWidth(100);
		// Set the position of the image0
		umbrellaView.setLayoutX(200); umbrellaView.setLayoutY(100);
		//umbrellaView.setStyle("-fx-background-insets: 40, 40, 40, 40;");
  
		
		/**
		 * Rotate Transition
		 */
		// Setup the Transitions
		RotateTransition rotation = new RotateTransition();
		// Setup the duration of transition
		rotation.setDuration(Duration.millis(2000));
		// Setup the node for the transition or may say connection between the transition and umbrella image
		rotation.setNode(umbrellaView);
		// Set the rotation angle
		rotation.setByAngle(360);
		// Set the number of times want to rotate
		rotation.setCycleCount(400);
		// Setup autoreverse after one rotation
		rotation.setAutoReverse(false);
		// Play transition
		//rotation.play();
		
		/**
		 * Scale Transition
		 */
		// Create the object of Scale Transition
		ScaleTransition scaleTransition = new ScaleTransition();
		// Set the duration of the transition
		scaleTransition.setDuration(Duration.millis(2000));
		// Setup the node for the transition or may say connection between the transition and image
		scaleTransition.setNode(umbrellaView);
		// Setup the dimensions for scalling
		scaleTransition.setByY(1.5); scaleTransition.setByX(1.5);
		// Set the number of times want to zoom in and out
		scaleTransition.setCycleCount(400);
		// set autoreverse
		scaleTransition.setAutoReverse(true);
		// Play transition
		//scaleTransition.play();
		/**
		 * Translate Transition
		 */
		// Create the object of TranslateTransition
		TranslateTransition transition = new TranslateTransition();
		// Set the duration of the transition
		transition.setDuration(Duration.millis(200));
		// Setup the node for the transition or may say connection between the transition and image
		transition.setNode(umbrellaView);
		// Setup the transition
		transition.setFromX(sc.getWidth());
		transition.setToY(-1.0 * umbrellaView.getLayoutBounds().getWidth());
		// Set the animation indefinite times
		transition.setCycleCount(TranslateTransition.INDEFINITE);
		// Set the transition autorever
		transition.setAutoReverse(true);
		// Play animation
		//transition.play();
		
		
		// Create the object of TranslateTransition
		TranslateTransition transition2 = new TranslateTransition();
		// Set the duration of the transition
		transition2.setDuration(Duration.seconds(2));
		// Setup the node for the transition or may say connection between the transition and image
		transition2.setNode(umbrellaView);
		// Setup the transition
		transition2.setFromX(sc.getWidth());
		transition2.setToX(-1.0 * umbrellaView.getLayoutBounds().getWidth());
		// Set the animation indefinite times
		transition2.setCycleCount(TranslateTransition.INDEFINITE);
		// Set the transition autorever
		transition2.setAutoReverse(true);
		// Play animation
		//transition2.play();
        
		
		// Create the object of the circle and set the size of the circle
		Circle path = new Circle(150, 150, 150);
		// Hide the color of the circle
		path.setFill(null);
		// Set the border of the circle
		path.setStroke(Color.WHITE);
		
		/**
		 * Path transition
		 */
		// Create the object of Path Transition
		//PathTransition pathTrans = new PathTransition(Duration.seconds(2),umbrellaView, rectangle);
		// Set up a Path Transition for the Rectangle and set the duration of the animation
        PathTransition pathTrans = new PathTransition(Duration.seconds(2), path, umbrellaView);
		// Setup the orientation
		pathTrans.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		// Set the number of time want to display the animation
		pathTrans.setCycleCount(FadeTransition.INDEFINITE);
		// Set the direction autoreverse
		pathTrans.setAutoReverse(true);
		// Play the animation
		//pathTrans.play();
		
		Circle circle = new Circle(50, 50, 30);
		
		/**
		 * Path transition
		 */
		final Path paths = new Path();
		paths.setStroke(Color.rgb(40, 40,  40));
	    paths.getElements().add(new MoveTo(900, 40));
	    paths.getElements().add(new CubicCurveTo(80, 100,  100, 120, 20, 30));
	    paths.getElements().add(new CubicCurveTo(280, 1180, 110, 240, 880, 540));
	    paths.setOpacity(0.5);

	    final PathTransition pathTransition = new PathTransition();

	    pathTransition.setDuration(Duration.seconds(8.0));
	    pathTransition.setDelay(Duration.seconds(.5));
	    pathTransition.setPath(paths);
	    pathTransition.setNode(umbrellaView);
	    pathTransition
	        .setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
	    pathTransition.setCycleCount(Timeline.INDEFINITE);
	    pathTransition.setAutoReverse(false);
	    //pathTransition.play();
        
        
		// Group the children
		root.getChildren().addAll(umbrellaView, /* path,*/ paths);
		
		primaryStage.setScene(sc);
		primaryStage.show();
	}
	
	public static void main(String []args)
	{
		Application.launch(args);
	}

}





/*
import javafx.animation.FillTransition;
import javafx.animation.PathTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import static javafx.animation.PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT;
 
public class Demo extends Application
{
    public static void main(String[] args) 
    {
        Application.launch(args);
    }
     
    @Override
    public void start(Stage stage) 
    {
        // Create the Rectangle
        Rectangle rect = new Rectangle(50, 30, Color.RED);
 
        // Create the path
        Circle path = new Circle(100);
        path.setFill(null);
        path.setStroke(Color.BLACK);
         
        // Create the VBox
        VBox root = new VBox(rect, path);
        // Set the Size of the VBox
        root.setPrefSize(300, 300);
        // Set the Style-properties of the VBox
        root.setStyle("-fx-padding: 10;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 2;" +
                "-fx-border-insets: 5;" +
                "-fx-border-radius: 5;" +
                "-fx-border-color: blue;");
         
        // Create the Scene
        Scene scene = new Scene(root);
        // Add the Scene to the Stage
        stage.setScene(scene);
        // Set the Title of the Stage
        stage.setTitle("A Sequential Transition Example");
        // Display the Stage
        stage.show();
 
        // Set up a Scale Transition
        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(1));
        scaleTransition.setFromX(1.0);
        scaleTransition.setToX(2.0);
        scaleTransition.setFromY(1.0);
        scaleTransition.setToY(2.0);
        // Let the animation run forever
        scaleTransition.setCycleCount(2);
        // Reverse direction on alternating cycles
        scaleTransition.setAutoReverse(true);
         
        // Set up a Fill Transition
        FillTransition fillTransition = new FillTransition(Duration.seconds(1));
        fillTransition.setFromValue(Color.RED);
        fillTransition.setToValue(Color.BLUE);
        // Let the animation run forever
        fillTransition.setCycleCount(2);
        // Reverse direction on alternating cycles
        fillTransition.setAutoReverse(true);
         
        // Set up a Path Transition
        PathTransition pathTransition = new PathTransition(Duration.seconds(2), path);
        pathTransition.setOrientation(ORTHOGONAL_TO_TANGENT);
 
        // Create a sequential transition
        SequentialTransition sequTransition = new SequentialTransition();
        // Rectangle is the node for all animations
        sequTransition.setNode(rect);
        // Add animations to the list
        sequTransition.getChildren().addAll(scaleTransition, fillTransition,pathTransition);
        // Let the animation run forever
        sequTransition.setCycleCount(PathTransition.INDEFINITE);
        // Play the Animation
        sequTransition.play();      
    }
}*/



/*import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PathTransition;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
 
public class Demo extends Application
{
    public static void main(String[] args) 
    {
        Application.launch(args);
    }
     
    @Override
    public void start(Stage stage) 
    {
        // Create the Rectangle
        Rectangle rect = new Rectangle(200, 200, Color.RED);
        // Create the HBox
        HBox root = new HBox(rect);
        // Set the Margin for the HBox
        HBox.setMargin(rect, new Insets(50));
        // Set the Style-properties of the HBox
        root.setStyle("-fx-padding: 10;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 2;" +
                "-fx-border-insets: 5;" +
                "-fx-border-radius: 5;" +
                "-fx-border-color: blue;");
 
        // Create the Scene
        Scene scene = new Scene(root);
        // Add the Scene to the Stage
        stage.setScene(scene);
        // Set the Title of the Stage
        stage.setTitle("A Parallel Transition Example");
        // Display the Stage
        stage.show();
 
        // Set up a Fade Transition
        FadeTransition fadeTransition = new FadeTransition(Duration.seconds(1));
        fadeTransition.setFromValue(0.20);
        fadeTransition.setToValue(1.0);
        // Let the animation run two times
        fadeTransition.setCycleCount(2);
        // Reverse direction on alternating cycles
        fadeTransition.setAutoReverse(true);
         
        // Set up a Rotate Transition
        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(2));
        rotateTransition.setFromAngle(0.0);
        rotateTransition.setToAngle(360.0);
        // Let the animation run two times
        rotateTransition.setCycleCount(2);
        // Reverse direction on alternating cycles
        rotateTransition.setAutoReverse(true);
         
        // Create and start a Parallel Transition
        ParallelTransition parTransition = new ParallelTransition();
        parTransition.setNode(rect);
        // Add the Children to the ParallelTransition
        parTransition.getChildren().addAll(fadeTransition, rotateTransition);
        // Let the animation run forever
        parTransition.setCycleCount(PathTransition.INDEFINITE);
        // Play the Animation
        parTransition.play();       
    }
}*/