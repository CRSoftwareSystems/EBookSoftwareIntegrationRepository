package EPUB_OMEGA;

import java.awt.Desktop; 
import java.io.IOException;

import EPUB_PROS.EPUB_MAIN;
import EPUB_PROS.EPUB_User_Interface;
import EPUB_PROS.Gradient_Effects;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.concurrent.Worker.State;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;
import javafx.scene.web.WebHistory.Entry;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/**
 * 
 * @author Shane
 * 03-04-2019, Wednesday
 * The purpose to create this class is to setup the method of Web View in order to
 * use the internet and able to visit what we want to see or where we want to visit like
 * web browser
 */

public class Web_View 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX              Define the variables and objects globally    XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	public static WebView browser;
	public static WebEngine web_Engine;
	public static ProgressBar loadingProcess;
	private static Worker<Void> work;
	public static Label status;
	private static DropShadow dropShadow;
	public static Stage alertStage;
	public static WebHistory web_History;
	public static ListView<Entry> history_List;
	public static ObservableList<Entry> entryList;

	
	// Set the link in order to load initially
	private static String urlLink= "https://www.google.com";
	// Access the icon for stage or Access image to set as a icon on stage
    public final static String ALERT_ICON="/biohazard.png";
    
    
	
	/**
	 * 
	 * Create this method to setup the web view
	 * Moreover, pass the browser object at the stackpane which is available at the
	 * EPUB_MAIN class
	 */
	@SuppressWarnings("unchecked")
	public static void web_Browser()
	{
		/**
		 * Call the Gradient colors methods
		 */
		Gradient_Effects.oMega();
		
		/**
		 * Create an object of the Drop Shadow
		 */
		dropShadow = new DropShadow();
		
		
		/*shutDown = new Button();
		shutDown.setText("DON'T KILL ME");
		shutDown.setMinHeight(400); shutDown.setMinWidth(500);
		shutDown.setFont(Font.font("Helvetica", 100));
		shutDown.setTextFill(Gradient_Effects.omega);
		shutDown.setStyle("-fx-background-insets: 40,40,40,40;");
		shutDown.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{
				try {
					Runtime.getRuntime().exec("shutdown -r -t 0");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
				});*/
		// Create an object of the browser
		browser = new WebView();
		// Set the width and height of the browser
		browser.setMinHeight(940); browser.setMinWidth(1564);
		// Set the position of the browser
		browser.setTranslateY(30);
		// Set the zoom level of the web view
		browser.setZoom(1.2);
		// Set the font size of the web view texts
		browser.setFontScale(0.8);
		// When user right click on to the webview then event happen
		browser.setContextMenuEnabled(true);
		// Create an object of the web engine and access the engine with the help of view
		web_Engine = browser.getEngine();
		
		// Load the page 
		web_Engine.load(urlLink);
		// Zoom in the web view
		browser.setZoom(1.1);
		// Set up the font size of the web view
		browser.setFontScale(0.9);
		// Set the User-Agent HTTP Header
		web_Engine.setUserAgent("E-PUB, Version-> Platinum - E-PUB/E-Book 1.0");
		// When user right click then disble the menu options, so set it false instead of true
		browser.setContextMenuEnabled(false);
		
		/**
		 * Setup the progress bar, where whenever the page load then progress bar display the loading process.
		 */
		// Create an object of the progress bar
		loadingProcess = new ProgressBar();
		// Set the position of the progress bar
		loadingProcess.setTranslateX(85); loadingProcess.setTranslateY(480);
		// Set the width and height of the progress bar
		loadingProcess.setMinHeight(30); loadingProcess.setMinWidth(1550);
		
		// Load the page
		work = web_Engine.getLoadWorker();
		/**
		 * Setup the Label 
		 */
		// Create an object of the Label
		status = new Label();
		// Set the style of the label
		status.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the position of the text
		status.setTranslateX(10); status.setTranslateY(480);
		// Set the color of the label
		status.setTextFill(Gradient_Effects.omega);
		
		/**
		 * Setup the progress bar in order to display the progress when the page start loading
		 */
		work.stateProperty().addListener(new ChangeListener<State>()
				{
			public void changed(ObservableValue<? extends State> observe, State omegaPastState, State omegaFutureState)
			{
				// Display text message when the page start loading
				status.setText("Loading Progress: " + omegaFutureState.toString());
				// If the page loading success then perform if block of code
				if(omegaFutureState == Worker.State.SUCCEEDED)
				{
					// Set the title in order to get the location with the help of web engine
					EPUB_User_Interface.searchBar.setText(web_Engine.getLocation());
					// Disable the progress bar when page stop loading
					loadingProcess.setVisible(false);
					// Hide the text after the task is done
					status.setVisible(false);
				}
				else if(omegaFutureState == Worker.State.RUNNING)
				{
					// Display the progress bar when page is in loading state
					loadingProcess.setVisible(true);
					// Display the text when the page is in the loading state
					status.setVisible(true);
				}
				
				else if(omegaFutureState == Worker.State.FAILED)
				{
					// Display text if loading failed
					status.setText("Loading Failed!");
					/**
					 * Setup the alert window if loading failed at any case like Not connected with the internet or something
					 * else reason.
					 */
					Alert alertWindow = new Alert(AlertType.WARNING);
					// Set the dialog pane
					DialogPane dialog = alertWindow.getDialogPane();
					// Set the background of the alert window
					dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
					// Add the Effect on dialog
					dialog.setEffect(dropShadow);
					// Set the text color 
					dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
					// Set the title of the window
					alertWindow.setTitle("Loading Error");
					// Set the header text
					alertWindow.setHeaderText("Loading Failed!");
					// Set the message for the user in brief
					alertWindow.setContentText("Please, check your internet connection!");
					// Create an object of the Stage and set the icon onto the alert window
					alertStage = (Stage) alertWindow.getDialogPane().getScene().getWindow();
					// Set the image as an window icon
					alertStage.getIcons().add(new Image(ALERT_ICON));
					// Set the height of the alert window
					alertWindow.getDialogPane().setMinHeight(200);
					// Set the width of the alert window
					alertWindow.getDialogPane().setMinWidth(500);
					// Display alert window
					alertWindow.showAndWait();
				}
			}
				});
		
		// Bind the progress of Progress bar with the Worker progress property
		loadingProcess.progressProperty().bind(work.progressProperty());
		
	}

	
}

