package EPUB_OMEGA;

import EPUB_PROS.EPUB_MAIN;
import EPUB_PROS.EPUB_User_Interface;
import EPUB_PROS.Gradient_Effects;
import EPUB_PROS.Too_Verti;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBoxBuilder;
import javafx.scene.layout.VBoxBuilder;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 * 
 * @author Shane
 * 07-04-2019, Sunday
 * The purpose to create this class is to prepare the Navi Drawer features or add some functions to perform
 * some task like to display books in the form of grid view
 */
@SuppressWarnings("deprecation")
public class Navi_Drawer_Features 
{
	/**
	 * Define the objects and variables globally in order to access from another class according to their specifiers.
	 */
	private static Button homeNavi;
	private static Image homeImg, booksImg;
	private static ImageView homeView, booksView;
	private static DropShadow navi_Effect;
	private static ScrollPane scrollPane;
	private static Button furiousBook, furiousLab;
	public static Button omegaBook;
	public static Button omegaLab;
	public static Button gammaBoo;
	private static Button gammaLab;
	private static Button alphaBook;
	private static Button alphaLab;
	private static Button silverHawk;
	private static Button silverLab;
	private static Button booksSection;
	private static Button sdCR;
	private static Image betaBook, gammaBook, gammaImg, alphaImg, silverImg;
	private static ImageView betaView, gammaView, gammaViews, alphaView, silverView;
	private static FlowPane flowPane;
	private static DropShadow dropShadow;
	
	
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXX       Setup button to display number of books in Grid view                XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	public static void furious_Navi_Drawer()
	{
		
		/**
		 * Call the gradient method
		 */
		Gradient_Effects.oMega();
		
		// Create an object of the image in order to access the image and setup as an icon
		homeImg = new Image(Navi_Drawer_Features.class.getResourceAsStream("/Home.png"));
		// Set the icon at the image view to view an image
		homeView = new ImageView(homeImg);
		// Set the size of the icon
		homeView.setFitHeight(35); homeView.setFitWidth(40);
		
		// Create an object of the books section button
		sdCR = new Button("SD CR");
		// Set the font size of the button
		sdCR.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 26));
		// Set the position of the button
		sdCR.setTranslateX(-8); sdCR.setTranslateY(-710);
		// Hide the background of the button
		sdCR.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		sdCR.setStyle("-fx-background-insets: 40,40,40,40;");
		
		/**
		 * Setup Mouse Hover Effect on Home Button
		 */
		sdCR.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				sdCR.setEffect(EPUB_User_Interface.shadowEffect);
				// Set the background color on hover
				sdCR.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		sdCR.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				sdCR.setEffect(null);
				// Disable background color on hovor end
				sdCR.setStyle("-fx-background-color: transparent;");
			}
				});
		
		/**
		 * Event handling of the home button, get back to home if click onto the home button
		 */
		sdCR.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent homeEvent)
			{
				Web_View.web_Engine.load("https://www.carterradley.com/");
				// Play sound
				EPUB_User_Interface.clickAud.play();
			}
				});
		
		// Create an object of the books section button
		homeNavi = new Button("Home", homeView);
		// Set the font size of the button
		homeNavi.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 26));
		// Set the position of the button
		homeNavi.setTranslateX(-8); homeNavi.setTranslateY(-710);
		// Hide the background of the button
		homeNavi.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		homeNavi.setStyle("-fx-background-insets: 40,40,40,40;");
		
		/**
		 * Setup Mouse Hover Effect on Home Button
		 */
		homeNavi.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				homeNavi.setEffect(EPUB_User_Interface.shadowEffect);
				// Set the background color on hover
				homeNavi.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		homeNavi.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				homeNavi.setEffect(null);
				// Disable background color on hovor end
				homeNavi.setStyle("-fx-background-color: transparent;");
			}
				});
		/**
		 * Setup the button in order to display the number of books.
		 */
		// Create an object of the image in order to access the image and setup as an icon
		booksImg = new Image(Navi_Drawer_Features.class.getResourceAsStream("/Home.png"));
		// Set the icon at the image view to view an image
		booksView = new ImageView(booksImg);
		// Set the size of the icon
		booksView.setFitHeight(35); booksView.setFitWidth(40);
		
		// Create an object of the books section button
		booksSection = new Button("Books Section", booksView);
		// Set the font size of the button
		booksSection.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Set the position of the button
		booksSection.setTranslateX(-2); booksSection.setTranslateY(-710);
		// Hide the background of the button
		booksSection.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		booksSection.setStyle("-fx-background-insets: 40,40,40,40;");
		
		// Create an object of the Drop shadow effect
		navi_Effect = new DropShadow();
		
		/**
		 * Hover effect on to the button
		 */
		homeNavi.addEventHandler(MouseEvent.MOUSE_ENTERED,new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent homeEvent)
			{
				// Set the effect on hover
				homeNavi.setEffect(navi_Effect);
				// Set the text color on hover
				homeNavi.setTextFill(Gradient_Effects.omegaRedEffect);
			}
				});
		
		homeNavi.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent homeEvent)
			{
				// Disable effect
				homeNavi.setEffect(null);
				// Set the color on hover end
				homeNavi.setTextFill(Gradient_Effects.omega);
			}
				});
		
		
		/**
		 * Hover effect on to the button
		 */
		booksSection.addEventHandler(MouseEvent.MOUSE_ENTERED,new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent homeEvent)
			{
				// Set the effect on hover
				booksSection.setEffect(navi_Effect);
				// Set the text color on hover
				booksSection.setTextFill(Gradient_Effects.omegaRedEffect);
				// Set the background color on hover
				booksSection.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		booksSection.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent homeEvent)
			{
				// Disable effect
				booksSection.setEffect(null);
				// Set the color on hover end
				booksSection.setTextFill(Gradient_Effects.omega);
				// Disable background color on hovor end
				booksSection.setStyle("-fx-background-color: transparent;");
			}
				});
		
		// Create an object of the drop shadow
		dropShadow = new DropShadow();
		/**
		 * Setup the Grid View to setup the number of books
		 */
		// Create an object of the scroll pane
		scrollPane = new ScrollPane();
		// Set the scroll bar horizontally and display when required
		scrollPane.setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
		// Set the scroll bar vertically and display when required
		scrollPane.setVbarPolicy(ScrollBarPolicy.AS_NEEDED);
		// Set the size of the scroll pane
		scrollPane.setMinWidth(1555); scrollPane.setMaxHeight(960);
		// Set the position of the scroll pane
		scrollPane.setTranslateY(30);
		// Set the padding of the scroll pane
		scrollPane.setPadding(new Insets(30));
		// Set the border of the scroll pane
		scrollPane.setStyle(" -fx-background: rgb(80,80,80);-fx-border-width: 5;"
				+ "-fx-padding: 15; -fx-border-color: linear-gradient(to top,#E74C3C, #F1C40F );"
				+ "-fx-font-size: 20px;");
		scrollPane.getStylesheets().add("ab.css");
		
		/**
		 * Setup the One grid item
		 */
		// Create an object of the image in order to access the image to setup the icon
		betaBook = new Image(Navi_Drawer_Features.class.getResourceAsStream("/pubg.jpg"));
		// Create an object of the Image View to view an image
		betaView = new ImageView(betaBook);
		// Set the size of the book image
		betaView.setFitWidth(400); betaView.setFitHeight(350);
		
		// Create an object of the book
		furiousBook = new Button("", betaView);
		// Hide the background of the button
		furiousBook.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		/**
		 * Setup hover effect
		 */
		furiousBook.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// When mouse hover then set the opacity 
				betaView.setOpacity(0.3);

			}
				});
		
		furiousBook.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// When mouse away then setup normal opacity
				betaView.setOpacity(1);
			}
				});
		
		// Create an object of the book
		furiousLab = new Button("Snake in the Eagle Shadow");
		// Set the positon of the button
		furiousLab.setTranslateY(230); furiousLab.setTranslateX(-424);
		// Set the font size of the button
		furiousLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 28));
		// Set the color of the text
		furiousLab.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		furiousLab.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		/**
		 * Setup hover effect
		 */
		furiousLab.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// setup the hover effect
				furiousLab.setEffect(dropShadow);
				// Set the background color on hover
				furiousLab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		furiousLab.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the hover effect
				furiousLab.setEffect(null);
				// Disable background color on hovor end
				furiousLab.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
				
			}
				});
		// Set the position of the button
		/**
		 * Second grid item
		 */
		// Create an object of the image and access the icon
		gammaBook = new Image(Navi_Drawer_Features.class.getResourceAsStream("/AI.jpg"));
		// Create an object of the image view to setup the icon
		gammaView = new ImageView(gammaBook);
		// Set the size of the book
		gammaView.setFitWidth(400); gammaView.setFitHeight(350);
		
		// Create an object of the button
		omegaBook = new Button("", gammaView);
		// Set the position of the button
		omegaBook.setTranslateX(-300); omegaBook.setTranslateY(-2);
		// Hide the background of the button
		omegaBook.setStyle("-fx-background-insets: 40, 40, 40, 40;");

		/**
		 * Setup hover effect
		 */
		omegaBook.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// When mouse hover then set the opacity 
				gammaView.setOpacity(0.3);
			}
				});
		
		omegaBook.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// When mouse away then setup normal opacity
				gammaView.setOpacity(1);
			}
				});
		
		
		// Create an object of the book
		omegaLab = new Button("Cuando Me Enamoro");
		// Set the positon of the button
		omegaLab.setTranslateY(-130); omegaLab.setTranslateX(580);
		// Set the font size of the button
		omegaLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 28));
		// Set the color of the text
		omegaLab.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		omegaLab.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		/**
		 * Setup hover effect
		 */
		omegaLab.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// setup the hover effect
				omegaLab.setEffect(dropShadow);
				// Set the background color on hover
				omegaLab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		omegaLab.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the hover effect
				omegaLab.setEffect(null);
				// Disable background color on hovor end
				omegaLab.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
			}
				});
		
		/**
		 * Third book setup
		 */
		// Create an object of the Image in order to access the image to put as an icon
		gammaImg = new Image(Navi_Drawer_Features.class.getResourceAsStream("/incidious.jpg"));
		// Create an object of the image view in order to view an image
		gammaViews = new ImageView(gammaImg);
		// Set the size of the image
		gammaViews.setFitWidth(400); gammaViews.setFitHeight(350);
		
		// Create an object of the button
		gammaBoo = new Button("", gammaViews);
		// Set the position of the button
		gammaBoo.setTranslateX(710); gammaBoo.setTranslateY(-360);
		// Hide the background of the button
		gammaBoo.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		

		/**
		 * Setup hover effect
		 */
		gammaBoo.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// When mouse hover then set the opacity 
				gammaViews.setOpacity(0.3);
			}
				});
		
		gammaBoo.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// When mouse away then setup normal opacity
				gammaViews.setOpacity(1);
			}
				});
		
		// Create an object of the book
		gammaLab = new Button("Privet");
		// Set the positon of the button
		gammaLab.setTranslateY(-130); gammaLab.setTranslateX(450);
		// Set the font size of the button
		gammaLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 28));
		// Set the color of the text
		gammaLab.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		gammaLab.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		
		/**
		 * Setup hover effect
		 */
		gammaLab.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// setup the hover effect
				gammaLab.setEffect(dropShadow);
				// Set the background color on hover
				gammaLab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		gammaLab.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the hover effect
				gammaLab.setEffect(null);
				// Disable background color on hovor end
				gammaLab.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
			}
				});
		/**
		 * Set up the fourth book
		 */
		// Create an object of the Image in order to access the image
		alphaImg = new Image(Navi_Drawer_Features.class.getResourceAsStream("/shinchan.jpg"));
		// Create an object of the image view to view an image
		alphaView = new ImageView(alphaImg);
		// Set the size of the Image
		alphaView.setFitWidth(400); alphaView.setFitHeight(350);
		
		// Create an object of the book button
		alphaBook = new Button("", alphaView);
		// Set the position of the button
		alphaBook.setTranslateY(100); alphaBook.setTranslateX(-840);
		// Hide the background of the button
		alphaBook.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		/**
		 * Setup hover effect
		 */
		alphaBook.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// When mouse hover then set the opacity 
				alphaView.setOpacity(0.3);
			}
				});
		
		alphaBook.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// When mouse away then setup normal opacity
				alphaView.setOpacity(1);
			}
				});
		
		// Create an object of the book
		alphaLab = new Button("Corazon");
		// Set the positon of the button
		alphaLab.setTranslateY(-30); alphaLab.setTranslateX(110);
		// Set the font size of the button
		alphaLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 28));
		// Set the color of the text
		alphaLab.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		alphaLab.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		
		/**
		 * Setup hover effect
		 */
		alphaLab.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// setup the hover effect
				alphaLab.setEffect(dropShadow);
				// Set the background color on hover
				alphaLab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		alphaLab.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the hover effect
				alphaLab.setEffect(null);
				// Disable background color on hovor end
				alphaLab.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
			}
				});
		/**
		 * Set up the fifth book
		 */
		// Create an object of the Image in order to access the image
		silverImg = new Image(Navi_Drawer_Features.class.getResourceAsStream("/AI_Book.jpg"));
		// Create an object of the image view to view an image
		silverView = new ImageView(silverImg);
		// Set the size of the Image
		silverView.setFitWidth(400); silverView.setFitHeight(350);
		
		// Create an object of the book button
		silverHawk = new Button("", silverView);
		// Set the position of the button
		silverHawk.setTranslateX(370); silverHawk.setTranslateY(-260);
		// Hide the background of the button
		silverHawk.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		

		/**
		 * Setup hover effect
		 */
		silverHawk.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// When mouse hover then set the opacity 
				silverView.setOpacity(0.3);
			}
				});
		
		silverHawk.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// When mouse away then setup normal opacity
				silverView.setOpacity(1);
			}
				});
		
		// Create an object of the book
		silverLab = new Button("Gotcha!");
		// Set the positon of the button
		silverLab.setTranslateY(-30); silverLab.setTranslateX(70);
		// Set the font size of the button
		silverLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 28));
		// Set the color of the text
		silverLab.setTextFill(Gradient_Effects.omega);
		// Hide the background of the button
		silverLab.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		/**
		 * Setup hover effect
		 */
		silverLab.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent alphaEvent)
			{
				// setup the hover effect
				silverLab.setEffect(dropShadow);
				// Set the background color on hover
				silverLab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		silverLab.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the hover effect
				silverLab.setEffect(null);
				// Disable background color on hovor end
				silverLab.setStyle("-fx-background-color: transparent; -fx-background-radius: 30;");
			}
				});
		
		// Create an object of the grid pane and pass the button objects in ordre to setup at the scroll pane
		flowPane = new FlowPane();
		// Set the size of the grid pane
		flowPane.setMinWidth(1400);
		// Group the buttons children at the grid pane
		flowPane.getChildren().addAll(furiousBook, furiousLab, omegaBook, omegaLab, gammaBoo, gammaLab, alphaBook, alphaLab,
				                      silverHawk, silverLab);
		// Set the grid pane at the scrollpane
		scrollPane.setContent(flowPane);
		
		
		
		/**
		 * Event handling of the home button and when user click upon it then new scene open and user able to see
		 *  the number of books in grid view 
		 */
		
		booksSection.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent homeEvent)
			{
				// Setup new scene when click onto the home button
				EPUB_MAIN.stg.setScene(EPUB_MAIN.homeScene);
				// Group the children together and access the backgroundImage method from Background_Image class.
				EPUB_MAIN.homePane.getChildren().addAll(HBoxBuilder.create().spacing(10).children(
						VBoxBuilder.create().spacing(10).children(
								EPUB_MAIN.naviDrawer.hideAndSeekDrawer(), EPUB_MAIN.naviDrawer).build(), scrollPane)
						        .build(), EPUB_User_Interface.gammaBar,EPUB_User_Interface.omegaBar, Too_Verti.alphaBar,
						        EPUB_User_Interface.notesPane);
				
				// Set the visibility of hamburger icon false
				EPUB_User_Interface.hambMenu.setDisable(true);
				// Disable the search field
				EPUB_User_Interface.searchBar.setDisable(true);
				
				
			}
				});
		
		
		/**
		 * Event handling of the home button, get back to home if click onto the home button
		 */
		homeNavi.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent homeEvent)
			{
				// Get back to the home when user click onto the home button
				EPUB_MAIN.stg.setScene(EPUB_MAIN.scene1);
				// Group the children together and access the backgroundImage method from Background_Image class.
				EPUB_MAIN.root.getChildren().addAll(HBoxBuilder.create().spacing(10).children(
						VBoxBuilder.create().spacing(10).children(
								EPUB_MAIN.naviDrawer.hideAndSeekDrawer(), EPUB_MAIN.naviDrawer).build(), EPUB_User_Interface.tabPane)
						        .build(),EPUB_User_Interface.omegaBar, EPUB_User_Interface.gammaBar,Too_Verti.alphaBar,
						        /*Web_View.loadingProcess, Web_View.status,*/ EPUB_User_Interface.notesPane);
				// Set the visibility of hamburger icon false
				EPUB_User_Interface.hambMenu.setDisable(false);
				// Disable the search field
				EPUB_User_Interface.searchBar.setDisable(false);
			}
				});
		
		
		// Add the button at the navigation drawer
		EPUB_MAIN.naviDrawer.getChildren().addAll(sdCR,homeNavi, booksSection);
	}
}
