package EPUB_OMEGA;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

import EPUB_PROS.EPUB_MAIN;
import EPUB_PROS.EPUB_User_Interface;
import EPUB_PROS.Gradient_Effects;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

/**
 * 
 * @author Shane
 * 09-04-2019, Monday
 * Create this class is to setup the mehod to bookmark the url in list view
 *
 */
public class Bookmark_View 
{
	/**
	 * Define the variables and objects globally in order to access from another classes as per their specifiers.
	 */
	// Define the object of the TableView and typecast into the URL_LINK user defined class
	public static TableView<URL_LINK> bookmark_Table_View;
	// Define the object of Observable list and typecase into the URL_LINK user defined class
	public static ObservableList<URL_LINK> bookmark_List;
	public static Button update, visit, delete;
	private static TableColumn column;
	public static TextField editField;
	public static String str;
	private static File readBookmarkFile, writeIntoBookmarkFile;
	private static Writer writeIntoFile;
	public static HBox hBox;
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                Setup Bookmark list view method                            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	/**
	 * Setup the bookmark method to bookmark the URL links in order to visit that link in future.
	 * Here, if the user feels the link is important then user click onto the bookmark icon and save the link at the list view.
	 */
	public static void bookmark_List()
	{
		// Create the object of the table view
		bookmark_Table_View = new TableView<URL_LINK>();
		// Set editable true
		bookmark_Table_View.setEditable(true);
		// Set the style of the list view
		bookmark_Table_View.setStyle("-fx-control-inner-background: #2C3E50; -fx-highlight-fill:#E74C3C;"
						+ "-fx-highlight-text-fill: #FDFEFE; -fx-border-color: linear-gradient(to bottom right,#E74C3C 100%,#F1C40F 10%);"
						+ "-fx-border-width: 5; -fx-font-size: 20;");
		// Create the object of observable list and create some demo data
		bookmark_List = FXCollections.observableArrayList(
						/**
						 * Here, can add the URL links or anything which one want to display at tableview
						 * like below sample   new URL_LINK("https://mail.google.com/mail/u/0/#inbox")
						 */
						);
		/**
		 * Method calling
		 */
		Gradient_Effects.oMega();
		// Set the position of the table
		bookmark_Table_View.setTranslateX(20); 
		// Set the size of the bookmark table 
		bookmark_Table_View.setMinHeight(800);
		bookmark_Table_View.setMinWidth(1262);
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Setup Visit button               XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the visit button
		visit = new Button();
		// Set the text of the button
		visit.setText("VISIT");
		// Set the position of the button
		visit.setLayoutX(1400); visit.setLayoutY(20);
		// Set the text color of the button
		visit.setTextFill(Gradient_Effects.omega);
		// Set the size of the button
		visit.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Set the background color of the button
		visit.setStyle("-fx-background-color: blue; -fx-background-radius: 30;");
		// Set the size of the button
		visit.setMinWidth(150);
		
		/**
		 * Event handling of the visit button
		 */
		EventHandler<ActionEvent> visitEvent = new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent actionEvent)
			{
/*				URL_LINK getString =(URL_LINK)tableView.getSelectionModel().getSelectedItem();
				str = (String)getString.toString();
				System.out.println(str);
				UI_EPUB.bookmarkField.setText(str);*/
				Web_View.web_Engine.load(EPUB_User_Interface.searchBar.getText().toString());
				// play sound when click on the button
				//UI_EPUB.pingAud.play();
				
			}
				};
		visit.setOnAction(visitEvent);
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Setup Delete button to delete the row     XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the Delete button
		delete = new Button();
		// Set the text of the button
		delete.setText("DELETE");
		// Set the position of the button
		delete.setLayoutX(1400); delete.setLayoutY(90);
		// Set the text color of the button
		delete.setTextFill(Gradient_Effects.elBano);
		// Set the size of the text
		delete.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC,22));
		// Set up the border
		delete.setStyle("-fx-background-radius: 30; -fx-background-color: red;");
		// Set the size of the button
		delete.setMinWidth(150);
		/**
		 * Event handling of delete button
		 */
		EventHandler<ActionEvent> deleteEvent = new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent actionEvent)
			{
				// play sound when click on the button
				//UI_EPUB.pingAud.play();
				// Get the selected row 
				int stringRow = bookmark_Table_View.getSelectionModel().getSelectedIndex();
				if(stringRow <= -1)
				{
					return;
				}
				bookmark_List.remove(stringRow);
				if(bookmark_Table_View.getItems().size() == 0)
				{
					delete.setDisable(true);
					return;
				}
				
				if(stringRow != 0)
				{
					stringRow = stringRow -1;
				}
				bookmark_Table_View.requestFocus();
				bookmark_Table_View.getSelectionModel().select(stringRow);
				bookmark_Table_View.getFocusModel().focus(stringRow);
			}
				};
				// Set the event on button delete
				delete.setOnAction(deleteEvent);
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Setup Table Bookmark Lists       XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the table column
		column = new TableColumn("URL LIST");
		// Setup content of the Table
		column.setCellValueFactory(new PropertyValueFactory<URL_LINK, String>("uRLBookmarkList"));
		// Set the size of the column
		column.prefWidthProperty().bind(bookmark_Table_View.widthProperty().multiply(1));

		
        
		// Set items of the list into the table
		bookmark_Table_View.setItems(bookmark_List);
		// Set data into the column
		bookmark_Table_View.getColumns().add(column);
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Setup Editable and update data   XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the textfield 
		editField = new TextField();
		// Set the width of the field
		editField.setPrefWidth(150);
		// Set the position of the field
		editField.setTranslateX(100);
		editField.setTranslateY(358);
		// Set the size of the edit field
		editField.setMinWidth(500);
		// Style the border of the field
		editField.setStyle("-fx-background-radius: 30;");
		//  Set the size of the field and text style
		editField.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the title in order to get the location with the help of web engine
		editField.setText(Web_View.web_Engine.getLocation());
		
		// Which item or row user select then user would be able to edit data
		bookmark_Table_View.getSelectionModel().selectedItemProperty().addListener((obs, ov, nv) ->
		{
			if(nv != null)
			{
				// Get the string into the edit field
				editField.setText(nv.urlLink.get());
				// Get string into the bookmark field
				EPUB_User_Interface.searchBar.setText(nv.urlLink.get());
				editField.setText(Web_View.web_Engine.getLocation());
			}
		});
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Setup update button to update the data      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		// Create the object of the button
		update = new Button();
		// Set the text of the button
		update.setText("UPDATE");
		// Set the size of the button
		update.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Style the border of the button
		update.setStyle("-fx-background-radius: 30; -fx-background-color: "
				+ "linear-gradient(to top right, rgba(9,30,61,1) 45.3%, rgba(95,123,190,1) 279% );");
		update.setTranslateY(358);
		// Set the position of the button
		update.setTranslateX(120);
		// Set the text color of the button
		update.setTextFill(Gradient_Effects.omegaRedEffect);
		
		/**
		 * Event handling of update button
		 */
		update.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{
				// play sound when click on the button
				//UI_EPUB.pingAud.play();
				// Create the object of the URL_LINK user defined class then store the selected item or bookmark list row or single item
				URL_LINK bookmarkItem = bookmark_Table_View.getSelectionModel().getSelectedItem();
				// Set the item
				bookmarkItem.urlLink.set(editField.getText());
				bookmark_Table_View.toFront();
				// Create the object of the url link class
				URL_LINK addData = new URL_LINK("");
				// Add data 
				bookmark_List.add(addData);
			
				// Get the size of the list and reduce one from them
				int row = bookmark_List.size() -1;
				// Get focus at the table or may say enter at the table 
				bookmark_Table_View.requestFocus();
				// Get the selected row
				bookmark_Table_View.getSelectionModel().select(row);
				bookmark_Table_View.getFocusModel().focus(row);
				// Set the write file to null initially
				writeIntoFile =null;
				// Handle the file using try and catch
				try
				{
					// Create the object of file and access the file to write into it
					writeIntoBookmarkFile = new File("Bookmark.csv");
					// Write into the file which one we accessed using file
					writeIntoFile = new BufferedWriter(new FileWriter(writeIntoBookmarkFile));
					// Setup to write in to the file using some conditions
					for(URL_LINK urlLink : bookmark_List)
					{
						// Get the data and then go to next line in order to save data at next line
						String link = urlLink.getURLBookmarkList() + "\n";
						// Write the data into the file
						writeIntoFile.write(link);
						
					}
				}
				catch(Exception exception)
				{
					// play audio
					//UI_EPUB.omegaAud.play();
					// Display error if file not found
					Alert alert = new Alert(AlertType.WARNING);
					DialogPane dp = alert.getDialogPane();
					dp.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
					dp.setEffect(EPUB_User_Interface.shadowEffect);
					dp.setStyle("-fx-font-weight: bold; -fx-border-color: red;");
					alert.setTitle("Status");
					alert.setHeaderText("File Not Found");
					alert.setContentText("Sorry, File not found.");
					alert.showAndWait();
				}
				finally
				{
					try
					{
						// Flush the file
						writeIntoFile.flush();
					}
					catch(IOException inputOutputexception)
					{
						inputOutputexception.printStackTrace();
					}
					try
					{
						// Close the file
						writeIntoFile.close();
					}
					catch(IOException inputOutputException)
					{
						inputOutputException.printStackTrace();
					}
				}
			}
		
				});
		
		/**
		 * Create the Object of HBox in order to setup content horizontally
		 */
		hBox= new HBox();
		// Add data into the HBox
		hBox.getChildren().addAll(editField, update);
		// Set the position 
		hBox.setLayoutX(20); hBox.setLayoutY(480);

		// Event handling 
		bookmark_Table_View.setOnMouseClicked(new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				if(mouseEvent.getClickCount()==2)
				{
					//StackPane.setMargin(hbox, new Insets(mouseEvent.getSceneY(), 0, 0, 0));
					// Set button infront of the text field
					hBox.toFront();
				}
			}
				});
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Load the text file data into the table view               XXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the file and access the file 
		readBookmarkFile = new File("Bookmark.csv");
		// Read the file if exits else display error
		if( readBookmarkFile != null)
		{
			// Read the file
			readBookmarkFile(readBookmarkFile);
		}
		
		
		
	}
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX        Setup Method to read the file    XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	
	 private static String readBookmarkFile(File data)
	 {
		 
		 // Create an object of the String buffer
		 StringBuffer buffer = new StringBuffer();
		 // Create an object of the File reader to read the file
		 FileReader readBookmarkFile=null;
		 try 
		 {
		    	readBookmarkFile = new FileReader(data);
		 } 
		 catch (FileNotFoundException e) 
		 {
		    	/**
			  * Alert Window
			  */
		 }
		 // Create the object of the buffere reader and set to null
	     BufferedReader bufReader = null;
	     // Setup delimeter
	     String fieldDelimeter = ",";
	      
	    bufReader = new BufferedReader(readBookmarkFile);
	     try 
	     {
	    	 // Read the file which one we accessed
             bufReader = new BufferedReader(new FileReader(data));
          
             // Create the String variable to read the line 
             String text;
             // Read the line until the file is not null
             while ((text = bufReader.readLine()) != null) 
             {
            	 // Create the array 
                 String[] fields = text.split(fieldDelimeter, -1);
                 
                 URL_LINK urlLink = new URL_LINK(fields[0]);
                 // Add the data into file
                 bookmark_List.add(urlLink);
             }        
	 
         } 
      catch (FileNotFoundException ex) 
      {
          Logger.getLogger(EPUB_MAIN.class.getName()).log(Level.SEVERE, null, ex);
      } 
      catch (IOException ex) 
      {
         Logger.getLogger(EPUB_MAIN.class.getName()).log(Level.SEVERE, null, ex);
      } 
      try {
		bufReader.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	         
      return buffer.toString();
  }
	
	

}
