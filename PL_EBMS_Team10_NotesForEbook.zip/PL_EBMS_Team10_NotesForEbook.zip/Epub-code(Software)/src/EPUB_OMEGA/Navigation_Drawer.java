package EPUB_OMEGA;

import EPUB_PROS.EPUB_User_Interface;
import javafx.animation.Animation;
import javafx.animation.Transition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

/**
 * 
 * @author Shane
 * 01-04-2019, Monday
 * The purspose to create this class is to prepare or setup the Side_Bar or may say Navigation Drawer, where we can 
 * display the list of books or anything else.
 */
public class Navigation_Drawer extends VBox
{

	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXX          Define objects globally in order to access from other class      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXX          according to their specifiers.                                   XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	private Button hamburger;
	private Image hamburgerImg, leftArrowImg;
	private ImageView hamburgerView, leftArrowView;
	
	/**
	 * Setup a button in order to hide and display the Navigation Drawer
	 */
	public Button hideAndSeekDrawer()
	{
		return hamburger;
	}
	
	/**
	 * Create the constructor of the current class
	 */
	public Navigation_Drawer(BorderPane drawerPane)
	{
		 /**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                   Setup Navigation open close button                       XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		 /**
		  * Setup the Hamburger Icon
		  */
		// Create an object of the Image and access the image in order to setup the image as icon
		hamburgerImg = new Image(getClass().getResourceAsStream("/hamburger.png"));
		// Create an object of the Image view and setup the image as an icon
		hamburgerView = new ImageView(hamburgerImg);
		// Set the height and width of the image which behave as an icon
		hamburgerView.setFitHeight(50); hamburgerView.setFitWidth(50);
		
		/**
		 * Setup the Left Arrow Icon
		 */
		// Create an object of the image and acess image too
		leftArrowImg = new Image(Navigation_Drawer.class.getResourceAsStream("/leftArrow.png"));
		// Create an object of the Image view and set the image inside of it in order to view the icon
		leftArrowView = new ImageView(leftArrowImg);
		// Set the height and width of the icon
		leftArrowView.setFitHeight(50); leftArrowView.setFitWidth(50);
		
		/**
		 * Setup the icon of the button in order to hide and display the navigation drawer
		 */
		// Create an object of the Navigation hide and display button
		hamburger = new Button("", leftArrowView);
		// Set the position of the button
		hamburger.setTranslateY(8); 
		// Hide the background of the button
		hamburger.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		// Setup the background color of the navigation drawer
		setStyle("-fx-background-color: linear-gradient(to top, #0f0c29, #302b63, #24243e);"
		    	+ "-fx-padding: 15; -fx-border-color: linear-gradient(to top,#E74C3C, #F1C40F ); "
			    + "-fx-border-width: 5;");
		// Group the children of Node....
		getChildren().add(drawerPane);
		
		/**
		 * Setup the Event Action on to button in order to hide and display the Navigation Drawer
		 */
		EventHandler<ActionEvent> hamburgerEvent = new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent actionEvent)
			{
				 /**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 		 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                   Display Navigation Drawer                                XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
				/**
				 * Display the navigation drawer
				 */
				// Create the variable to store the width of the drawer
				final double naviBarWidth = getWidth();
		 		// Create an object of the Animation in order to setup the Navigation Drawer visible
				Animation displayNaviDrawer = new Transition()
						{
					{
						// Set the time in order to display Navigation drawer {Mean take some time to open the drawer}
						setCycleDuration(Duration.millis(290));
					}

					// Setup the calculation in order to display the drawer
					protected void interpolate(double iPolate)
					{
						// Create the double variable in order to store the calculation to display the Navigation Drawer
						final double displayNavi = naviBarWidth * iPolate;
						// Set the position
						setTranslateX(-naviBarWidth + displayNavi);
					}
						};
						
						/**
						 * Change the button icon when Navigation Drawer hide or display
						 */
						displayNaviDrawer.onFinishedProperty().set(new EventHandler<ActionEvent>()
								{
							public void handle(ActionEvent actionEvent)
							{
								// Display the left arrow icon when drawer open 
								hamburger.setGraphic(leftArrowView);
								// Set the position of the hamburger icon
								hamburger.setTranslateX(7);
								// Set the size of the TabPane in order to display at right position when user open navi drawer
								EPUB_User_Interface.tabPane.setMinHeight(100); EPUB_User_Interface.tabPane.setMinWidth(1200);
								// Set the position of the tabpane
								EPUB_User_Interface.tabPane.setTranslateX(1); 
								// Set the position of the browser
								Web_View.browser.setMinWidth(1570);
								// Set the position of the browser
								Web_View.browser.setTranslateX(1);
								// Set the size of the progress bar
								Web_View.loadingProcess.setMinWidth(1550);
								// Set the position of the progress bar
								Web_View.loadingProcess.setTranslateX(88);
							}
								});
						
						/**
						 * Hide the Navigation Drawer
						 */
						// Setup the animation in order to hide the Navigation Drawer
						Animation hideNaviDrawer = new Transition()
								{
							{
								// Set the time to hide the navigation drawer { Mean it will take few milliseconds to hide the Navigation Drawer.
								setCycleDuration(Duration.millis(290));
							}
							protected void interpolate(double iPolate)
							{
								// Create the variable to store the calculation in order to hide the navigation drawer
								final double naviWidth = naviBarWidth * (1.0 - iPolate);
								// Set the position
								setTranslateX(-naviBarWidth + naviWidth);
							}
								};
						
								/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
						 		 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                   Hide the Navigation Drawer                               XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
						 		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
						 		/**
						 		 * Setup the Event action to hide the navigation drawer
						 		 */
								hideNaviDrawer.onFinishedProperty().set(new EventHandler<ActionEvent>()
										{
									public void handle(ActionEvent event)
									{
										// Hide the Navigation Drawer
										setVisible(false);
										// Display the hamburger icon when drawer hidden
										hamburger.setGraphic(hamburgerView);
										// Set the position of the hamburger icon
										hamburger.setTranslateX(20);
										// Set the size of the tab pane when navigation drawer close
										EPUB_User_Interface.tabPane.setMinWidth(1700);
										// set the position
										EPUB_User_Interface.tabPane.setTranslateX(-110);
										// Set the size of the web browser
										Web_View.browser.setMinWidth(1700);
										// Set the position
										Web_View.browser.setTranslateX(-110);
										// Set the size of the progress bar
										Web_View.loadingProcess.setMinWidth(1680);
										// Set the position of the progress bar
										Web_View.loadingProcess.setTranslateX(20);
										
										
									}
										});
						/**
						 * Implement the logic to check whether the Navigation Drawer is open or close then apply some actions
						 */
						if(displayNaviDrawer.statusProperty().get() == Animation.Status.STOPPED &&
								hideNaviDrawer.statusProperty().get() == Animation.Status.STOPPED)
						{
							// IF Navigation Drawer not visible then display the Navigation drawer in order to click over the button
							if(!isVisible())
							{
								// Set the visibility true in order to see the navigation drawer
								setVisible(true);
								// Open the drawer with animation where it take few milliseconds to open the drawer
								displayNaviDrawer.play();
							}
							else
							{
								// If Navigation Drawer is visible and want to hide then click over the button to hide the navigation drawer.
								// Hide the navigation drawer with animation where it take few milliseconds to hide the Navigation drawer
								hideNaviDrawer.play();
							}
						}
						
			}
				};
				
		// Set the event onto the button
		hamburger.setOnAction(hamburgerEvent);
	}
	
}
