package EPUB_OMEGA;

import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class Splash_Screen extends Application
{
	// Get the URL of the image which one want to display as a welcome screen

	private Stage welcomeStage;
	private Image splashImg;
	private ImageView splashView;
	private VBox welcomeBox;
	private Task<ObservableList<String>> task;
	private InitCompletionHandler completion;
	
	public void start(Stage stage)
	{
		task = new Task<ObservableList<String>>()
		{
	protected ObservableList<String> call() throws InterruptedException 
	{
		// Set the time how long want to display the welcome screen 
		Thread.sleep(5000);
		return null;
	}
		};
		
     // Create an object of the image and access the welcome image
     splashImg = new Image("pubg.jpg");
     // Set the image at the image view to view an image
     splashView = new ImageView(splashImg);
     // Create an object of the Virtual Box
     welcomeBox = new VBox();
     // Group the children together
     welcomeBox.getChildren().add(splashView);
     // Bind with thread and start the task
     new Thread(task).start();
     
     displaySplash(stage, task, () -> displayWindow());
		
	}
	private void displayWindow()
	{
		
	}
	public void displaySplash(Stage stage, Task<?> task, InitCompletionHandler 
			completion)
	{
		
	        
	}
	public interface InitCompletionHandler
	{
		void complete();
	}
	
	/**
	 * Launch the application
	 * 
	 */
	public static void main(String []args)
	{
		Application.launch(args);
	}
}
