import java.io.BufferedReader; 
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Notes_Main extends Application
{
	
	private Group root;
	private Scene sc;
	private TextArea notesArea;
	private Button save;
	private DropShadow dropShadow;
	
	public void start(Stage stage)
	{
		dropShadow = new DropShadow();
		root = new Group();
		sc = new Scene(root, 1400, 800, Color.rgb(40,  40,  40));
		notesArea= new TextArea();
		notesArea.setLayoutX(1090); notesArea.setLayoutY(100);
		notesArea.setMaxWidth(300); notesArea.setMinHeight(400);
		notesArea.setFont(Font.font("Helvetica",  FontPosture.ITALIC,18));
		notesArea.setStyle("-fx-background-color: linear-gradient(to bottom right, white 0%, red 100% );"
				+ "-fx-text-fill: #555A54;");
		
		save = new Button();
		save.setText("SAVE");
		save.setLayoutX(1090); save.setLayoutY(550);
		save.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		save.setStyle("-fx-background-radius: 30;");
		save.setStyle("-fx-background-color: #090a0c, linear-gradient(#38424b 0%, #1f2429 20%, #191d22 100%),"
				+ "linear-gradient(#20262b, #191d22), radial-gradient(center 50% 0%, radius 100%, "
				+ "rgba(114,131,148,0.9), rgba(255,255,255,0)); "
				+ "-fx-background-radius: 30;"
				+ "-fx-background-insets: 0,1,2,0;"
				+ "-fx-padding:10 20 10 20;");
		save.setMinWidth(300);
		save.setTextFill(Color.WHITE);
		/**
		 * Drop shadow effect on the text
		 */
		// When hover over the mouse 
		save.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Set effect on button or shadow effect
				save.setEffect(dropShadow);
				// Set color of the button
				save.setTextFill(Color.web("#F4D03F"));	
				// play sound when mouse hover over the button
				//bookmark.play();
			}
				});
		
		// When mouse exist over the button
		save.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Set the effect null
				save.setEffect(null);
				save.setTextFill(Color.WHITE);
				// Stop alarm when mouse away from button
				///clickAud.stop();
			}
				});
	    		
		notesArea.getStylesheets().add("ab.css");
		
		//FileChooser fc = new FileChooser();
		
		File file = new File("Bookmark.txt");
		//fc.showOpenDialog(stage);
		System.out.println(file.exists());
		System.out.println(file);
        if(file != null)
        {
            notesArea.setText(readData(file));
        }
		save.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{ 
				//FileChooser fcc = new FileChooser();
				File fila = new File("Bookmark.txt");//fcc.showOpenDialog(stage);
	            if(fila != null)
	            {
	                saveTextAreaData(notesArea.getText(), fila);
	            }
			}
				});
            
       
		
		root.getChildren().addAll(save, notesArea);
		stage.setScene(sc);
		stage.show();
	}
	private void saveTextAreaData(String data, File file)
	{
        try 
        {
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(data);
            fileWriter.close();
        } 
        catch (IOException ex) 
        {
            System.out.println("Sorry, File not Found!");
        }
          
    }

	 private String readData(File data)
	 {
	        StringBuilder buffer = new StringBuilder();
	        BufferedReader bufReader = null;
	         
	        try {
	 
	            bufReader = new BufferedReader(new FileReader(data));
	             
	            String text;
	            while ((text = bufReader.readLine()) != null) 
	            {
	                buffer.append(text);
	            }
	 
	        } 
	        catch (FileNotFoundException ex) 
	        {
	            Logger.getLogger(Notes_Main.class.getName()).log(Level.SEVERE, null, ex);
	        } 
	        catch (IOException ex) 
	        {
	            Logger.getLogger(Notes_Main.class.getName()).log(Level.SEVERE, null, ex);
	        } 
	        finally 
	        {
	            try 
	            {
	                bufReader.close();
	            } 
	            catch (IOException ex) 
	            {
	                Logger.getLogger(Notes_Main.class.getName()).log(Level.SEVERE, null, ex);
	            }
	        } 
	         
	        return buffer.toString();
	    }
	
	
	
	public static void main(String []args)
	{
		Application.launch(args);
	}
}