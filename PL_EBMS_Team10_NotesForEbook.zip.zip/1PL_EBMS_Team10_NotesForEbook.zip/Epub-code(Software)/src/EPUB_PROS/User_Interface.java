package EPUB_PROS;

import java.net.URL;

import EPUB_OMEGA.Splash_Screen;
import javafx.event.ActionEvent; 
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;


/**
 * 
 * @author Shane
 * 12-03-2019
 * The purpose to create this class to design the UI of the Application
 *
 */
public class User_Interface
{
	/**
	 * Define the objects here and used them inside the constructor
	 * Here, UI design for window or scene 1
	 * The purpose to define the objects globally is to allow the methods to get access within this class or out 
	 * of the class if it is set to public static.
	 */
	public static Text welcome_Text;
	public static Label userName, password;
	public static TextField user_Name_Field;
	public static PasswordField password_Field;
	public static Button login, register, clear;
	private DropShadow dropShadow;
	private Image clearImg;
	public static ImageView clearImgView;
	public static AudioClip welcomeBack;
	public static URL welcomeBackURL;
	
	
	// Constructor and inside of it we will design the UI of the application
	public User_Interface(Pane theRoot)
	{
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX                     Method Calling                                             XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Call the Gradient color
		Gradient_Effects.gradientBallEffect();
		Gradient_Effects.gradientRedEffect();
		
		/**
		 * Create the object of the Drop Shadow
		 */
		dropShadow = new DropShadow();
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX         SETUP VOICE OR AUDIO            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * Set up the Welcome back message when user login the window
		 */
		// Acess the welcome back sound
		welcomeBackURL = EPUB_User_Interface.class.getResource("/welcomeback.mp3");
		
		// Connect the sound with the audio player
		welcomeBack = new AudioClip(welcomeBackURL.toExternalForm());
		// Set the volume of the song or sound
		welcomeBack.setVolume(1);
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX               Set the Welcome Text and Implements Animation upon it            XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create the object of the text
		welcome_Text = new Text();
		// Set the text
		welcome_Text.setText("WELCOME");
		// Set the position of the text
		welcome_Text.setLayoutX(700); welcome_Text.setLayoutY(200);
		// Set the size and style of the text
		welcome_Text.setFont(Font.font("Helvetica",FontPosture.ITALIC,120));
		// Set the color of the text
		welcome_Text.setFill(Gradient_Effects.omegaRedEffect);
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX               Set Label and TextField                 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		// Create the object of the Label
		userName = new Label();
		// Set the text of the label
		userName.setText("USERNAME");
		// Set the style and size of the label
		userName.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 30));
		// Set the position of the label
		userName.setLayoutX(600); userName.setLayoutY(300);
		
		
		// Create the object of text field for username label
		user_Name_Field = new TextField();
		// Set the position of the field
		user_Name_Field.setLayoutX(800); user_Name_Field.setLayoutY(300);
		// Set the style of the text
		user_Name_Field.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the style of the field 
		user_Name_Field.setStyle("-fx-background-radius: 30;");
		// Give hint to the user what user need to do
		user_Name_Field.setPromptText("Enter your Name:");
		// Set the width of the field
		user_Name_Field.setMinWidth(350);
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX               Set the Label and Textfild to enter Password                     XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		// Create the object of label for password 
		password = new Label();
		// Set the text 
		password.setText("PASSWORD");
		// Set the style and size of the label
		password.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 30));
		// Set the position of the label
		password.setLayoutX(600); password.setLayoutY(400);
		
		
		// Create the object of password Field for password label
		password_Field= new PasswordField();
		// Set the position of the field
		password_Field.setLayoutX(800); password_Field.setLayoutY(400);
		// Set the style of the text
		password_Field.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));
		// Set the style of the field
		password_Field.setStyle("-fx-background-radius: 30;");
		// Give the hint to the user what user need to do
		password_Field.setPromptText("Enter your Password");
		// Set the width of the field
		password_Field.setMinWidth(350);
		

		// Call the Animation Ball method to display the ball on to the text
		Anim_Trans.animationBall();
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX               Setup the Login Button                                           XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		
		// Create the object of button
		login = new Button();
		// Set the text of the button
		login.setText("LOGIN");
		// Set the position of the button
		login.setLayoutX(800); login.setLayoutY(500);
		// Set the style of the border
		login.setStyle("-fx-background-color: #090a0c, linear-gradient(#38424b 0%, #1f2429 20%, #191d22 100%),"
				+ "linear-gradient(#20262b, #191d22), radial-gradient(center 50% 0%, radius 100%, "
				+ "rgba(114,131,148,0.9), rgba(255,255,255,0)); "
				+ "-fx-background-radius: 30;"
				+ "-fx-background-insets: 0,1,2,0;"
				+ "-fx-padding:10 20 10 20;");
		// Set the size and style of the button text
		login.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the text
		login.setTextFill(Color.WHITE);
		// Set the mininum width of the button
		login.setMinWidth(150);
		
		
		/**
		 * Setup hover effect on login button
		 */
		login.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Set the hover effect on button
				login.setEffect(dropShadow);
				// Change the color on hover
				login.setTextFill(Color.web("#F4D03F"));
			}
				});
		
		login.addEventHandler(MouseEvent.MOUSE_EXITED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// Disable the effect when hover doesn't happen
				login.setEffect(null);
				// Set the color of the text
				login.setTextFill(Color.WHITE);	
			}
				});
		
		/** 
		 * Call the zoomAnim animation method
		 */
		Anim_Trans.zoomAnim();
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX               Setup the Clear Button                                           XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * Setup image at button
		 */
		
		// Create the object of image and access the image
		clearImg= new Image("umbrella.png");
		// Set the Image at Imageview to view the image
		clearImgView = new ImageView(clearImg);
		// Set the width and height of the image
		clearImgView.setFitHeight(30); clearImgView.setFitWidth(30);
		clearImgView.setLayoutX(300); clearImgView.setLayoutY(200);
		/**
		 * Call the rotate animation method
		 */
		Anim_Trans.rotateImg();
		
		// Create the object of the clear button
		clear = new Button("CLEAR", clearImgView);
		// Set the text of the button
		clear.setText("CLEAR");
		// Set the size and style of the button
		clear.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the position of the button
		clear.setLayoutX(1040); clear.setLayoutY(500);
		// Set the style of the button
		clear.setStyle("-fx-background-color: #090a0c, linear-gradient(#38424b 0%, #1f2429 20%, #191d22 100%),"
				+ "linear-gradient(#20262b, #191d22), radial-gradient(center 50% 0%, radius 100%, "
				+ "rgba(114,131,148,0.9), rgba(255,255,255,0)); "
				+ "-fx-background-radius: 30;"
				+ "-fx-background-insets: 0,1,2,0;"
				+ "-fx-padding:10 20 10 20;");
		// Set the button text color
		clear.setTextFill(Color.WHITE);
		// Set the minimum width of the button
		clear.setMinWidth(120);
		
		/**
		 * Setup hover effect on button
		 */
		clear.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Set the hover effect on button
				clear.setEffect(dropShadow);
				// Change the color on hover
				clear.setTextFill(Color.web("#F4D03F"));
			}
				});
		clear.addEventHandler(MouseEvent.MOUSE_EXITED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Disable the effect when hover doesn't happen
				clear.setEffect(null);
				// Set the color of the text
				clear.setTextFill(Color.WHITE);	
			}
				});
		
		/**
		 * Event Handling of clear button
		 */
		clear.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent actionEvent)
			{
				// clear the fields when user click upon clear button
				user_Name_Field.clear();
				password_Field.clear();
			}
				});
		
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXX               Setup the Register Button                                           XXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		// Create the object of the register button
		register = new Button();
		// Set the text of the register button
		register.setText("Not Account Yet? Create One");
		// Set the position of the button
		register.setLayoutX(800); register.setLayoutY(600);
		// Set the size and style of the button
		register.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 22));
		// Set the style of the button
		register.setStyle("-fx-background-color: #090a0c, linear-gradient(#38424b 0%, #1f2429 20%, #191d22 100%),"
						+ "linear-gradient(#20262b, #191d22), radial-gradient(center 50% 0%, radius 100%, "
						+ "rgba(114,131,148,0.9), rgba(255,255,255,0)); "
						+ "-fx-background-radius: 30;"
						+ "-fx-background-insets: 0,1,2,0;"
						+ "-fx-padding:10 20 10 20;");
		// Set the color of the text
		register.setTextFill(Color.WHITE);
		
		/**
		 * Hover effect or handling on button
		 */
		register.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Set the hover effect on button
				register.setEffect(dropShadow);
				// Change the color on hover
				register.setTextFill(Color.web("#F4D03F"));
			}
				});
		
		register.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent mouseEvent)
			{
				// Disable the effect when hover doesn't happen
				register.setEffect(null);
				// Set the color of the text
				register.setTextFill(Color.WHITE);
			}
				});
		
		/**
		 * Event Handling of register button
		 */
		register.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent actionEvent)
			{
				// Jump onto the register button when user want to create new account
				EPUB_MAIN.stg.setScene(EPUB_MAIN.regScene);
			}
				});
		
		
	}
}
