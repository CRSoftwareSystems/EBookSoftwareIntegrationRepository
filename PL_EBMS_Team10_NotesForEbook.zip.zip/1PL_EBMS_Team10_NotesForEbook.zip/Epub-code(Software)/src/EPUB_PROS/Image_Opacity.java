package EPUB_PROS;
import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

/**
 * 
 * @author Shane
 * 12-03-2019, Tuesday
 * This purpose of this method to setup the opacity of background image
 */
public class Image_Opacity 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXX      TRANSPARENCY IMAGE SETUP       XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	public static void transparencyImage(Image bgImage, WritableImage bgWritableImage, int width, int height)
	{
		// Create the object of pixel reader and also get the pixel of the image and store into the 
		// pxReader 
		PixelReader pxReader = bgImage.getPixelReader();
		// Create the object of Pixel Writer and get the allowance to make changes into the image
		PixelWriter pxWriter = bgWritableImage.getPixelWriter();
		// Read one pixel at a time and write it to the destination
		for(int h=0; h < height; h++)
		{
			for(int w=0; w < width; w++)
			{
				// Read the pixel color 
				Color opacity = pxReader.getColor(w, h);
				// Setup the opacity of the image
				pxWriter.setColor(w, h, Color.color(opacity.getRed(), opacity.getGreen(), opacity.getBlue(), 0.70));
				
			}
		}
		
	}

}
