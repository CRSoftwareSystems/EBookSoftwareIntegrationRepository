package EPUB_PROS;
import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

/**
 * 
 * @author Shane
 * 15-03-2019, Friday
 * The purpose of this class is to setup the animations for numerous purposes.
 *
 */
public class Anim_Trans 
{
	// Define the objects globally in order access from anywhere
	public static Circle animBall, animBall1;
	private static PathTransition pathTrans;
	private static RotateTransition rotation;
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX                   Setup Animation Ball Transition         XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	public static void animationBall()
	{
		
		// Create the object of the circle and set the size of the circle
		animBall = new Circle(30, 30, 15);
		// Set the color or effects of the ball
		animBall.setFill(Gradient_Effects.omegaBallEffect);
		
		/**
		 * Set up the path of the ball where the ball move
		 */
		// Create the object of the Path Transition
		pathTrans = new PathTransition();
		// Set the duration how long the ball moves 
		pathTrans.setDuration(Duration.seconds(15));
		// Set the Node [Set that object which one want to anim like animBall (CIRCLE) ]
		pathTrans.setNode(animBall);
		// Set the path where the ball start following the path to move
		pathTrans.setPath(User_Interface.welcome_Text);
		// Set the count how many times want to move or animate
		pathTrans.setCycleCount(FadeTransition.INDEFINITE);
		// Set Autoreverse true if want to reverse the animation
		pathTrans.setAutoReverse(false);
		// Play the transition
		pathTrans.play();
	}
	
	/**
	 * Create method to setup ball animation method
	 */
	public static void animBall()
	{
		// Create the object of the circle and set the size of the ball
		animBall1= new Circle(30, 30, 15);
		// Set the gradient effect onto the ball
		animBall1.setFill(Gradient_Effects.omegaBallEffect);
		
		/**
		 * Set up the path of the ball where ball can move to follow the path
		 */
		// Create the object of the path transition
		pathTrans = new PathTransition();
		// Set the duration how long the ball moves
		pathTrans.setDuration(Duration.seconds(28));
		// Set the Node [Set the object which one want to animate like animBall1 [CIRCLE]
		pathTrans.setNode(animBall1);
		// Set the path where the ball start following the path to move
		pathTrans.setPath(Register_UI.registeration_Form);
		// Set the count how many times want to move or animate
		pathTrans.setCycleCount(FadeTransition.INDEFINITE);
		// Set up want to AutoReverse or not, if yes then pass true else pass false
		pathTrans.setAutoReverse(false);
		// Play the transition
		pathTrans.play();
		
	}
	/**
	 * Create method to setup the rotation image
	 */
	public static void rotateImg()
	{
		// Create the object of RotateTransition
		rotation = new RotateTransition();
		// Set the duration of the transition
		rotation.setDuration(Duration.millis(2000));
		// Setup the node for the transition or may say connection between the transition and umbrella image
		rotation.setNode(User_Interface.clearImgView);
		// Set the rotation angle
		rotation.setByAngle(360);
		// Set the number of times want to rotate image
		rotation.setCycleCount(FadeTransition.INDEFINITE);
		// Set the autoreverse true if want to rotate and set to false if doesn't want to reverse rotate
		rotation.setAutoReverse(false);
		// Play transition
		rotation.play();
	}
	
	/**
	 * Create the method to setup the button zoom in and out animation
	 */
	public static void zoomAnim()
	{
		// Create the object of Scale Transition
		ScaleTransition scaleTransition = new ScaleTransition();
		// Set the duration of the transition
		scaleTransition.setDuration(Duration.millis(2000));
		// Setup the node for the transition or may say connection between the transition and image
		scaleTransition.setNode(User_Interface.login);
		// Setup the dimensions for scalling
		scaleTransition.setByY(0.2); scaleTransition.setByX(0.2);
		// Set the number of times want to zoom in and out
		scaleTransition.setCycleCount(FadeTransition.INDEFINITE);
		// set autoreverse
		scaleTransition.setAutoReverse(true);
		// Play transition
		scaleTransition.play();
	}
	

}
