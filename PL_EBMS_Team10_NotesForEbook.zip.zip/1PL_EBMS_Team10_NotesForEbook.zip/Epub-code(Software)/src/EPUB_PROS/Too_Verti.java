package EPUB_PROS;

import EPUB_OMEGA.Splash_Screen;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * 
 * @author Shane
 * 01-04-2019, Monday
 * The purpose to create this class is to setup the Toolbar vertically in order to display some shortcut
 * keys where user can use most usefull features easily.
 */
public class Too_Verti 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX                      Define the objects globally          XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	public static ToolBar alphaBar;
	private static Button exitFullScreen, logout, okay, cancel;
	private static Image exitScreenImg, logoutImg;
	private static ImageView exitScreenView, logoutView;
	
	private static Stage primaryStage;
	private static Group root;
	private static Label message;
	private static Scene exitScene;
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX         Create the method of Toolbar and setup some features inside it    XXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	public static void shortcutKeys()
	{
		// Create an object of the Toolbar
		alphaBar = new ToolBar();
		// Set the height and width of the toolbar
		alphaBar.setMinWidth(95); alphaBar.setMinHeight(994);
		// Set the position of the tool bar
		alphaBar.setTranslateX(1834); alphaBar.setTranslateY(7);
		// Set the background color of the toolbar
		alphaBar.setBackground(new Background(new BackgroundFill(Gradient_Effects.elBano, CornerRadii.EMPTY, Insets.EMPTY)));
		
		/**
		 * Setup the button onto the vertical toolbar to exit the full screen
		 * 
		 */
		// Create an object of the image and access the image
		exitScreenImg = new Image(Too_Verti.class.getResourceAsStream("/exitFullScreen.png"));
		// Create an object of the image view to view an image
		exitScreenView = new ImageView(exitScreenImg);
		// Set the size of the image
		exitScreenView.setFitWidth(75); exitScreenView.setFitHeight(70);
		// Set the position of the button
		exitScreenView.setTranslateX(-105); exitScreenView.setTranslateY(-50);
		
		// Create an object of the button
		exitFullScreen = new Button("", exitScreenView);
		// hide the background of the button
		exitFullScreen.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		/**
		 * Event handling on to the exit screen button
		 */
		exitFullScreen.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent exitEvent)
			{
				// Exit the screen
				EPUB_MAIN.stg.setFullScreen(false);
				// Play sound 
				EPUB_User_Interface.clickAud.play();
			}
				});
		
		/**
		 * Setup Mouse Hover Effect on exit full screen Button
		 */
		exitFullScreen.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				exitFullScreen.setEffect(EPUB_User_Interface.shadowEffect);
			}
				});
		
		exitFullScreen.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				exitFullScreen.setEffect(null);
				// Disable background color on hovor end
				exitFullScreen.setStyle("-fx-background-color: transparent;");
			}
				});
		/**
		 * Setup the logout button to logout the application
		 */
		// Create an object of the image and access the image
		logoutImg = new Image(Too_Verti.class.getResourceAsStream("/logout.png"));
		// Create an object of the image view to view an image
		logoutView = new ImageView(logoutImg);
		// Set the size of the image
		logoutView.setFitWidth(70); logoutView.setFitHeight(0);
		// Set the position of the button
		logoutView.setTranslateY(100); logoutView.setTranslateX(-5);
			
		// Create an object of the button
		logout = new Button("", logoutView);
		// hide the background of the button
		logout.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		/**
		 * Setup Mouse Hover Effect on logout Button
		 */
		logout.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				logout.setEffect(EPUB_User_Interface.shadowEffect);
			}
				});
		
		logout.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				logout.setEffect(null);
				// Disable background color on hovor end
				logout.setStyle("-fx-background-color: transparent;");
			}
				});
		
		/**
		 * Event handling on to the logout button
		 */
		logout.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent exitEvent)
			{
				// Create an object of the stage
				primaryStage = new Stage();
				// Create an object of the group
				root = new Group();
				// Create an object of the scene
				exitScene = new Scene(root, 500, 300, Color.rgb(40, 40, 40));
				
				// Create an object of the label
				message = new Label("Are you sure you want to logout?");
				// Set the text of the text
				message.setTextFill(Color.RED);
				// Set the position of the label
				message.setLayoutX(40); message.setLayoutY(80);
				// Set the style of the text
				message.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 28));
				
				
				okay = new Button("CONTINUE");
				// Set the style of the button
				okay.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
				// Set the style of the button background
				okay.setStyle("-fx-background-radius: 30; -fx-background-color: #3498DB;");
				
				// Set the position of the button
				okay.setLayoutX(70); okay.setLayoutY(200);
				
				okay.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent cancelEvent)
			{
				// Logout the application
				EPUB_MAIN.stg.setScene(EPUB_MAIN.scene);
				// Play sound 
				EPUB_User_Interface.clickAud.play();
				primaryStage.close();
			}
				});
				cancel = new Button("CANCEL");
				// Set the style of the button
				cancel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
				// Set the style of the button background
				cancel.setStyle("-fx-background-radius: 30; -fx-background-color: #3498DB;");
				// Set the position of the button
				cancel.setLayoutX(310); cancel.setLayoutY(200);
				// Event handling of the cancel button
				cancel.setOnAction(new EventHandler<ActionEvent>()
						{
					public void handle(ActionEvent cancelEvent)
					{
						// Close the window
						primaryStage.close();
					}
						});
				
				// Group the children
				root.getChildren().addAll(message, okay, cancel);
				// Set the icon or image as a icon on stage
				primaryStage.getIcons().add(new Image(EPUB_MAIN.APPLICATION_ICON));
				// Hide the stage
				primaryStage.initStyle(StageStyle.TRANSPARENT);
				// Set the scene with the stage
				primaryStage.setScene(exitScene);
				// Display the scene
				primaryStage.show();
				
				
				
				
			}
			
				});
		// Add the button at the tool bar
		alphaBar.getItems().addAll( logout, exitFullScreen);
		
	}
	
}
