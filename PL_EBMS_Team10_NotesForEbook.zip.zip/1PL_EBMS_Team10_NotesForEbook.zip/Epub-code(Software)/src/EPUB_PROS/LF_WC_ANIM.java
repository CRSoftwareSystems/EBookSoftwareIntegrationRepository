package EPUB_PROS;
import javafx.scene.text.Text;

/**
 * 
 * @author Shane
 * 14-03-2019, Thursday
 * 
 * The purpose of this class is to design the WELCOME TEXT via implementing Animation
 *
 */


public class LF_WC_ANIM 
{
	/**
	 * Define the variables globally in order to access it from anywhere within the program.
	 */
	private Text welcome_Text;
	// Constructor
	public LF_WC_ANIM()
	{
		// Create the object of the text
		welcome_Text= new Text();
		// Set the text of the welcome
	}
	

}
