package EPUB_PROS;
import javafx.animation.FadeTransition;  
import javafx.animation.PathTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Welcome_Text_Anim extends Application
{
	public void start(Stage primaryStage)
	{
		// Create the object of the group in order to group the children together
		Group root = new Group();
		// Create the object of the Scene and also set the width and height of the window
		Scene scene = new Scene(root, 1200, 800, Color.GREEN);
		
		/*
		Image umbrella = new Image("AI_Circle.jpg");
		ImageView umbrellaView = new ImageView(umbrella);*/
		// Set the width and height of the image
		/*umbrellaView.setFitHeight(100); umbrellaView.setFitWidth(100);
		// Set the position of the image0
		umbrellaView.setLayoutX(200); umbrellaView.setLayoutY(100);
		umbrellaView.setStyle("-fx-background-insets: 40, 40, 40, 40;");*/
		 RadialGradient g = new RadialGradient(
		            0, 0,
		            0.35, 0.35,
		            0.5,
		            true,
		            CycleMethod.NO_CYCLE,
		            new Stop(0.0, Color.WHITE),
		            new Stop(1.0, Color.BLUE));
		 RadialGradient r = new RadialGradient(
		            0, 0,
		            0.35, 0.35,
		            0.5,
		            true,
		            CycleMethod.NO_CYCLE,
		            new Stop(0.0, Color.WHITE),
		            new Stop(1.0, Color.RED));
		// Create the object of the circle and set the size of the circle
		Circle path = new Circle(30, 30, 15);
		path.setFill(g);
		
		
		// Create the object of the Text
		Text welcome = new Text();
		welcome.setText("W");
		welcome.setStroke(r);
		welcome.setFill(r);
		//welcome.setStrokeWidth(2);
		welcome.setLayoutX(100); welcome.setLayoutY(500);
		welcome.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 120));
		//welcome.setFont(Font.font("Arial", FontWeight.BOLD, FontPosture.ITALIC, 45));
		
		/**
		 * Path transition
		 */
		// Create the object of Path Transition
		//PathTransition pathTrans = new PathTransition(Duration.seconds(2),umbrellaView, rectangle);
		// Set up a Path Transition for the Rectangle and set the duration of the animation
        PathTransition pathTrans = new PathTransition();
        pathTrans.setDuration(Duration.seconds(15));
        pathTrans.setNode(path);
        pathTrans.setPath(welcome);
		// Setup the orientation
		//pathTrans.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		// Set the number of time want to display the animation
		pathTrans.setCycleCount(FadeTransition.INDEFINITE);
		// Set the direction autoreverse
		pathTrans.setAutoReverse(false);
		// Play the animation
		pathTrans.play();


		// Group the children
		root.getChildren().addAll(welcome,path);
		// Connect the scene and stage together
		primaryStage.setScene(scene);
		// Display the window
		primaryStage.show();
	}
	
	// Main method to launch the application
	public static void main(String []args)
	{
		// Launch the application
		Application.launch(args);
	}

}
