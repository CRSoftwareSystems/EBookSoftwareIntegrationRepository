package EPUB_PROS;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;

/**
 * 
 * @author Shane
 * 16-03-2019, Saturday
 * The purpose of this class is to setup the background Image
 *
 */
public class Background_Image
{	
	/**
	 * Define the objects globally in order to access from anywhere according to their specifiers
	 */
	private static Image backgroundImage;
	private static ImageView backgroundView;
	private static WritableImage backgroundUI;

	/**
	 * Create this method to setup the background image
	 */
	public static Node backgroundImage() 
	{
		// Access the image
		backgroundImage = new Image("universe.jpeg");
		// Get the width and height of the image
		int imgWidth =(int) backgroundImage.getWidth();
		int imgHeight= (int) backgroundImage.getHeight();
		// Create the object of writable image and pass the height and width of the image
		// what we got
		backgroundUI= new WritableImage(imgWidth, imgHeight);
		// Copy all the sources together and create the method where we can setup the image opacity
		// transparencyImage method is defined at Image_Opacity class
		Image_Opacity.transparencyImage(backgroundImage, backgroundUI, imgWidth, imgHeight);
		// View the image
		backgroundView = new ImageView(backgroundUI);
		// Set the height and width of the Image
		backgroundView.setFitHeight(1100); backgroundView.setFitWidth(1930);
		// Return the backgroundView [Image object]
		return backgroundView;
	}

}
