package EPUB_PROS;

import EPUB_OMEGA.Splash_Screen;
import EPUB_OMEGA.Web_View;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Login_Logic 
{
	// Define some variables globally in order to access within the class or package
	private static String checkUserField, checkPasswordField;
	
	/**
	 * In this method, implements the logic of the login button
	 * If the fields fulfil the requirements then user would be able to 
	 * view or able to use the application.
	 */
	
	public static void loginWindow()
	{
		// Event handling login button
		User_Interface.login.setOnAction(new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent event)
			{
				// Store the Username field and password field in string variables
				checkUserField = User_Interface.user_Name_Field.getText().toString();
				checkPasswordField= User_Interface.password_Field.getText().toString();
				
				if(checkUserField.equals("ADMIN") && checkPasswordField.equals("SHANE"))
					{
					
					// If condition pass then user able to reach next window
					EPUB_MAIN.stg.setScene(EPUB_MAIN.scene1);
					// Play audio when login the window
					User_Interface.welcomeBack.play();
					
					}
				else if(checkUserField.isEmpty() && checkPasswordField.isEmpty())
					{
					
					// If user enter wrong inputs then display Alert window
					// Create the object of the Alert and also set the type of alert
					Alert alert = new Alert(AlertType.WARNING);
					// Set the dialog pane
					DialogPane dialog = alert.getDialogPane();
					// Set the background of the alert window
					dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
					// Add the Effect on dialog
					dialog.setEffect(EPUB_User_Interface.shadowEffect);
					// Set the text color 
					dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
					// Set the title of the Alert popup window
					alert.setTitle("Check Input Fields with Database");
					// Set the Header text
					alert.setHeaderText("Login Failed!");
					// Add contents to the user where user able to understand the warning in brief
					alert.setContentText("Sorry, please check your username and password. ");
					// Create an object of the Stage and set the icon onto the alert window
					Web_View.alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
					// Set the image as an window icon
					Web_View.alertStage.getIcons().add(new Image(Web_View.ALERT_ICON));
					// Set the height of the alert window
					alert.getDialogPane().setMinHeight(200);
					// Set the width of the alert window
					alert.getDialogPane().setMinWidth(500);
					// Display alert window
					alert.showAndWait();
					}
				else if(!checkUserField.equals("ADMIN") || checkUserField.isEmpty() && checkPasswordField.isEmpty() || checkPasswordField.equals("SHANE"))
					{
					// If user enter wrong inputs then display Alert window
					// Create the object of the Alert and also set the type of alert
					Alert alert = new Alert(AlertType.WARNING);
					// Set the dialog pane
					DialogPane dialog = alert.getDialogPane();
					// Set the background of the alert window
					dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
					// Add the Effect on dialog
					dialog.setEffect(EPUB_User_Interface.shadowEffect);
					// Set the text color 
					dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
					// Set the title of the Alert popup window
					alert.setTitle("Check Input Fields with Database");
					// Set the Header text
					alert.setHeaderText("Login Failed!");
					// Add contents to the user where user able to understand the warning in brief
					alert.setContentText("Sorry, please check your Username or Email-ID");
					// Create an object of the Stage and set the icon onto the alert window
					Web_View.alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
					// Set the image as an window icon
					Web_View.alertStage.getIcons().add(new Image(Web_View.ALERT_ICON));
					// Set the height of the alert window
					alert.getDialogPane().setMinHeight(200);
					// Set the width of the alert window
					alert.getDialogPane().setMinWidth(500);
					// Display alert window
					alert.showAndWait();
					
					}
				
				else if(!checkPasswordField.equals("SHANE") || checkPasswordField.isEmpty() && checkUserField.equals("ADMIN"))
				{
					// If user enter wrong inputs then display Alert window
					// Create the object of the Alert and also set the type of alert
					Alert alert = new Alert(AlertType.WARNING);
					// Set the dialog pane
					DialogPane dialog = alert.getDialogPane();
					// Set the background of the alert window
					dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
					// Add the Effect on dialog
					dialog.setEffect(EPUB_User_Interface.shadowEffect);
					// Set the text color 
					dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
					// Set the title of the Alert popup window
					alert.setTitle("Check Input Fields with Database");
					// Set the Header text
					alert.setHeaderText("Login Failed!");
					// Add contents to the user where user able to understand the warning in brief
					alert.setContentText("Sorry, please check your password.");
					// Create an object of the Stage and set the icon onto the alert window
					Web_View.alertStage = (Stage) alert.getDialogPane().getScene().getWindow();
					// Set the image as an window icon
					Web_View.alertStage.getIcons().add(new Image(Web_View.ALERT_ICON));
					// Set the height of the alert window
					alert.getDialogPane().setMinHeight(200);
					// Set the width of the alert window
					alert.getDialogPane().setMinWidth(500);
					// Display alert window
					alert.showAndWait();
					
					
				}
				else
				{
					System.out.println(""+null);
				}
			}
			});
		}
	
}
