package EPUB_OMEGA;
import javafx.beans.property.SimpleStringProperty;

/**
 * 
 * @author Shane
 * 17-03-2019, Sunday
 * The purpose to create this class is to prepare the type of list and also
 * create the set and get methods.
 *
 */
public class URL_LINK 
{
	// Define the objects globally in order to access from another class according to their specifiers.
	final SimpleStringProperty urlLink;
	
	/**
	 * Create constructor
	 */
	URL_LINK(String urlList)
	{
		this.urlLink = new SimpleStringProperty(urlList);
	}
	
	/**
	 * Create this method to get the data or bookmark
	 */
	public String getURLBookmarkList()
	{
		return urlLink.get();
	}
	/**
	 * Create this method to set the data or bookmark
	 */
	public void setURL_BookmarkList(String url)
	{
		urlLink.set(url);
	}
}