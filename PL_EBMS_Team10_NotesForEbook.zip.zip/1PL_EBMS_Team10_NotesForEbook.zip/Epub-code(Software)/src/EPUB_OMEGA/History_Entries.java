package EPUB_OMEGA;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.web.WebHistory.Entry;

public class History_Entries 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                Setup history list view method                             XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	/**
	 * Setup the browser history in order to allow the user to see
	 * the history list where the user can visit at later time and 
	 * also provides numberous features like cancel or close the link
	 * even it require that link again.
	 */
		
	public static void history_List()
	{
		// Access the webview history 
		Web_View.web_History = Web_View.browser.getEngine().getHistory();
						
		// Acess the entries and store at the ObservableList entries
		Web_View.entryList = Web_View.web_History.getEntries();
		// Create an object of the History List view
		Web_View.history_List = new ListView<Entry>(Web_View.entryList);
		// Set the width and height of the list view
		Web_View.history_List.setMinWidth(1564); Web_View.history_List.setMinHeight(940);
		// Set the position of the list view
		Web_View.history_List.setTranslateY(30);
		// Set the background color of the list view
		// Set the style of the list view
		Web_View.history_List.setStyle("-fx-control-inner-background: #2C3E50; -fx-highlight-fill:#E74C3C;"
				+ "-fx-highlight-text-fill: #FDFEFE; -fx-border-color: linear-gradient(to bottom right,#E74C3C 100%,#F1C40F 10%);"
				+ "-fx-border-width: 5; -fx-font-size: 20;");
		
		// Display the history entries at the list view
		Web_View.history_List.setCellFactory(lv -> new ListCell<Entry>()
				{
			protected void updateItem(Entry entry, boolean nothing)
			{
				super.updateItem(entry, nothing);
				// Setup what content want to display at the history list
				setText(entry == null ? null : "URL:    " +entry.getUrl() +
						"          Title:     " + entry.getTitle() +
						"          Visited Date:      " + entry.getLastVisitedDate());
			}
				});
		
		/**
		 * Event handling,
		 * Here, when user click on to the history item then user able to visit
		 * that link at the Web view
		 */
		Web_View.history_List.setOnMouseClicked(new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent event)
			{
				// When user select the history list and click upon that then load that url and display at web view
				int omega = Web_View.history_List.getSelectionModel().getSelectedIndex() -
						Web_View.web_History.getCurrentIndex();
				Web_View.web_History.go(omega);
			}
				});
		
		/**
		 * This method prepared to update the list
		 */
		Web_View.web_History.currentIndexProperty().addListener(new ChangeListener<Number>()
				{
			public void changed(ObservableValue<? extends Number> observable, Number omegaPast, 
					Number omegaFuture)
			{
				// Update currently selected list view
				Web_View.history_List.getSelectionModel().select(omegaFuture.intValue());
			}
				});
	}

}
