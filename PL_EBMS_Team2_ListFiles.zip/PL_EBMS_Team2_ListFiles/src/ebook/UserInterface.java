package ebook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*******
 * <p> Title: UserInterface Class. </p>
 * 
 * <p> Description: A JavaFX demonstration application: This controller class describes the user
 * interface for the Exercise04 demonstration application </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-04 </p>
 * 
 * @author Abhinav Yadav - Team 2
 * @author yash - Team 2
 * 
 * @version 2.03	2018-07-19 Baseline
 * @version 3.00	2019-02-24 An enhancement for Project Lab 
 * 
 */
public class UserInterface {
	int result2 = 0;
	
	/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	private Stage primaryStage;
	
	// Attributes used to establish the display and control panel within the window provided to us
	private double controlPanelHeight = Mainline.WINDOW_HEIGHT - 110;
	private int marginWidth = 20;
	// The User Interface widgets used to control the user interface and start and stop the simulation
	private Label label_FileName = new Label("E-Book Manager");
	private Button button_add = new Button("Add Book");
	private Button button_openlibrary = new Button("Open");
	private Button button_help = new Button("Help");
//	private Button button_Display = new Button("Display the data");

	ObservableList<String> List = FXCollections.<String>observableArrayList();
	ListView<String> listview = new ListView<String>(List);
	VBox blk_Text = new VBox(listview);
	
	DirectoryChooser dir_chooser = new DirectoryChooser(); 
	// The attributes used to inform the user if the file name specified exists or not
	private Label message_FileFound = new Label("");
	private Label message_FileNotFound = new Label("");
	private Label message_ErrorDetails = new Label("");
	
	// black squares representing alive cells
	
	// This attribute holds the text that will be displayed 
	private TextArea blk_Text2 = new TextArea("");
	
	
	// GUI elements for the Add Pop-up
		final Stage addDialog = new Stage();
		private TextField fld_DefinitionName = new TextField();
    	private Button btn_delete = new Button("Delete");
    	private Button btn_exit = new Button("Exit");
    	private Button btn_browse = new Button("Browse");
    	 
  	   final Stage stage = new Stage();
  	   
  
	/**********************************************************************************************

	Constructors
	
	**********************************************************************************************/

	/**********
	 * This constructor established the user interface with all of the graphical widgets that are
	 * use to make the user interface work.
	 * 
	 * @param theRoot	This parameter is the Pane that JavaFX expects the application to use when
	 * 					it sets up the GUI elements.
	 */
	public UserInterface(Pane theRoot) {
		// Set the fill colors for the border frame for the game's output of the simulation
		
		addDialog.initModality(Modality.APPLICATION_MODAL);
        addDialog.initOwner(primaryStage);
        
		// Place a text area into the window and just within the above frame and make it not editable
 setupVBoxUI(blk_Text, 50, 50, Mainline.WINDOW_WIDTH-450, controlPanelHeight-61);		
		
		// Place a text area into the window and just within the above frame and make it not editable
		setupTextAreaUI(blk_Text2, "Monaco", 14, 320, 50, Mainline.WINDOW_WIDTH-350, controlPanelHeight-61, false);	
		
    	// Label the text field that is to receive the file name.
		setupLabelUI(label_FileName, "Arial", 18, Mainline.WINDOW_WIDTH-20, Pos.BASELINE_LEFT, 
				marginWidth, 10);
		
		setupButtonUI(button_help, "Arial", 18, 70, Pos.BASELINE_RIGHT, Mainline.WINDOW_WIDTH - 150,  
				10);
	
		

		// Establish a GUI button the user presses when the file name have been entered and the
		// code has verified that the data in the file is valid (e.g. it conforms to the requirements)
		setupButtonUI(button_add,"Arial", 18, 70, Pos.BASELINE_LEFT, Mainline.WINDOW_WIDTH - 525,  
				10);
		button_add.setOnAction((event) -> {setupDictionaryAddPopup();});

		// Establish the link between the button widget and a routine that loads the data into theData
		// data structure
	

		// The following set up the control panel messages for messages and information about errors
		setupLabelUI(message_FileFound, "Arial", 18, 150, Pos.BASELINE_LEFT, 350, controlPanelHeight);
		message_FileFound.setStyle("-fx-text-fill: green; -fx-font-size: 18;");

		setupLabelUI(message_FileNotFound, "Arial", 18, 150, Pos.BASELINE_LEFT, 350, controlPanelHeight);
		message_FileNotFound.setStyle("-fx-text-fill: red; -fx-font-size: 18;");

		setupLabelUI(message_ErrorDetails, "Arial", 16, Mainline.WINDOW_WIDTH, Pos.BASELINE_LEFT, 20,
				controlPanelHeight);
		
		message_ErrorDetails.setStyle("-fx-text-fill: red; -fx-font-size: 16;");

		
		
		// Place all of the just-initialized GUI elements into the pane with the exception of the
		// Stop button.  That widget will replace the Start button, once the Start has been pressed
		theRoot.getChildren().addAll(button_add, message_FileFound, message_FileNotFound, message_ErrorDetails,
				blk_Text, blk_Text2, label_FileName, button_help);
	}

	
	/**********************************************************************************************

	Helper methods - Used to set up the JavaFX widgets and simplify the code above
	
	**********************************************************************************************/

	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}
	
	private void setupVBoxUI(VBox t, double x, double y, double w, double h){
		t.setPrefWidth(w);
		t.setPrefHeight(h);	
		t.setLayoutX(x);
		t.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextAreaUI(TextArea t, String ff, double f, double x, double y, double w, double h, boolean e){
		t.setFont(Font.font(ff, f));
		t.setPrefWidth(w);
		t.setPrefHeight(h);	
		t.setLayoutX(x);
		t.setLayoutY(y);	
		t.setEditable(e);
		t.setWrapText(true);
	}


	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}
	
	
	/**********
	 * This method established the pop-up window that allows the user to add a new definition 
	 * in the dictionary and then save it.
	 */
	private void setupDictionaryAddPopup() {
		// Set up the pop-up modal dialogue window
        addDialog.setTitle("Open Library");
       
        Group dictionaryEditControls = new Group();
        
        // Set up the pop-up window
        Scene dialogScene = new Scene(dictionaryEditControls, 500, 200);
        

        // Set up the fields for the add pop-up window
		setupTextUI(fld_DefinitionName, "Arial", 14, 300, Pos.BASELINE_LEFT, 30, 50, true);
     
        // Set the screen so we can see it
        addDialog.setScene(dialogScene);
        
        setupButtonUI(btn_delete, "Arial", 12, 50, Pos.BASELINE_LEFT, 30, 150);
        btn_delete.setOnAction((event) ->  {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Delete ebook");
            List<File> selectedFiles = fileChooser.showOpenMultipleDialog(null);

            if (selectedFiles != null) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("Warning !");
                alert.setContentText("Are you sure you want to delete these files ?");

                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    for (File selectedFile : selectedFiles) {
                        selectedFile.delete();
                    }
                }
            } else {
                System.out.println("Error Selection");
            }
        });
        
        setupButtonUI(btn_exit, "Arial", 12, 50, Pos.BASELINE_LEFT, 400, 150);
        btn_exit.setOnAction((event) -> { addDialog.close(); });
        
        setupButtonUI(btn_browse, "Arial", 12, 50, Pos.BASELINE_LEFT, 400, 50);
        
		btn_browse.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(final ActionEvent e) {
				File file = dir_chooser.showDialog(addDialog);

				File directoryPath = new File(file.getAbsolutePath());
				File[] files = directoryPath.listFiles(new FilenameFilter() {

					public boolean accept(File dir, String name) {
						return name.endsWith(".txt");
					}
				});

				for (File file1 : files) {
					List.add(file1.getName());

					String v = file1.getAbsolutePath();

					File f = new File(v);
					blk_Text2.clear();
					Scanner t;
					try {
						t = new Scanner(f);

						while (t.hasNextLine()) {

							String ty = t.nextLine();
							blk_Text2.appendText(ty + "\n");

						}
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
    			
    			    
    				 
//    			listview.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue)->{
//    				blk_Text2.clear();
//
//    				String v= directoryPath+"\\"+listview.getSelectionModel().getSelectedItem();
//    				File t = new File(v);
//    				try {
//    					@SuppressWarnings("resource")
//						Scanner scan = new Scanner(t);
//    					while(scan.hasNextLine()) {
//    						
//    						String i = scan.nextLine();
//    						blk_Text2.appendText(i+"\n");
//    						}
//    					
//    				} catch (FileNotFoundException e1) {
//    					
//    					e1.printStackTrace();
//    				}
//    	    			
//    	    		});
  	        }
                
           
        });
  
        // Populate the pop-up window with the GUI elements
        dictionaryEditControls.getChildren().addAll(fld_DefinitionName, btn_delete, btn_browse, btn_exit);
        
        // Show the pop-up window
        addDialog.show();
		
	}
}

	