package ebook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/*******
 * <p> Title: UserInterface Class. </p>
 * 
 * <p> Description: A JavaFX demonstration application: This controller class describes the user
 * interface for the Exercise04 demonstration application </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2018-08-04 </p>
 * 
 * @author yash - Team 2
 * 
 * @version 2.03	2018-07-19 Baseline
 * @version 3.00	2019-02-24 An enhancement for Project Lab 
 * 
 * We are Reading the text files from a directory, and showing it on the user interface.
 */
public class UserInterface extends Application {
	
	
	ObservableList<String> List = FXCollections.<String>observableArrayList();
	ListView<String> listview = new ListView<String>(List);
	VBox vbox = new VBox(listview);
	TextArea ta = new TextArea();
	


	public  UserInterface(Pane theRoot)	
	{
		File directoryPath = new File("E:\\");
		 File[] files=directoryPath.listFiles(new FilenameFilter() {
				
				public boolean accept(File dir, String name) {
					return name.endsWith(".txt");
				}
			});
			
			for (File file : files) {
				List.add(file.getName());
				
			}
			
		Group group = new Group();
		Scene sc = new Scene(group,800,800);
		sc.setFill(Color.WHITE);
		
		Label Files = new Label("Directory");
		Files.setLayoutX(40);
		Files.setLayoutY(22);
		Label Content = new Label("Content");
		Content.setLayoutX(350);
		Content.setLayoutY(135);
		
		
		listview.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue)->{
			
			ta.clear();

			String v= directoryPath+"\\"+listview.getSelectionModel().getSelectedItem();
			File t = new File(v);
			try {
				@SuppressWarnings("resource")
				Scanner scan = new Scanner(t);
				while(scan.hasNextLine()) {
					
					String i = scan.nextLine();
					ta.appendText(i+"\n");
					}
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		});
		
		
		ta.setLayoutX(350);
		ta.setLayoutY(150);
		ta.setMaxHeight(700);
		ta.setMaxWidth(400);
		
		
		vbox.setLayoutX(40);
		vbox.setLayoutY(40);
		
		
		theRoot.getChildren().addAll(ta,vbox,Files,Content);
		
		
	}


	public static void main(String []args)
	{
		Application.launch(args);
	}

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
}

