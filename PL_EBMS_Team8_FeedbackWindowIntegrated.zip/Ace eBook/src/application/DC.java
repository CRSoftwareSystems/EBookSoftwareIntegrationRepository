package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class DC implements Initializable {
	
	@FXML
	WebView webView;
	
    @FXML 
   private WebEngine webengine;
    @FXML
	ComboBox<String> feedback_recievers;


	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		 this.webengine = this.webView.getEngine();
		    this.webengine.load("http://google.com");
		feedback_recievers = new ComboBox<>();
		feedback_recievers.getItems().addAll("Book Author","Application Administrator");
		
	}
	public  void launchFeedbackWindow() throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass()
				.getResource("/application/Feedback_Window.fxml"));
		Parent root1 = (Parent) fxmlLoader.load();
		Stage mainStage = new Stage();
		mainStage.setTitle("Give Us Your Valuable Feedback");
		mainStage.setScene(new Scene(root1));
		mainStage.show();
	}
	
}
