package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.web.HTMLEditor;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class DC implements Initializable {
	
	@FXML
	WebView webView;
	
    @FXML 
   private WebEngine webengine;
    @FXML
	ComboBox<String> feedback_recievers;


    ObservableList<String> List = FXCollections.<String>observableArrayList();
	ListView<String> listview = new ListView<String>(List);
	VBox vbox = new VBox(listview);
	javafx.scene.control.Label listOfBooks = new javafx.scene.control.Label("Available Books in Repository");
	Button browse = new Button("Browse Books");
	TextArea contentArea = new TextArea();
	TextField filePath = new TextField();
	File thedirectory = new File("RepositoryFolder");
	private HTMLEditor editor;
	private TextField searchField;
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		 this.webengine = this.webView.getEngine();
		    this.webengine.load("http://google.com");
		feedback_recievers = new ComboBox<>();
		feedback_recievers.getItems().addAll("Book Author","Application Administrator");
		
	}
	public  void launchFeedbackWindow() throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass()
				.getResource("/application/Feedback_Window.fxml"));
		Parent root1 = (Parent) fxmlLoader.load();
		Stage mainStage = new Stage();
		mainStage.setTitle("Give Us Your Valuable Feedback");
		mainStage.setScene(new Scene(root1));
		mainStage.show();
	}
	
	public  void editing() throws IOException {
		finalmethod();
	}
	
	
	public void finalmethod()	
	{
		Stage stage = new Stage();
		Group group = new Group();
		Scene sc = new Scene(group,1500,700);
		sc.setFill(Color.WHITE);
		Button editContent = new Button("Edit Book");
		Button search = new Button("Search In Book");
		
		searchField = new TextField();
		editContent.setLayoutX(1400); editContent.setLayoutY(180);
		editContent.setOnAction((event) -> {
			EditFileContent();
		});
		
		searchField.setLayoutX(500);searchField.setLayoutY(10);
		search.setLayoutX(800);search.setLayoutY(10);
		
		browse.setLayoutX(1000); browse.setLayoutY(50);
		browse.setOnAction((event) -> 
		{
		
			openDialo();
			
			 	});
		
		// Setup the Editor field where user add data and search string what user want to search
				editor = new HTMLEditor();
				// Set the position of the editor
				editor.setLayoutX(350); editor.setLayoutY(100);
				// Set the width and height of it
				editor.setMaxHeight(700); editor.setMinWidth(1000);
				editor.setVisible(false);
		File directoryPath = new File("RepositoryFolder");
		 File[] files=directoryPath.listFiles(new FilenameFilter() {
				
				public boolean accept(File dir, String name) {
					return name.endsWith(".txt");
				}
			});
			
			for (File file : files) {
				List.add(file.getName());
	
			}
		listview.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue)->{
			contentArea.clear();

			String v= directoryPath+"\\"+listview.getSelectionModel().getSelectedItem();
			File t = new File(v);
			try {
				Scanner scan = new Scanner(t);
				while(scan.hasNextLine()) {
					
					String i = scan.nextLine();
					contentArea.appendText(i+"\n");
					}
				
			} catch (FileNotFoundException e1) {
				
				e1.printStackTrace();
			}
			
		});
		
      
		/**
		 * Event Handling of button
		 */
		search.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{
				
				// Call the method
				comoEstas();
				contentArea.setVisible(false);
				editor.setVisible(true);
			}
				});

        
       		filePath.setLayoutX(450); filePath.setLayoutY(50);
		filePath.setMinWidth(530);
		
		contentArea.setLayoutX(350);contentArea.setLayoutY(100);
		contentArea.setText("Click on Book Please..!");
		contentArea.setMinHeight(700); contentArea.setMinWidth(1000);
		
		listOfBooks.setLayoutX(10);listOfBooks.setLayoutY(70);
		listOfBooks.setDisable(false);
		final double MAX_FONT_SIZE = 24; 
		listOfBooks.setFont(new Font(MAX_FONT_SIZE));
		listOfBooks.setTextFill(Color.web("Black"));
		vbox.setLayoutX(10);
		vbox.setLayoutY(100);
		
		listview.setPrefHeight(700);
		listview.setMinWidth(320);
		
		((Group) sc.getRoot()).getChildren().addAll(contentArea,vbox, editContent, listOfBooks, browse, filePath,searchField,search,editor);
		
		stage.setTitle("Book Editor...!");
		
		stage.setScene(sc);
		stage.show();
	}

	protected void highlight(File directoryPath, String text) {
		// TODO Auto-generated method stub
		
	}
	private void EditFileContent() {
		
			Stage stage = new Stage(); // setting up the stage
			stage.setWidth(1000);
			stage.setHeight(1000);
			Scene scene = new Scene(new Group());
	
			VBox root = new VBox();
			root.setPadding(new Insets(8, 8, 8, 8));
			root.setSpacing(200);
			root.setAlignment(Pos.BOTTOM_LEFT);
			final HTMLEditor htmlEditor = new HTMLEditor();
		
			
			htmlEditor.setHtmlText(contentArea.getText());
			htmlEditor.setMinHeight(500);
//			
			Button showHTMLButton = new Button("Publish Book");
			showHTMLButton.setLayoutX(100);
			root.setAlignment(Pos.CENTER);
//			
			showHTMLButton.setOnAction((event) ->
					{
						// setting up the path as a repository folder
						File file3 = new File("PublishedBooks\\"+listview.getSelectionModel().getSelectedItem()+".html");
						try {
							// write the content of the file using buffer writer
							BufferedWriter outWriter = new BufferedWriter(new FileWriter(file3));
							System.out.println("Processing Start...!");
							//using for each loop and iterate all the content into the file
							outWriter.write(htmlEditor.getHtmlText());
							outWriter.close();
							System.out.println("Book is Published....!");
						}
						catch(Exception e) {
							System.out.println("Unable to Proceeed....!");
						}
					
					});

			root.getChildren().addAll(htmlEditor, showHTMLButton);
			scene.setRoot(root);
			stage.setScene(scene);
		    stage.show();
		
	}
	/**
	 * Method of Search or Add String
	 */
	public void comoEstas()
	{
		// Declare the variable which is set to null
		Pattern pattern=null;
		try
		{
			// get the text from text field and store into the pattern variable
			pattern = Pattern.compile(searchField.getText());
		}
		catch (PatternSyntaxException patternSyntaxException)
		{
			// Able to set the html texts
			editor.setHtmlText(String.format(
					"<html><body><p>"+ "<span style=\"color:Red;\">"
							+ "%s</span></p></body></html>", 
							patternSyntaxException.getMessage()));
			return;
		}
		
		// Create the object of matcher and store the text area data
		Matcher match = pattern.matcher(contentArea.getText());
		// set boolean variable to false
		boolean got =false;
		// Create the string builder object
		StringBuilder stringBuilder = new StringBuilder();
		
		/**
		 * Create the class 
		 */
		class Alpha
		{
			int beginning, end;
			// Create constructor
			Alpha(int start, int end)
			{
				this.beginning= start;
				this.end= end;
			}
			
		}
		
		// Create the list to insert data
		List<Alpha> pos= new ArrayList<Alpha>();
		// when user click on button then find the string from text area
		while(match.find())
		{
			// if data or string match then set to true
			pos.add(new Alpha(match.start(), match.end()));
			got=true;
		}
		
		// if not match then print string not found
		if(!got)
		{
			
			stringBuilder.append(String.format("No match found.%n"));
			Alert alert = new Alert(AlertType.WARNING);
			DialogPane dp = alert.getDialogPane();
			dp.setBackground(new Background(new BackgroundFill(Color.ALICEBLUE, CornerRadii.EMPTY, Insets.EMPTY)));
			//dp.setEffect(UserInterface.shadowEffect);
			dp.setStyle("-fx-font-weight: bold; -fx-border-color: red;");
			alert.setTitle("Error");
			alert.setHeaderText("No match found.");
			alert.setContentText("Sorry, String not found.");
			alert.showAndWait();
			
		}
		else
		{
			System.out.println(pos);
			// set the position variable to 0
			int position =0;
			for(int i=0; i< pos.size(); i++)
			{
				stringBuilder.append(contentArea.getText().substring(position, 
						pos.get(i).beginning)).append("<span style=\"color:"
								+ "RED;font-size:20px; text-decoration"
								+ ":underline\">").append(contentArea.getText().substring(pos.get(i).beginning, pos.get(i).end))
                .append("</span>");
				position=pos.get(i).end;
			}
			if(position > 0)
			{
				stringBuilder.append(contentArea.getText().substring(position));
			}
		}
		
		String html = String.format("" +
                "<html><body><p>%s</p></body></html>", stringBuilder.toString());

        editor.setHtmlText(html);
	}
	
	public void openDialo()
	{
		FileChooser fileChooser = new FileChooser(); // definaing an object for Filechooser
		 fileChooser.setInitialDirectory(thedirectory);  // set the initial directory
		    fileChooser.setTitle("Delete File...!"); // set the title of the window
		    File selectedFile = fileChooser.showOpenDialog(null);
		    filePath.setText(selectedFile.getAbsolutePath());
		   
		    if(selectedFile != null)
		    {
		    	contentArea.clear();
		    	try (BufferedReader reader = new BufferedReader(new FileReader(new File(selectedFile.getAbsolutePath())))) {

		            String line;
		            while ((line = reader.readLine()) != null)
		              contentArea.appendText(line +"\n");

		        } catch (IOException e) {
		            System.out.println("File is Empty..!");
		        }
		    }
		    
	}
	
}
