package application;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.converter.PicturesManager;
import org.apache.poi.hwpf.converter.WordToHtmlConverter;
import org.apache.poi.hwpf.usermodel.Picture;
import org.apache.poi.hwpf.usermodel.PictureType;
import org.w3c.dom.Document;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
/**
 * <p> Title: Document to HTML </p>
 * 
 * <p> Description: Apache POI demonstrates the conversion of doc to HTML. It supports the conversion for the document file before 
 * 2007 version. The code takes the file location and convert it from doc to HTML. If a user insert image in the file it automatically 
 * creates the file for that particular image. </p>
 * 
 * @author Arjun Dutta, Sumit Singh, Sawan Gaba
 * 
 * @version 1.0 Implementation for the conversion of the doc to HTML which creates a repository of of the image.
 * @version 1.6 Implementation for the conversion of the doc to HTML in the baseline code of E-book.
 */

public class DC implements Initializable {

   
	@FXML
	WebView webView;
	
    @FXML 
   private WebEngine webengine;
    
    @FXML 
    private Button cnvrt;
   
    private void hlw() {
    	System.out.println("Hello World");
    }
    public static void converted(String path ) throws IOException, ParserConfigurationException, TransformerException{
    	InputStream input = new FileInputStream (path );
        HWPFDocument wordDocument = new HWPFDocument (input);
        WordToHtmlConverter wordToHtmlConverter = new WordToHtmlConverter (DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument() );
        wordToHtmlConverter.setPicturesManager (new PicturesManager() {
            public String savePicture (byte[] content, PictureType pictureType, String suggestedName, float widthInches, float heightInches) {
                return suggestedName;
               
            }
            
        });
        wordToHtmlConverter.processDocument (wordDocument);
        List<?> pics = wordDocument.getPicturesTable().getAllPictures();
        if (pics != null) {
            for (int i = 0; i <pics.size(); i++) {
                Picture pic = (Picture) pics.get (i);
                try {
                    pic.writeImageContent (new FileOutputStream (path + pic.suggestFullFileName() ) );
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
        Document htmlDocument = wordToHtmlConverter.getDocument();
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        DOMSource domSource = new DOMSource (htmlDocument);
        StreamResult streamResult = new StreamResult (outStream);

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer serializer = tf.newTransformer();
        serializer.setOutputProperty (OutputKeys.ENCODING, "gbk");
        serializer.setOutputProperty (OutputKeys.INDENT, "yes");
        serializer.setOutputProperty (OutputKeys.METHOD, "html");
        serializer.transform (domSource, streamResult);
        outStream.close();

        String content = new String (outStream.toByteArray() );

        writeFile (content, path + "hemant34.html", "gbk");
        

    }
    
    public void convert() {
    	 final String path = "D:/college projects/Semester 4/Project lab/sample/ab1.doc";
    	try {
			converted(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /**
	 * The write file
	 * @param content
	 * @param path
	 * @param encode
	 */
	public static void writeFile(String content, String path, String encode) {
		FileOutputStream fos = null;
		BufferedWriter bw = null;
		try {
			File file = new File(path);
			fos = new FileOutputStream(file);
			bw = new BufferedWriter(new OutputStreamWriter(fos, encode));
			bw.write(content);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bw != null){
					bw.close();
				}
				if (fos != null){
					fos.close();
				}
			} catch (IOException ie) {
				ie.printStackTrace();
			}
		}
	}




	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		cnvrt.setOnAction((event) -> {convert();});
		 this.webengine = this.webView.getEngine();
		    this.webengine.load("http://google.com");
		
		
	}
	
}
