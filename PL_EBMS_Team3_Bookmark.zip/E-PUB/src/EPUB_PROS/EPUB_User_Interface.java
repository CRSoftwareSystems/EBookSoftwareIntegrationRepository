package EPUB_PROS;


import java.io.BufferedReader; 
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

import EPUB_OMEGA.Bookmark_View;

import EPUB_OMEGA.Web_View;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * 
 * @author Shane
 * 01-04-2019, Monday
 * The purpose to create this class is to setup the Main User_Interface of the EPUB application.
 */
public class EPUB_User_Interface 
{
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX        Define the variables and objects globally in order               XXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX        to access from another class according to their specifiers.      XXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	public static MenuBar omegaBar;
	public static Menu hambMenu;
	private Menu history, bookMark, zoomIn, zoomOut, modification, themes, restartApp, systemConfig, exit;
	public static MenuItem historyView, bookMarkView, restartSys, shutdownSys, edit, copy, paste, delete,
	                       darkTheme, silverTheme;
	
	private Label historyLabel, viewHistoryLabel, bookMarkLabel, viewBookMarkLabel, zoomInLabel, zoomOutLabel, modificationLab,
	              themesLab, restartAppLab, systemConfigLab, exitLab, restartSysLab, shutdownSysLab, editLab, copyLab, pasteLab,
	              deleteLab, darkThemeLab, silverThemeLab;
	
	public static TextField searchBar;
	public static ToolBar gammaBar;
	private Button search, addNotes, forward, backward, reload, playSound, stopSound;
	private Image searchImg, hambImg, historyImg, viewImg, bookmarkImg, viewBookmark, addNotesImg, quitImg, notesImg, forwardImg, 
	              backwardImg, reloadImg, zoomInImg, zoomOutImg, modificationImg, themesImg, restartAppImg, systemConfigImg,
	              exitImg, restartSysImg, shutdownSysImg, editImg, copyImg, pasteImg, deleteImg, darkThemeImg, silverThemeImg,
	              runSoundImg, stopSoundImg;
	private ImageView searchImgView, hambImgView, historyImgView, viewImgView, bookmarkImgView, viewBookmarkView, 
	                  addNotesView, quitView, notesView, forwardView, backwardView, reloadView, zoomInView, zoomOutView,
	                  modificationView, themesView, restartAppView, systemConfigView, exitView, restartSysView, shutdownSysView,
	                  editView, copyView, pasteView, deleteView, darkThemeView, silverThemeView, runSoundView, stopSoundView;
	
	public static TabPane tabPane;
	private Tab furryWebView, hawkHistoryView, bookmarkTab;
	private Group web_View_Group, history_View_Group, bookmarkGroup;
	public static DropShadow shadowEffect;
	
	public static TabPane notesPane;
	private Tab notesTab, quitTab;
	private TextArea notesArea;
	private Group notesGroup;
	
	double notesSceneX, notesSceneY;
	double notesTranslateX, notesTranslateY;
	private static Stage alertStage;
	private File notesFile;
	
	// Access the icon for stage or Access image to set as a icon on stage
    private final static String ALERT_ICON="/File_Error.png";
    private final static String ALERT_ICON_FILE="/File_Not_Found.png";
    
    private static AudioClip themeSong;
	public static AudioClip clickAud;
    private static URL themeSound, clickURL;
    
    private static Tooltip backTip, forwardTip, reloadTip, urlTip, searchTip, themeTip, notesTip, hambTip, homeTip, booksTip,
                           exitTip, logoutTip;
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX      Setup the Main UserInterface of the application      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	// Create the constructor of the current class
	public EPUB_User_Interface(Pane pane)
	{
		/**
		 * Calling Gradient methods in order to use at the program
		 */
		Gradient_Effects.gradient();
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX 
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX         SETUP VOICE OR AUDIO            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * Set up the theme song here
		 */
		// Acess the theme sound
		themeSound = EPUB_User_Interface.class.getResource("/riversolo.mp3");
		clickURL = EPUB_User_Interface.class.getResource("/ui.mp3");
		
		
		// Connect the sound with the audio player
		themeSong = new AudioClip(themeSound.toExternalForm());
		clickAud = new AudioClip(clickURL.toExternalForm());
		
		// Set the volume of the song or sound
		themeSong.setVolume(0.1);
		clickAud.setVolume(1);
		
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX            Setup Menubar for numerous purposes            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create an object of the menu bar
		omegaBar = new MenuBar();
		// Set the size of the menu bar
		omegaBar.setMaxWidth(100); omegaBar.setMinHeight(60);
		// Set the position of the Menu Bar
		omegaBar.setTranslateY(-340); omegaBar.setTranslateX(664);
		// Set the background color of the menu bar
		omegaBar.setBackground(new Background(new BackgroundFill(Color.rgb(40, 40, 40), CornerRadii.EMPTY, Insets.EMPTY)));
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX            Setup the web view in order to call the method of it   XXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		Web_View.web_Browser();
		
		/**
		 * Setup the Hamburger Icon in order to setup some menu lists
		 */
		// Create an object of the Image in order to access the image and setup as an icon
		hambImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/hamb.png"));
		// Create an object of the Image view in order to setup the image as an icon
		hambImgView = new ImageView(hambImg);
		// Set the width and height of the image
		hambImgView.setFitWidth(55); hambImgView.setFitHeight(55);
		
		// Create an object of the menu
		hambMenu = new Menu("", hambImgView);
		
		// Set the position of the menubar
		
		// Add items at the menu bar
		omegaBar.getMenus().add(hambMenu);
		
		/**
		 * Apply css at the menu options
		 */
		omegaBar.getStylesheets().add("ab.css");
		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                            Setup TabPane                                  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		
		
		
		/**
		 * Setup TabPane in order to open different tabs for different purposes
		 */
		// Create an object of the TabPane
		tabPane = new TabPane();
		// Set the size of the TabPane
		tabPane.setMinWidth(1335); tabPane.setMinHeight(100);
		// Set the position of the tabpane
		tabPane.setTranslateY(29);
		// Set the inside color of text area
		tabPane.setStyle("-fx-font-size:16; -fx-background-color: #36474F;");
		// Access the css file
		tabPane.getStylesheets().add("ab.css");
		
		// Create an object of the Web View tab
		furryWebView = new Tab("Browser Tab");
		// Create an object of the group
		web_View_Group = new Group();
		// Add the content or something want to add, here going to add web browser view
		web_View_Group.getChildren().add(Web_View.browser);
		// Connect with the tab
		furryWebView.setContent(web_View_Group);
		// Add tabs at the tabpane
		tabPane.getTabs().add(furryWebView);
		// Setup the tab when user open new tab then display new tab instead of current one
		tabPane.getSelectionModel().selectLast();
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                            Setup Hamburger Menu Items                     XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create an object of the Image in order to access the History image icon
		historyImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/history.png"));
		// Create an object of the Image View in order to setup the icon and display image
		historyImgView = new ImageView(historyImg);
		// Set the height and width of the image
		historyImgView.setFitWidth(35); historyImgView.setFitHeight(40);
		// Create an object of the History Menu
		history = new Menu();
		// Create an object of the label
		historyLabel = new Label("HISTORY          ",historyImgView);
		// Set the text color 
		historyLabel.setTextFill(Gradient_Effects.omega);
		
		// Set the size of the text
		historyLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the label at the Menu Option
		history.setGraphic(historyLabel);
		
		// Add items at the hamburger icon menu
		hambMenu.getItems().add(history);
		
		/**
		 * Setup the submenu item of sub menu
		 */
		// Create an object of the Image in order to access the view icon
		viewImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/view.png"));
		// Create an object of the Image view to view the icon
		viewImgView = new ImageView(viewImg);
		// Set the height and width of the image
		viewImgView.setFitWidth(40); viewImgView.setFitHeight(35);
		
		// Create an object of the menu item
		historyView = new MenuItem();
		
		// Create an object of the History Label
		viewHistoryLabel = new Label("View History ", viewImgView);
		// Set the font size of the text
		viewHistoryLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the text
		viewHistoryLabel.setTextFill(Gradient_Effects.omega);
		// Add the history label at the menu item
		historyView.setGraphic(viewHistoryLabel);
		
		// Add the subMenuItems at the Hamburger submenu
		history.getItems().add(historyView);
		
		
		
		/**
		 * Event handler of history view in order to open the History List
		 */
		historyView.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent historyEvent)
			{
				// Create an object of the Web View tab
				hawkHistoryView = new Tab("History");
				// Add the background color of the tab
				hawkHistoryView.setStyle("-fx-background-color: linear-gradient(to top right, rgba(130,30,51,1) 45.3%,"
						+ " rgba(95,123,190,1) 279% );");
				// Create an object of the group
				history_View_Group = new Group();
				// Add the content or something want to add, here going to add web browser view
				history_View_Group.getChildren().add(Web_View.history_List);
				// Connect with the tab
				hawkHistoryView.setContent(history_View_Group);
				// Add tabs at the tabpane
				tabPane.getTabs().add(hawkHistoryView);
				// Setup the tab when user open new tab then display new tab instead of current one
				tabPane.getSelectionModel().selectLast();
				
				
			}
				});
		
		
		/**
		 * Setup the Bookmark Menu Items in order to allow the user to bookmark the URL if user feels important which
		 * allows to the user to visit that url at any time in future.
		 */
		// Create an object of the Image in order to access the bookmark icon
		bookmarkImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/bookmark.png"));
		// Create an object of the Image view to view the image or icon
		bookmarkImgView = new ImageView(bookmarkImg);
		// Set the height and width of the image
		bookmarkImgView.setFitWidth(40); bookmarkImgView.setFitHeight(35);
		
		// Create an object the sub menu item
		bookMark = new Menu();
		
		// Create an object of the bookmakr label
		bookMarkLabel = new Label("BOOKMARK         ", bookmarkImgView);
		// set the font size of the bookmark label
		bookMarkLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the menu text
		bookMarkLabel.setTextFill(Gradient_Effects.omega);
		
		// Add the label at the Menu option
		bookMark.setGraphic(bookMarkLabel);
		
		// Add the sub menu items at the Hamburger menu option
		hambMenu.getItems().add(bookMark);
		
		/**
		 * Setup the menu item at the bookmark menu which is submenu of the hamburger menu
		 */
		// Create an object of the Image in order to access the bookmark icon
		viewBookmark = new Image(EPUB_User_Interface.class.getResourceAsStream("/View_Bookmark.png"));
		// Create an object of the Image view to view the image or icon
		viewBookmarkView = new ImageView(viewBookmark);
		// Set the height and width of the image
		viewBookmarkView.setFitWidth(40); viewBookmarkView.setFitHeight(35);
		// Create an object of the bookmark menu item
		bookMarkView = new MenuItem();
		
		// Create an object of the bookmark view label
		viewBookMarkLabel = new Label("View Bookmark ",viewBookmarkView);
		// Set the font size of the label
		viewBookMarkLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		viewBookMarkLabel.setTextFill(Gradient_Effects.omega);
		
		// Set the label at the menu item
		bookMarkView.setGraphic(viewBookMarkLabel);
		
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		bookMark.getItems().add(bookMarkView);
		
		/**
		 * Call the bookmark_List() method 
		 */
		Bookmark_View.bookmark_List();
		/**
		 * Event Handling of the bookmark menu item
		 */
		bookMarkView.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent bookmarkEvent)
			{
				// Create an object of the tab
				bookmarkTab = new Tab("Bookmark");
				// Add the background color of the tab
				bookmarkTab.setStyle("-fx-background-color: linear-gradient(to top right, rgba(130,30,51,1) 45.3%, rgba(95,123,190,1) 279% );");
				
				// Create an object of the group
				bookmarkGroup = new Group();
				// Group the object of the bookmark tab
				bookmarkGroup.getChildren().addAll(Bookmark_View.bookmark_Table_View, Bookmark_View.visit,
						                           Bookmark_View.delete,
						                           Bookmark_View.hBox);
				// Connect with the tab
				bookmarkTab.setContent(bookmarkGroup);
				// Add tabs at the tabpane
				tabPane.getTabs().add(bookmarkTab);
				// Setup the tab when user open new tab then display new tab instead of current one
				tabPane.getSelectionModel().selectLast();
			}
				});
		
		/**
		 * Setup the Zoom In and Zoom out options at the menu items
		 */
		// Create an object of the Image in order to access the zoom in icon
		zoomInImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/Zoom_In.png"));
		// Create an object of the Image view to view the image or icon
		zoomInView = new ImageView(zoomInImg);
		// Set the height and width of the image
		zoomInView.setFitWidth(40); zoomInView.setFitHeight(35);
		// Create an object of the zoom In menu item
		zoomIn = new Menu();
		
		// Create an object of the zoom In view label
		zoomInLabel = new Label("Zoom In ",zoomInView);
		// Set the font size of the label
		zoomInLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		zoomInLabel.setTextFill(Gradient_Effects.omega);
		
		// Set the label at the menu item
		zoomIn.setGraphic(zoomInLabel);
		
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(zoomIn);
		
		/**
		 * Event handling on zoom in and zoom in menu options
		 */
		zoomIn.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent zoomOutEvent)
			{
				// Reduce or Zoom in the web browser
				Web_View.browser.setZoom(Web_View.browser.getZoom() * 1.2);
			}
				});
		
		/**
		 * Setup the zoom out menu item
		 */
		// Create an object of the Image in order to access the zoom out icon
		zoomOutImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/Zoom_Out.png"));
		// Create an object of the Image view to view the image or icon
		zoomOutView = new ImageView(zoomOutImg);
		// Set the height and width of the image
		zoomOutView.setFitWidth(40); zoomOutView.setFitHeight(35);
		// Create an object of the zoom Out menu item
		zoomOut = new Menu();
		
		// Create an object of the zoom Out view label
		zoomOutLabel = new Label("Zoom Out ",zoomOutView);
		// Set the font size of the label
		zoomOutLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		zoomOutLabel.setTextFill(Gradient_Effects.omega);
		
		// Set the label at the menu item
		zoomOut.setGraphic(zoomOutLabel);
			
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(zoomOut);
		
		/**
		 * Event handling on zoom in and zoom out menu options
		 */
		zoomOut.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent zoomOutEvent)
			{
				// Reduce or Zoom out the web browser
				Web_View.browser.setZoom(Web_View.browser.getZoom() /1.2);
			}
				});
		/**
		 * Set up the event on key board in order to zoom in and out the browser view
		 */
		Web_View.browser.addEventFilter(KeyEvent.KEY_RELEASED, (KeyEvent keyEvent) ->
		{
			if(keyEvent.getCode() == KeyCode.ADD || keyEvent.getCode() == KeyCode.EQUALS || keyEvent.getCode() == KeyCode.PLUS)
			{
				// Zoom in when Plus or Equal keys entered by key board
				Web_View.browser.setZoom(Web_View.browser.getZoom() * 1.2);
			}
			else if(keyEvent.getCode() == KeyCode.SUBTRACT || keyEvent.getCode() == KeyCode.MINUS)
			{
				// Reduce or Zoom out the web browser
				Web_View.browser.setZoom(Web_View.browser.getZoom() /1.2);
			}
		});
		
		/**
		 * Setup the Modification menu where add the four features which is edit, paste, delete, copy as a menu items where user 
		 * can perform such task at the application.
		 */
		// Create an object of the Image in order to access the modification icon
		modificationImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/modification.png"));
		// Create an object of the Image view to view the image or icon
		modificationView = new ImageView(modificationImg);
		// Set the height and width of the image
		modificationView.setFitWidth(40); modificationView.setFitHeight(35);
		// Create an object of the modification menu item
		modification = new Menu();
		
		// Create an object of the modification view label
		modificationLab = new Label("Modification View ",modificationView);
		// Set the font size of the label
		modificationLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		modificationLab.setTextFill(Gradient_Effects.omega);
		
		// Set the label at the modification item
		modification.setGraphic(modificationLab);
			
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(modification);
		
		/*******************************************************************************************************************************
		 * *********************************          Setup Modification Menu Items             ****************************************
		 ******************************************************************************************************************************/
		// Create an object of the Image in order to access the Edit icon
		editImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/edit.png"));
		// Create an object of the Image view to view the image or icon
		editView = new ImageView(editImg);
		// Set the height and width of the image
		editView.setFitWidth(40); editView.setFitHeight(35);
		// Create an object of the Edit menu item
		edit = new MenuItem();
				
		// Create an object of the Edit view label
		editLab = new Label("Edit                    ",editView);
		// Set the font size of the label
		editLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		editLab.setTextFill(Gradient_Effects.omega);
				
		// Set the label at the Edit item
		edit.setGraphic(editLab);
				
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		modification.getItems().add(edit);
		
		/**
		 * Setup the Copy menu items
		 */
		// Create an object of the Image in order to access the copy icon
		copyImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/copy.png"));
		// Create an object of the Image view to view the copy or icon
		copyView = new ImageView(copyImg);
		// Set the height and width of the image
		copyView.setFitWidth(40); copyView.setFitHeight(35);
		// Create an object of the copy menu
		copy = new MenuItem();
						
		// Create an object of the copy view label
		copyLab = new Label("Copy ",copyView);
		// Set the font size of the label
		copyLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		copyLab.setTextFill(Gradient_Effects.omega);
						
		// Set the label at the copy
		copy.setGraphic(copyLab);
						
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		modification.getItems().add(copy);
		
		/**
		 * Setup the paste menu items
		 */
		// Create an object of the Image in order to access the paste icon
		pasteImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/paste.png"));
		// Create an object of the Image view to view the copy or icon
		pasteView = new ImageView(pasteImg);
		// Set the height and width of the image
		pasteView.setFitWidth(40); pasteView.setFitHeight(35);
		// Create an object of the paste menu
		paste = new MenuItem();
								
		// Create an object of the paste view label
		pasteLab = new Label("Paste ",pasteView);
		// Set the font size of the label
		pasteLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		pasteLab.setTextFill(Gradient_Effects.omega);
								
		// Set the label at the paste menu
		paste.setGraphic(pasteLab);
								
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		modification.getItems().add(paste);
		
		
		/**
		 * Setup the Delete menu items in order to delte the object or something what the user selected
		 */
		// Create an object of the Image in order to access the delete icon
		deleteImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/remove.png"));
		// Create an object of the Image view to view the delete or icon
		deleteView = new ImageView(deleteImg);
		// Set the height and width of the image
		deleteView.setFitWidth(40); deleteView.setFitHeight(35);
		// Create an object of the delete menu
		delete = new MenuItem();
										
		// Create an object of the delete view label
		deleteLab = new Label("Delete ",deleteView);
		// Set the font size of the label
		deleteLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		deleteLab.setTextFill(Gradient_Effects.omega);
										
		// Set the label at the delete menu
		delete.setGraphic(deleteLab);
										
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		modification.getItems().add(delete);
				
				
				
		/**
		 * Setpup the Themes menu where user can change the application themes as per their likes.
		 */
		// Create an object of the Image in order to access the Theme icon
		themesImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/Theme.png"));
		// Create an object of the Image view to view the image or icon
		themesView = new ImageView(themesImg);
		// Set the height and width of the image
		themesView.setFitWidth(40); themesView.setFitHeight(35);
		// Create an object of the theme menu item
		themes = new Menu();
				
		// Create an object of the theme view label
		themesLab = new Label("Themes ",themesView);
		// Set the font size of the label
		themesLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		themesLab.setTextFill(Gradient_Effects.omega);
				
		// Set the label at the theme item
		themes.setGraphic(themesLab);
				
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(themes);
		
		
		/*******************************************************************************************************************************
		 * *********************************          Setup Themes Menu Items             ****************************************
		 ******************************************************************************************************************************/
		/**
		 * Setup the two themes where user can change as per their likes.
		 * Here, firstly setup the Dark Theme 
		 */
		// Create an object of the Image in order to access the Dark theme icon
		darkThemeImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/dark_Theme.png"));
		// Create an object of the Image view to view the image or icon
		darkThemeView = new ImageView(darkThemeImg);
		// Set the height and width of the image
		darkThemeView.setFitWidth(40); darkThemeView.setFitHeight(35);
		// Create an object of the Dark theme menu item
		darkTheme = new MenuItem();
						
		// Create an object of the Dark theme view label
		darkThemeLab = new Label("Dark Theme                    ",darkThemeView);
		// Set the font size of the label
		darkThemeLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		darkThemeLab.setTextFill(Gradient_Effects.omega);
						
		// Set the label at the Dark theme item
		darkTheme.setGraphic(darkThemeLab);
						
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		themes.getItems().add(darkTheme);
		
		
		/**
		 * Setup the Silver theme
		 */
		// Create an object of the Image in order to access the Silver theme icon
		silverThemeImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/silver_Theme.png"));
		// Create an object of the Image view to view the image or icon
		silverThemeView = new ImageView(silverThemeImg);
		// Set the height and width of the image
		silverThemeView.setFitWidth(40); silverThemeView.setFitHeight(35);
		// Create an object of the Silver theme menu item
		silverTheme = new MenuItem();
								
		// Create an object of the Silver theme view label
		silverThemeLab = new Label("Silver Theme                    ",silverThemeView);
		// Set the font size of the label
		silverThemeLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		silverThemeLab.setTextFill(Gradient_Effects.omega);
								
		// Set the label at the Silver theme item
		silverTheme.setGraphic(silverThemeLab);
								
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		themes.getItems().add(silverTheme);
		
		
		/**
		 * Setup the restart option to restart the application
		 */
		// Create an object of the Image in order to access the restart icon
		restartAppImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/restart_App.png"));
		// Create an object of the Image view to view the image or icon
		restartAppView = new ImageView(restartAppImg);
		// Set the height and width of the image
		restartAppView.setFitWidth(40); restartAppView.setFitHeight(35);
		// Create an object of the restart menu item
		restartApp = new Menu();
						
		// Create an object of the restart label
		restartAppLab = new Label("Restart App ",restartAppView);
		// Set the font size of the label
		restartAppLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		restartAppLab.setTextFill(Gradient_Effects.omega);
						
		// Set the label at the restart item
		restartApp.setGraphic(restartAppLab);
						
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(restartApp);
		
		/**
		 * Event handling on to the restart menu item
		 */
		restartApp.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent exitEvent)
			{
				// Close the Application
				EPUB_MAIN.stg.close();
				// Launch the application again
				Platform.runLater( () -> new EPUB_MAIN().start( new Stage() ) );
			}
				});
		/**
		 * Setup the SystemConfig option or menu item in order to restart and shut down the system
		 */
		// Create an object of the Image in order to access the system Config icon
		systemConfigImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/system_Config.png"));
		// Create an object of the Image view to view the image or icon
		systemConfigView = new ImageView(systemConfigImg);
		// Set the height and width of the image
		systemConfigView.setFitWidth(40); systemConfigView.setFitHeight(35);
		// Create an object of the system config menu item
		systemConfig = new Menu();
								
		// Create an object of the system config label
		systemConfigLab = new Label("System Config ",systemConfigView);
		// Set the font size of the label
		systemConfigLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		systemConfigLab.setTextFill(Gradient_Effects.omega);
								
		// Set the label at the system config item
		systemConfig.setGraphic(systemConfigLab);
								
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(systemConfig);
		/*******************************************************************************************************************************
		 * *********************************          Setup System Configuration Menu Items        *************************************
		 ******************************************************************************************************************************/
		/**
		 * Setup the System configuration where setup the two menu items which is Restart System, and another one is
		 * Shutdown system.
		 * If user want to restart and shutdown the system then user can perform such task from current application
		 * instead to move desktop features.
		 */
		// Create an object of the Image in order to access the Restart system icon
		restartSysImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/restart.png"));
		// Create an object of the Image view to view the image or icon
		restartSysView = new ImageView(restartSysImg);
		// Set the height and width of the image
		restartSysView.setFitWidth(40); restartSysView.setFitHeight(35);
		// Create an object of the Restart system  menu item
		restartSys = new MenuItem();
						
		// Create an object of the Restart system  view label
		restartSysLab = new Label("Restart System   ",restartSysView);
		// Set the font size of the label
		restartSysLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		restartSysLab.setTextFill(Gradient_Effects.omega);
						
		// Set the label at the Restart system  item
		restartSys.setGraphic(restartSysLab);
						
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		systemConfig.getItems().add(restartSys);
		
		/**
		 * Event handling to restart the system
		 */
		restartSys.setOnAction(new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent event)
			{
				try
				{
					Runtime.getRuntime().exec("shutdown -r -t 0");
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
					
				}
			}
		});
		
		
		/**
		 * Setup the option of Shutdown in order to shutdown the system
		 */
		// Create an object of the Image in order to access the Shutdown system icon
		shutdownSysImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/shutdown.png"));
		// Create an object of the Image view to view the image or icon
		shutdownSysView = new ImageView(shutdownSysImg);
		// Set the height and width of the image
		shutdownSysView.setFitWidth(40); shutdownSysView.setFitHeight(35);
		// Create an object of the Shutdown system  menu item
		shutdownSys = new MenuItem();
							
		// Create an object of the Shutdown system  view label
		shutdownSysLab = new Label("Shutdown System     ",shutdownSysView);
		// Set the font size of the label
		shutdownSysLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		shutdownSysLab.setTextFill(Gradient_Effects.omega);
								
		// Set the label at the Shutdown system  item
		shutdownSys.setGraphic(shutdownSysLab);
								
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		systemConfig.getItems().add(shutdownSys);
		
		/**
		 * Event handling to shutdown the system
		 */
		shutdownSys.setOnAction(new EventHandler<ActionEvent>()
		{
			public void handle(ActionEvent event)
			{
				try
				{
					Runtime.getRuntime().exec("shutdown -s -t 0");
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
					
				}
			}
		});
		/**
		 * Setup the Exit option or menu item in order to close the application
		 */
		// Create an object of the Image in order to access the exit icon
		exitImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/exit.png"));
		// Create an object of the Image view to view the image or icon
		exitView = new ImageView(exitImg);
		// Set the height and width of the image
		exitView.setFitWidth(40); exitView.setFitHeight(35);
		// Create an object of the exit menu item
		exit= new Menu();
								
		// Create an object of the exit label
		exitLab = new Label("Exit ",exitView);
		// Set the font size of the label
		exitLab.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Set the color of the label
		exitLab.setTextFill(Gradient_Effects.omega);
								
		// Set the label at the exit item
		exit.setGraphic(exitLab);
										
		// Add the menu item at the Menu option which is submenu of the hamburger menu 
		hambMenu.getItems().add(exit);
		
		/**
		 * Event handling on to the exit menu item
		 */
		exit.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent exitEvent)
			{
				// Close the application
				EPUB_MAIN.stg.close();
			}
				});
		
		

		
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX            Setup ToolBar for numerous purposes            XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		// Create an object of the Tool bar
		gammaBar = new ToolBar();
		// Set the size of the toolbar
		gammaBar.setMaxWidth(928); gammaBar.setMinHeight(60);
		// Set the position of the of the tool bar
		gammaBar.setTranslateY(-340); gammaBar.setTranslateX(-230);
		// Set the background of the tool bar
		gammaBar.setBackground(new Background(new BackgroundFill(Color.rgb(40, 40, 40), CornerRadii.EMPTY, Insets.EMPTY)));
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX            Setup Forward and backward pages               XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		
		
		/**
		 * Create two option which is forward and backward in order to go back and go forward pages or scenes,
		 * where user can reach at back and forward page when required
		 */
		// Create an object of the image and access the backward icon
		backwardImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/backward.png"));
		// Create an object of the Image view to view an image
		backwardView = new ImageView(backwardImg);
		// Set the height and width of the image
		backwardView.setFitWidth(40); backwardView.setFitHeight(35);
		
		// Create an object of the backward button
		backward = new Button("", backwardView);
		// Hide the background from the button
		backward.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		// Create an object of tooltip
		backTip = new Tooltip();
		// Set the text what want to display
		backTip.setText("Return Back");
		// Set the font of the tooltip text
		backTip.setFont(Font.font("Arial", FontPosture.ITALIC, 20));
		// Set the color of the text
		backTip.setStyle("-fx-base: #AE3522; -fx-background-radius: 30; -fx-text-fill: orange;");
		// Set the tooltip on which field want to display
		backward.setTooltip(backTip);
		
		/**
		 * Setup Mouse Hover Effect on backward Button
		 */
		backward.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				backward.setEffect(shadowEffect);
				// Set the background color on hover
				backward.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );");
				
			}
				});
		
		backward.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				backward.setEffect(null);
				// Disable background color on hovor end
				backward.setStyle("-fx-background-color: transparent;");
			}
				});
		/**
		 * Event handling of the backward button
		 */
		backward.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent forwardEvent)
			{
				// Go backward when user click onto the backward button
				Web_View.web_History.go(-1);
				// Play sound 
				clickAud.play();
			}
				});
		
		// Create an object of the image and access the forward icon
		forwardImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/forward.png"));
		// Create an object of the image view to view an image
		forwardView = new ImageView(forwardImg);
		// Set the size of the image
		forwardView.setFitHeight(35); forwardView.setFitWidth(40);
		
		// Create an object of the forward button
		forward = new Button("", forwardView);
		// Hide the background from the button
		forward.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		// Create an object of tooltip
		forwardTip = new Tooltip();
		// Set the text what want to display
		forwardTip.setText("Go Forward");
		// Set the font of the tooltip text
		forwardTip.setFont(Font.font("Arial", FontPosture.ITALIC, 20));
		// Set the color of the text
		forwardTip.setStyle("-fx-base: #AE3522; -fx-background-radius: 30; -fx-text-fill: orange;");
		// Set the tooltip on which field want to display
		forward.setTooltip(forwardTip);
		/**
		 * Setup Mouse Hover Effect on forward Button
		 */
		forward.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				forward.setEffect(shadowEffect);
				// Set the background color on hover
				forward.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );");
			}
				});
		
		forward.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				forward.setEffect(null);
				// Disable background color on hovor end
				forward.setStyle("-fx-background-color: transparent;");
			}
				});
		/**
		 * Event handling of the forward button
		 */
		forward.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent forwardEvent)
			{
				// Go forward when user click onto the forward button
				Web_View.web_History.go(1);
				// Play sound 
				clickAud.play();
			}
				});
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX            Setup Reload option to reload the web page      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * Setup the reload button in order to relaod the page if required
		 */
		// Create an object of the image in order to access the reload icon
		reloadImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/reload.png"));
		// Create an object of the image view to view an image
		reloadView = new ImageView(reloadImg);
		// Set the size of the image 
		reloadView.setFitWidth(45); reloadView.setFitHeight(40);
		
		// Create an object of the reload button
		reload = new Button("", reloadView);
		// Hide the background 
		reload.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		
		// Create an object of tooltip
		reloadTip = new Tooltip();
		// Set the text what want to display
		reloadTip.setText("Reload the page");
		// Set the font of the tooltip text
		reloadTip.setFont(Font.font("Arial", FontPosture.ITALIC, 20));
		// Set the color of the text
		reloadTip.setStyle("-fx-base: #AE3522; -fx-background-radius: 30; -fx-text-fill: orange;");
		// Set the tooltip on which field want to display
		reload.setTooltip(reloadTip);
		/**
		 * Setup Mouse Hover Effect on reload Button
		 */
		reload.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				reload.setEffect(shadowEffect);
				// Set the background color on hover
				reload.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );");
			}
				});
		
		reload.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				reload.setEffect(null);
				// Disable background color on hovor end
				reload.setStyle("-fx-background-color: transparent;");
			}
				});
		/**
		 * Event handling of the relaod button
		 */
		reload.setOnAction(new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent reloadEvent)
			{
				// Reload the page
				Web_View.web_Engine.reload();
				// Play sound 
				clickAud.play();
			}
				});
		
		
		// Create an object of the text field 
		searchBar = new TextField();
		// Set the size of the field
		searchBar.setMinHeight(45); searchBar.setMinWidth(600);
		// Set the position of the text field
		searchBar.setTranslateX(60);
		// Set the border circular of the field
		searchBar.setStyle("-fx-background-radius: 30; -fx-text-fill: #00ff00; -fx-background-color: black;");
		// Set the hint text inside the text field
		searchBar.setPromptText("Enter the URL....");
		// Set the size and the style of the text
		searchBar.setFont(Font.font("Helvetica", FontPosture.ITALIC, 20));	
		
		// Create an object of tooltip
		urlTip = new Tooltip();
		// Set the text what want to display
		urlTip.setText("Enter the URL");
		// Set the font of the tooltip text
		urlTip.setFont(Font.font("Arial", FontPosture.ITALIC, 20));
		// Set the color of the text
		urlTip.setStyle("-fx-base: #AE3522; -fx-background-radius: 30; -fx-text-fill: orange;");
		// Set the tooltip on which field want to display
		searchBar.setTooltip(urlTip);
		
		
		/**
		 * Setup the Search button
		 */
		/*node.setStyle("-fx-border-color: firebrick; -fx-border-width: 10; -fx-border-style: solid outside line-join miter;");
		node.setStyle("-fx-stroke: firebrick; -fx-stroke-width: 10; -fx-stroke-type: outside;");
		*/
		// Create an object of the image in order to access the image and setup as an icon onto the button
		searchImg = new Image(EPUB_User_Interface.class.getResourceAsStream("/Find.png"));
		// Create an object of the Image view and setup icon on to the button
		searchImgView = new ImageView(searchImg);
		// Set the size of the icon
		searchImgView.setFitHeight(35); searchImgView.setFitWidth(55);
		// Create an object of the button and setup the image instead of the text
		search = new Button("", searchImgView);
		// Set the the size of the text
		search.setFont(Font.font("Helvetica", FontWeight.BOLD, FontPosture.ITALIC, 20));
		// Hide the background of the button
		search.setStyle("-fx-background-insets: 40, 40, 40, 40;");
		// Set the position of the button
		search.setTranslateX(60);
		
		
		
		// Create an object of tooltip
		searchTip = new Tooltip();
		// Set the text what want to display
		searchTip.setText("Visit URL Link");
		// Set the font of the tooltip text
		searchTip.setFont(Font.font("Arial", FontPosture.ITALIC, 20));
		// Set the color of the text
		searchTip.setStyle("-fx-base: #AE3522; -fx-background-radius: 30; -fx-text-fill: orange;");
		// Set the tooltip on which field want to display
		search.setTooltip(searchTip);
		/**
		 * Setup Mouse Hover Effect on search Button
		 */
		search.addEventHandler(MouseEvent.MOUSE_ENTERED,  new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Add Effect 
				search.setEffect(shadowEffect);
				// Set the background color on hover
				search.setStyle("-fx-background-color: linear-gradient(to top right, rgba(180,39,93,1) 0%,rgba(37,28,208,1) 90% );"
						+ "-fx-background-radius: 30;");
			}
				});
		
		search.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>()
				{
			public void handle(MouseEvent notesEvent)
			{
				// Disable hover effect
				search.setEffect(null);
				// Disable background color on hovor end
				search.setStyle("-fx-background-color: transparent;");
			}
				});
		
		/**
		 * Event handling of the search button
		 */
		EventHandler<ActionEvent> searchEvent = new EventHandler<ActionEvent>()
				{
			public void handle(ActionEvent event)
			{
				// Store the text field text at the string and load the page then view at the web view
				String url= searchBar.getText().toString();
				// Load the url with the help of engine
				Web_View.web_Engine.load(url);
				// Play sound 
				clickAud.play();
			}
				};
		// Set the event onto the search button
		search.setOnAction(searchEvent);
		
		
	
		
				
				
				
				
		
		// Add the search field into the toolbar
		gammaBar.getItems().addAll(searchBar, search);
				
		
		
		
		// Group the children at the pane in order to display at the window 
		pane.getChildren().addAll();
	}
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX     Setup the method to save the notes at the file        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	private void saveTextAreaData(String data, File file)
	{
        try 
        {
        	// Create an object of the file writer
            FileWriter fileWriter = new FileWriter(file);
            // Write the data 
            fileWriter.write(data);
            // Close the writer
            fileWriter.close();
        } 
        catch (IOException ex) 
        {
        	/**
        	 * Display alert window if file not found
        	 */
        	
        	/**
			 * Setup the alert window if loading failed at any case like Not connected with the internet or something
			 * else reason.
			 */
			Alert alertWindow = new Alert(AlertType.WARNING);
			// Set the dialog pane
			DialogPane dialog = alertWindow.getDialogPane();
			// Set the background of the alert window
			dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
			// Add the Effect on dialog
			dialog.setEffect(shadowEffect);
			// Set the text color 
			dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
			// Set the title of the window
			alertWindow.setTitle("Loading Error");
			// Set the header text
			alertWindow.setHeaderText("Loading Failed!");
			// Set the message for the user in brief
			alertWindow.setContentText("Please, check your internet connection!");
			// Create an object of the Stage and set the icon onto the alert window
			alertStage = (Stage) alertWindow.getDialogPane().getScene().getWindow();
			// Set the image as an window icon
			alertStage.getIcons().add(new Image(ALERT_ICON_FILE));
			// Set the height of the alert window
			alertWindow.getDialogPane().setMinHeight(200);
			// Set the width of the alert window
			alertWindow.getDialogPane().setMinWidth(500);
			// Display alert window
			alertWindow.showAndWait();
        }
          
    }
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX     Setup the method to read the file and display at notes section     XXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	private String readData(File notes)
	 {
		// Create an object of the String builder
		StringBuilder buffer = new StringBuilder();
		// Create an object of the file reader to read the file
		FileReader notesRead = null;
		try 
		{
			// Read the file if file exist
			notesRead = new FileReader(notes);
		} 
		catch (FileNotFoundException fileNotFoundException)
		{
			/**
			 * Display alert window if file not found
			 */
			/**
			 * Setup the alert window if loading failed at any case like Not connected with the internet or something
			 * else reason.
			 */
			Alert alertWindow = new Alert(AlertType.WARNING);
			// Set the dialog pane
			DialogPane dialog = alertWindow.getDialogPane();
			// Set the background of the alert window
			dialog.setBackground(new Background(new BackgroundFill(Gradient_Effects.omega, CornerRadii.EMPTY, Insets.EMPTY)));
			// Add the Effect on dialog
			dialog.setEffect(shadowEffect);
			// Set the text color 
			dialog.setStyle("-fx-font-weight: bold; -fx-border-color: red; -fx-font-size: 20;");
			// Set the title of the window
			alertWindow.setTitle("File Error");
			// Set the header text
			alertWindow.setHeaderText("File Not Found!");
			// Set the message for the user in brief
			alertWindow.setContentText("Sorry, File couldn't Found!");
			// Create an object of the Stage and set the icon onto the alert window
			alertStage = (Stage) alertWindow.getDialogPane().getScene().getWindow();
			// Set the image as an window icon
			alertStage.getIcons().add(new Image(ALERT_ICON));
			// Set the height of the alert window
			alertWindow.getDialogPane().setMinHeight(200);
			// Set the width of the alert window
			alertWindow.getDialogPane().setMinWidth(500);
			// Display alert window
			alertWindow.showAndWait();
		}
		// Create an object of the buffered reader
		BufferedReader notesBufReader = new BufferedReader(notesRead);
		// Create the String variable to store the read data
		String notesStorage;
		// Implement the logic to read the file line by line via buffer reader
		try 
		{
			while((notesStorage = notesBufReader.readLine()) != null)
			{
				// Append the text 
				buffer.append(notesStorage);
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		    // Return the data in to the string form
	        return buffer.toString();
	    }
	
	/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 * XXXXXXXXXXXXXXXXXX     Setup the Draggable events on to the notes section    XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
	 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
	
	 /**
     * Setup the mouse event onto the Notes Section where set event on mouse pressed
     * 
     */
    EventHandler<MouseEvent> mousePressed = new EventHandler<MouseEvent>()
    		{
    	public void handle(MouseEvent mouseEvent)
    	{
    		// get the scene vertical and horizontal and give control on mouse event
    		notesSceneX = mouseEvent.getSceneX();
    		notesSceneY = mouseEvent.getSceneY();
    		// Get the allowance to set the positon on mouse event
    		notesTranslateX = ((TabPane)(mouseEvent.getSource())).getTranslateX();
    		notesTranslateY = ((TabPane)(mouseEvent.getSource())).getTranslateY();
    	}
    		};
    /**
     * Set up the event to drag the Notes Section
     */
    EventHandler<MouseEvent> mouseDragged = new EventHandler<MouseEvent>()
    		{
    	public void handle(MouseEvent mouseEvent)
    	{
    		double textOffSetX = mouseEvent.getSceneX() - notesSceneX;
    		double textOffSetY = mouseEvent.getSceneY() - notesSceneY;
    		double textNewTranslateX = notesTranslateX + textOffSetX;
    		double textNewTranslateY = notesTranslateY + textOffSetY;
    		
    		((TabPane)(mouseEvent.getSource())).setTranslateX(textNewTranslateX);
    		((TabPane)(mouseEvent.getSource())).setTranslateY(textNewTranslateY);
    	}
    		};
}
