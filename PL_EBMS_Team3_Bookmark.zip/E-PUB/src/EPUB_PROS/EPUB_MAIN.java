package EPUB_PROS;

import java.io.File;  


import EPUB_OMEGA.Web_View;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBoxBuilder;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.VBoxBuilder;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

/**
 * 
 * @author Shane
 * 11-03-2019, Monday
 * 
 * Main class of the program
 */

// Extend the Application class in order to use or implements the Java-FX methods
// In order to import images from folder, Build that folder which helps to behave like a source folder

@SuppressWarnings("deprecation")
public class EPUB_MAIN extends Application
{
	// Access the icon for stage or Access image to set as a icon on stage
	public static final String APPLICATION_ICON="umbrella.png";	
	
	
	@SuppressWarnings("unused")
	private EPUB_User_Interface ePUB_UI;
	
	
	
	public static Scene scene,scene1, regScene, homeScene;
	public static StackPane root;

	public static StackPane homePane;

	public static Pane regRoot, pane;
	public static Stage stg;
	
	private BorderPane naviPane;
	
	
	/**
	 * This is start method to start the application and inside the parenthesis, create the variable of the Stage.
	 */
	public void start(final Stage windowStage)
	{
		stg=windowStage;
		
		/**
		 * Calling omega method
		 */
		Gradient_Effects.gradient();
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXX                      Second Window Setup                  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		/**
		 * In order to handle two windows or scenes in two classes then create the object of Pane here
		 * and then crate the object of another class here and pass the Pane object in to the Class parenthesis.
		 * [Pane, Scene, User Interface class]
		 */
		// The pane create for scene 1 or may say for second window
		root = new StackPane();
		// Create the object of scene and set the window size of it, actually this is second secone of the window
		scene1 = new Scene(root, 1380, 700);
		// Set the background color of the window
		root.setBackground(new Background(new BackgroundFill(Gradient_Effects.elBano, CornerRadii.EMPTY, Insets.EMPTY)));
		
		// Create the object of the EPUB_User_Interface in order to setup the connection between them
		ePUB_UI = new EPUB_User_Interface(root);
		
		/**XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 * XXXXXXXXXXXXXXXXXXXXXXXXXXX                   Setup Navigation Drawer                                 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
		 XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*/
		// Create an object of the borderpane
		naviPane = new BorderPane();
		
		//naviDrawer.setTranslateY(300);
		// Set the flow of the Border pane vertically
		VBox.setVgrow(naviPane, Priority.ALWAYS);
		
		
		// Set the padding of the stackpane
		root.setPadding(new Insets(45, 15, 15, 10));
		
		// Group the children together and access the backgroundImage method from Background_Image class.
		root.getChildren().addAll(HBoxBuilder.create().spacing(10).children(
				VBoxBuilder.create().spacing(10).children().build(), EPUB_User_Interface.tabPane)
				        .build(),EPUB_User_Interface.omegaBar, EPUB_User_Interface.gammaBar,
				        Web_View.loadingProcess, Web_View.status);		
		
		
		
		

		// Disable the stage close icon, 
		windowStage.setOnCloseRequest(new EventHandler<WindowEvent>()
		{
		public void handle(WindowEvent event)
		    {
				// Method calling to disable the quit icon
				//disableStageQuitIcon(event);
			}
		});
		
		
		// Disable the resizable option
		windowStage.setResizable(false);
		// Set the window at full screen
		windowStage.setFullScreen(false);
		// Set the icon or image as a icon on stage
		windowStage.getIcons().add(new Image(APPLICATION_ICON));
		// Set the style of the stage or may also set it as transparent
		windowStage.initStyle(StageStyle.DECORATED);
		// Set the title of the window or the application
		windowStage.setTitle("E-PUB Application");
		// Connect the scene and stage together
		windowStage.setScene(scene1); // pass scene inside the parenthesis
		// Display window
		windowStage.show();
	}
	

	/**
	 * Method to disable the close window which is available on the stage
	 */
	public void disableStageQuitIcon(WindowEvent event)
	{
		// Prevent the user to close the window
		EventType<WindowEvent> disableWindow= (EventType<WindowEvent>) event.getEventType();
		if(disableWindow == WindowEvent.WINDOW_CLOSE_REQUEST)
		{
			// Reject the request to close the window
			event.consume();
		}
	}
	
	// Main method to launch the application
	public static void main(String []args)
	{
		// Launch the application
		Application.launch(args);
	}

}
